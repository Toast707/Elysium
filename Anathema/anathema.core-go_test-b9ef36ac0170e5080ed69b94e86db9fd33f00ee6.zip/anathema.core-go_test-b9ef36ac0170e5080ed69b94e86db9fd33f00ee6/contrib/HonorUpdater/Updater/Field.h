#ifndef _FIELD_H_
#define _FIELD_H_

class Field
{
    public:
        enum DataTypes
        {
            DB_TYPE_UNKNOWN = 0x00,
            DB_TYPE_STRING  = 0x01,
            DB_TYPE_INTEGER = 0x02,
            DB_TYPE_FLOAT   = 0x03,
            DB_TYPE_BOOL    = 0x04
        };
        
        Field() : mValue(NULL), mType(DB_TYPE_UNKNOWN) {};
        ~Field();
        char *GetString() const { return mValue; }
        int GetInt() const { return mValue ? static_cast<int>(atol(mValue)) : int(0); }
        float GetFloat() const { return mValue ? static_cast<float>(atol(mValue)) : float(0); }
        
        void SetValue(const char *value);
        void SetType(enum DataTypes type) { mType = type; }
    private:
        char *mValue;
        enum DataTypes mType;
};

Field::~Field()
{
    if(mValue) delete [] mValue;
}

void Field::SetValue(const char *value)
{
    if(mValue) delete [] mValue;

    if (value)
    {
        mValue = new char[strlen(value) + 1];
        strcpy(mValue, value);
    }
    else
        mValue = NULL;
}

#endif
