#ifndef _DATABASEENV_H_
#define _DATABASEENV_H_
#ifdef WIN32
#include <winsock.h>
#endif

#include <mysql/mysql.h>

#define MAX_QUERY_LEN   32*1024

#include "Field.h"
#include "QueryResult.h"
#include "DataBase.h"

extern DataBase Characters;

#endif


