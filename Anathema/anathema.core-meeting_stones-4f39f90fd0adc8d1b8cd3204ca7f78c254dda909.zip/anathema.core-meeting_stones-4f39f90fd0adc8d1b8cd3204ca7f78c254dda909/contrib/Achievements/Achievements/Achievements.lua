﻿Achievements = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceEvent-2.0", "AceDB-2.0", "FuBarPlugin-2.0")
local tablet = AceLibrary("Tablet-2.0")

local options = {
    type = "execute",
    name = "Request achievements",
    desc = "Request achievements",
    func = function()
        Achievements:Request()
    end
}

Achievements.name = "FuBar - Achievements"
Achievements:RegisterDB("AchievementsFubarDB")
Achievements.defaultMinimapPosition = 0
Achievements.hasNoColor = true
Achievements.hasIcon = "Interface\\Addons\\Achievements\\icon"
Achievements.hideWithoutStandby = true

Achievements:RegisterChatCommand({ "/achievements", "/achiv" }, options)

local L = {}
local L_HINT = 1
local L_TITLE = 2
local L_DESC = 3
local L_EXIT = 4

local AchivTitleTable = {}
local AchivStatusTable = {}
local AchivDescTable = {}
local selectedId = 1
local numAchivs = 0;

local ACHIVS_DISPLAYED = 22
local ACHIV_HEIGHT = 16

function Achievements:OnInitialize()
    L[L_HINT] = "|cffeda55fClick|r for request achievements. |cffeda55fClick and drag|r to move button."
    L[L_TITLE] = "Achievements"
    L[L_DESC] = "Description"
    L[L_EXIT] = "Exit"
    Achievements:SetLocale()
end

function Achievements:SetLocale()
    AchievementsTitleText:SetText(L[L_TITLE])
    AchievementsDescriptionTitle:SetText(L[L_DESC])
    AchievementsFrameExitButton:SetText(L[L_EXIT])
end

function Achievements:OnEnable()
    self:RegisterEvent("CHAT_MSG_ADDON")
    self:RegisterEvent("UNIT_PORTRAIT_UPDATE");
    SetPortraitTexture(AchievementsPortrait, "player")
    SendAddonMessage("ACHIEVLOCALE", " ", "BATTLEGROUND");
end

function Achievements:OnDisable()
    
end

function Achievements:Request()
    if AchievementsFrame:IsVisible() then
        AchievementsFrame:Hide()
    else
        SendAddonMessage("ACHIEV", " ", "BATTLEGROUND");
    end
end

function strsplit(msg, char)
    local arr = { }
    local i = 0
    while (string.find(msg, char) ) do
        local iStart, iEnd = string.find(msg, char)
        i = i + 1
        arr[i] = strsub(msg, 1, iStart-1)
        msg = strsub(msg, iEnd+1, strlen(msg))
    end
    if ( strlen(msg) > 0 ) then
        arr[i+1] = msg
    end
    return arr
end

function Achievements:CHAT_MSG_ADDON(prefix, message, distribution, sender)
    if distribution ~= "BATTLEGROUND" then
        return
    end
    
    if sender ~= GetUnitName("player") then
        return
    end
    
    if prefix == "ACHIEVLOCALE" then
        local mas = strsplit(message, '\t')
        for i,j in mas do
            L[i] = j
        end
        Achievements:SetLocale()
    else if prefix == "ACHIEV" then
        local mas1 = strsplit(message, '\r')
        if table.getn(mas1) == 0 then error("Achievements not found!") end
        AchivTitleTable = {}
        AchivStatusTable = {}
        AchivDescTable = {}
        for i, j in mas1 do
            local mas2 = { }
            mas2 = strsplit(j, '\t')
            if table.getn(mas2) ~= 3 then error("You should update your addon.") end
            AchivTitleTable[i] = mas2[1]
            AchivStatusTable[i] = mas2[2]
            AchivDescTable[i] = mas2[3]
        end
        numAchivs = table.getn(mas1)
        AchievementsFrame:Show()
    end end
end

function Achievements:UNIT_PORTRAIT_UPDATE(unit)
    if not AchievementsFrame:IsVisible() then return end
    
    if unit == "player" then
        SetPortraitTexture(AchievementsPortrait, unit)
    end
end

function Achievements:OnTooltipUpdate()
    tablet:SetHint(L[L_HINT])
end

function Achievements:OnClick()
    Achievements:Request()
end

function AchievementsFrame_OnShow()
    PlaySound("igQuestLogOpen")
    AchievementsFrame_Update()
end

function AchievementsFrame_Update()
    if not AchievementsFrame:IsVisible() then return end
    local line;
    FauxScrollFrame_Update(AchievementsListScrollFrame, numAchivs, ACHIVS_DISPLAYED, ACHIV_HEIGHT)
    AchievementsHighlightFrame:Hide()
    for i = 1, ACHIVS_DISPLAYED do
        local achivTitle = getglobal("AchievementsTitle"..i)
        local achivTitleHighlight = getglobal("AchievementsTitle"..i.."Highlight")
        line = i + FauxScrollFrame_GetOffset(AchievementsListScrollFrame);
        if line <= numAchivs then
            achivTitle:SetText(AchivTitleTable[line])
            achivTitle:SetNormalTexture("")
            achivTitleHighlight:SetTexture("")
            achivTitle.r = 1.00
            achivTitle.g = 1.00
            achivTitle.b = 0.00
            achivTitle:Show()
            if line == selectedId then
                AchievementsHighlightFrame:SetPoint("TOPLEFT", achivTitle, "TOPLEFT", 0, 0);
                AchievementSkillHighlight:SetVertexColor(achivTitle.r, achivTitle.g, achivTitle.b);
                AchievementsHighlightFrame:Show();
                achivTitle:LockHighlight();
                AchievementsTitle_UpdateDesc(selectedId)
            else
                achivTitle:UnlockHighlight();
            end
        else
            achivTitle:Hide()
        end
    end
end

function AchievementsTitle_OnClick(button)
    if button == "LeftButton" then
        local id = this:GetID() + FauxScrollFrame_GetOffset(AchievementsListScrollFrame)
        AchievementsFrame_SetSelection(id)
    end
end

function AchievementsFrame_SetSelection(id)
    selectedId = id
    AchievementsFrame_Update()
end

function AchievementsTitle_UpdateDesc(id)
    AchievementsQuestTitle:SetText(AchivTitleTable[id])
    AchievementsStatus1:SetText(AchivStatusTable[id])
    AchievementsQuestDescription:SetText(AchivDescTable[id])
end
