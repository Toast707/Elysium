-- Character database
CREATE TABLE `character_achievstatus` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `achievement` int(11) unsigned NOT NULL default '0' COMMENT 'Achievement Identifier',
  `status` int(11) unsigned NOT NULL default '0',
  `rewarded` tinyint(1) unsigned NOT NULL default '0',
  `count1` int(11) unsigned NOT NULL default '0',
  `count2` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`achievement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Achievement System';

-- World database
CREATE TABLE `achievement_template` (
  `entry` int(11) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `Title` text,
  `Details` text,
  `Objectives` text,
  `condition_type` int(11) unsigned NOT NULL default '0',
  `condition_value1` int(11) unsigned NOT NULL default '0',
  `condition_value2` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`entry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Achievement System';

