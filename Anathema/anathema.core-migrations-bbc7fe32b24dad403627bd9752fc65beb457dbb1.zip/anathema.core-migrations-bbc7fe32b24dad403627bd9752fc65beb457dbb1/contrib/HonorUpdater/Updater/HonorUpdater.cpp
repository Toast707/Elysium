#include <stdio.h>
#include <iostream>
#include <fstream> 
#include <stdlib.h>
#include <string>
#include <string.h>
#include <cmath>
#include <list>
#include <time.h>
#include <math.h>
#include <map>

#include "DataBaseEnv.h"

#define MIN_KILLS 25
#define HONOR_RANK_COUNT 16
#define MAX_SYM 20

using namespace std;

enum TYPE_OF_HONOR
{
    HONORABLE_KILL    = 1,
    DISHONORABLE_KILL = 2,
    BONUS_HONOR_UNIT  = 3,
    QUEST             = 4,
    OTHER             = 5,
};

enum Commands 
{
    com_help,
    com_update,
    com_construct,
    com_getdata,
    com_getpl,
    com_unstanding,
    com_calcbp,
    com_calcrp,
    com_showpl,
    com_write,
    com_calcws,
    com_getst,
    com_showkl,
    com_writekl,
    sbcom_alliance,
    sbcom_horde,
    com_quit
};

struct PlayerHonor
{
    int guid;
    int level;
    int highest_rank;
    int standing;
    int kills;
    float rank_points;
    float contribution_points;
    public:
        PlayerHonor() {}
};

struct PlayerOldKills
{
    int guid;
    int hk;
    int dk;
};

struct UpdateQueriesOne
{
    int field1_tbl1;
    int field2_tbl1;
};

struct UpdateQueriesTwo
{
    int field1_tbl2;
    int field2_tbl2;
};

struct ControlPoint
{
    int BRP;
    float CP;
    float RP;
    int pointer;
};

bool sort_cp(PlayerHonor arg1, PlayerHonor arg2)
{
    return arg1.contribution_points > arg2.contribution_points;
}

bool find_by_standing(PlayerHonor arg1, int standing)
{
    return arg1.standing == standing;
}

int GetDateFromDatabase() const 
{
    QueryResult* result = Characters.PQuery("SELECT TO_DAYS(NOW())");

    if (!result)
        return 0;

    int day = result->Fetch()[0].GetInt();
    delete result;
    return day;
}

#ifdef WIN32
#define DBL_EPSILON 2.2204460492503131E-16

float round(float v){
    int sgn =v/fabs(v);
    float eps = sgn*10;
    float rmr = fmod( v, eps );
    v -= rmr;
    if( sgn*rmr - sgn*(eps / 2)>-DBL_EPSILON )
        v += eps;
    return v;
}
#endif

typedef list<PlayerHonor> PlayersHonorList;
typedef list<ControlPoint> ControlPointsList;
typedef list<PlayerOldKills> PlayersOldKillsList;
typedef list<UpdateQueriesOne> UpdateQueriesListOne;
typedef list<UpdateQueriesTwo> UpdateQueriesListTwo;

static map<string, Commands> map_Commands;
static char comInput[MAX_SYM];
static void InitializeCommands();

void InitializeCommands()
{
    map_Commands["update"]      = com_update;
    map_Commands["help"]        = com_help;
    map_Commands["construct"]   = com_construct;
    map_Commands["getdata"]     = com_getdata;
    map_Commands["getpl"]       = com_getpl;
    map_Commands["unstanding"]  = com_unstanding;
    map_Commands["calcbp"]      = com_calcbp;
    map_Commands["calcrp"]      = com_calcrp;
    map_Commands["showpl"]      = com_showpl;
    map_Commands["write"]       = com_write;
    map_Commands["calcws"]      = com_calcws;
    map_Commands["getst"]       = com_getst;
    map_Commands["showkl"]      = com_showkl;
    map_Commands["writekl"]     = com_writekl;
    map_Commands["quit"]        = com_quit;
    
    map_Commands["alliance"]    = sbcom_alliance;
    map_Commands["horde"]       = sbcom_horde;
}

DataBase Characters;
PlayersHonorList m_playersHonorList;
ControlPointsList m_controlPointsList;
PlayersOldKillsList m_playersOldKillsList;
UpdateQueriesListOne m_updateQueriesListOne;
UpdateQueriesListTwo m_updateQueriesListTwo;

void unsetWeeklyStanding(Commands fraction);
void getPlayersList(Commands fraction);
void showPlayersList();
void updateWeeklyStanding();
void calculatePointsTable();
void calculateRankPoints();
void updateHonor(Commands fraction);

void getOldKillsList();
void showOldKillsList();
void updateOldKills();

void getDataFields();
void updateConstructor();

float capRankPoints(int level);

int calculateHonorRank(float rank_points);

int main()
{
    InitializeCommands();

    char dbhost[14], dbuser[14], dbpass[14], dbname[14];
    bool done = false;

    cout << "Welcome to Anathema Engine honor updater.\n";
    start:
    cout << "Enter MySQL hostname or IP address: ";
    cin >> dbhost;
    cout << "Enter MySQL username: ";
    cin >> dbuser;
    cout << "Enter MySQL user password: ";
    cin >> dbpass;
    cout << "Enter MySQL database name: ";
    cin >> dbname;
    cout << "Initialize database connection... " << flush;
    if(!Characters.Init(dbhost,dbuser,dbpass,dbname))
        goto start;
    cout << "Done!\n";
    while(!done)
    {
        cout << "Type command (help for help): ";
        cout.flush();
        cin.getline(comInput, MAX_SYM);
        switch(map_Commands[comInput])
        {
            case com_update:
                cout << "Enter fraction (alliance or horde): ";
                cout.flush();
                cin.getline(comInput, MAX_SYM);
                switch(map_Commands[comInput])
                {
                    case sbcom_alliance:
                        unsetWeeklyStanding(sbcom_alliance);
                        getPlayersList(sbcom_alliance);
                        updateWeeklyStanding();
                        calculatePointsTable();
                        calculateRankPoints();
                        updateHonor(sbcom_alliance);
                        break;
                    case sbcom_horde:
                        unsetWeeklyStanding(sbcom_horde);
                        getPlayersList(sbcom_horde);
                        updateWeeklyStanding();
                        calculatePointsTable();
                        calculateRankPoints();
                        updateHonor(sbcom_horde);
                        break;
                    default:
                        cout << map_Commands[comInput] << " isn't WoW fraction! Failed!";
                        break;
                }
                break;
            case com_help:
                cout << "== Anathema Engine honor updater list of commands:\n";
                cout << "update[alliance|horde] - do calculating and updating weekly standing and rank points.\n"
                        "Its equil for (unstanding, getpl, calcws, calcbp, calcrp, write) commands\n";
                cout << "help - help\n";
                cout << "getpl[alliance|horde] - get a list of players\n";
                cout << "unstanding[alliance|horde] - unset all standing in `characters` table\n";
                cout << "calcbp - calculate breakpoints \n";
                cout << "quit - quit programm\n";
                cout << "calcrp - calculate rank points\n";
                cout << "showpl - show a list of players\n";
                cout << "write - update `characters` table\n";
                cout << "calcws - calculate weekly standing for list of players\n"; 
                cout << "== Stored kills commands:\n";
                cout << "getst - get stored kills list\n";    
                cout << "showkl - show kills list\n";
                cout << "writekl - update kills\n";
                cout << "== Other tools kills commands:\n";
                cout << "getdata - get characters data fields\n";    
                cout << "construct - multi-rows update constructor\n";
                break;
            case com_construct:
                updateConstructor();
                break;
            case com_getdata:
                getDataFields();
                break;
            case com_getpl:
                cout << "Enter fraction (alliance or horde): ";
                cout.flush();
                cin.getline(comInput, MAX_SYM);
                switch(map_Commands[comInput])
                {
                    case sbcom_alliance:
                        getPlayersList(sbcom_alliance);
                        break;
                    case sbcom_horde:
                        getPlayersList(sbcom_horde);
                        break;
                    default:
                        cout << map_Commands[comInput] << " isn't WoW fraction! Failed!";
                        break;
                }
                break;
            case com_unstanding:
                cout << "Enter fraction (alliance or horde): ";
                cout.flush();
                cin.getline(comInput, MAX_SYM);
                switch(map_Commands[comInput])
                {
                    case sbcom_alliance:
                        unsetWeeklyStanding(sbcom_alliance);
                        break;
                    case sbcom_horde:
                        unsetWeeklyStanding(sbcom_horde);
                        break;
                    default:
                        cout << map_Commands[comInput] << " isn't WoW fraction! Failed!";
                        break;
                }
                break;
            case com_calcbp:
                calculatePointsTable();
                break;
            case com_quit:
                cout << "Good bye!\n";
                done = true;
                break;
            case com_calcrp:
                calculateRankPoints();
                break;
            case com_showpl:
                showPlayersList();
                break;
            case com_write:
                cout << "Enter fraction (alliance or horde): ";
                cout.flush();
                cin.getline(comInput, MAX_SYM);
                switch(map_Commands[comInput])
                {
                    case sbcom_alliance:
                        updateHonor(sbcom_alliance);
                        break;
                    case sbcom_horde:
                        updateHonor(sbcom_horde);
                        break;
                    default:
                        cout << map_Commands[comInput] << " isn't WoW fraction! Failed!";
                        break;
                }
                break;             
            case com_calcws:
                updateWeeklyStanding();
                break;
            case com_getst:
                getOldKillsList();
                break;
            case com_showkl:
                showOldKillsList();
                break;
            case com_writekl:
                updateOldKills();
                break;
            default:
                cout << "Incorrect syntax.\n";
                break;
        }
    }
    return 0;
}

void updateConstructor()
{
    char db_1[14], db_2[14], tbl_1[14], tbl_2[14], field_1_tbl1[14],  field_2_tbl1[14], field_1_tbl2[14], field_2_tbl2[14];
    int f_1_tbl1, f_2_tbl1, f_1_tbl2, f_2_tbl2;
    
    cout << "Enter first db name: ";
    cin >> db_1;
    cout << "Enter second db name: ";
    cin >> db_2;
    cout << "Enter table name from first db: ";
    cin >> tbl_1;
    cout << "Enter table name from second db: ";
    cin >> tbl_2;
    cout << "Enter field1 name from first table: ";
    cin >> field_1_tbl1;
    cout << "Enter field2 name from first table: ";
    cin >> field_2_tbl1;
    cout << "Enter field1 name from second table: ";
    cin >> field_1_tbl2;
    cout << "Enter field2 name from second table: ";
    cin >> field_2_tbl2;
    
    string ofile = "MultiUpdate.sql";
    std::ofstream outfile(ofile.c_str());
    
    QueryResult *result_tbl1 = Characters.PQuery("SELECT DISTINCT `%s`,`%s` FROM `%s`.`%s`", field_1_tbl1, field_2_tbl1, db_1, tbl_1);
    QueryResult *result_tbl2 = Characters.PQuery("SELECT DISTINCT `%s`,`%s` FROM `%s`.`%s`", field_1_tbl2, field_2_tbl2, db_2, tbl_2);
                
    if(result_tbl1)
    {
        m_updateQueriesListOne.clear();
        do
        {
            Field *fields_tbl1 = result_tbl1->Fetch();
            f_1_tbl1 = fields_tbl1[0].GetInt();
            f_2_tbl1 = fields_tbl1[1].GetInt();
            //cout << "Getting " << field_1_tbl1 << "," << field_2_tbl1 << " from " << db_1 << "." << tbl_1 << "\n" << flush;
            
            UpdateQueriesOne updateQueryOne;
            updateQueryOne.field1_tbl1 = f_1_tbl1;
            updateQueryOne.field2_tbl1 = f_2_tbl1;
            
            m_updateQueriesListOne.push_back(updateQueryOne);
        }
        while(result_tbl1->NextRow());
        delete result_tbl1;
    }
    
    if(result_tbl2)
    {
        m_updateQueriesListTwo.clear();
        do
        {
            Field *fields_tbl2 = result_tbl2->Fetch();
            f_1_tbl2 = fields_tbl2[0].GetInt();
            f_2_tbl2 = fields_tbl2[1].GetInt();
            //cout << "Getting " << field_1_tbl2 << "," << field_2_tbl2 << " from " << db_2 << "." << tbl_2 << "\n" << flush;
            
            UpdateQueriesTwo updateQueryTwo;
            updateQueryTwo.field1_tbl2 = f_1_tbl2;
            updateQueryTwo.field2_tbl2 = f_2_tbl2;
            
            m_updateQueriesListTwo.push_back(updateQueryTwo);
        }
        while(result_tbl2->NextRow());
        delete result_tbl2;
    }
    
    for (UpdateQueriesListOne::iterator itr1 = m_updateQueriesListOne.begin(); itr1 != m_updateQueriesListOne.end() ; ++itr1)
        for (UpdateQueriesListTwo::iterator itr2 = m_updateQueriesListTwo.begin(); itr2 != m_updateQueriesListTwo.end() ; ++itr2)
            if (itr1->field1_tbl1 == itr2->field1_tbl2)
                outfile << "UPDATE " << tbl_1 << " SET " << field_2_tbl1 << " = " << itr2->field2_tbl2 << " WHERE " << field_1_tbl1 << " = " << itr1->field1_tbl1 << ";" << endl;
}

void unsetWeeklyStanding(Commands fraction)
{
    if (fraction == sbcom_alliance)
    {
        cout << "Set all Alliance standing in `characters` table to 0... ";
        if (Characters.PExecute("UPDATE `characters` SET `honor_standing` = '0' WHERE `race` IN(1,3,4,7)"))
        cout << "Done!\n";
    }
    else if (fraction == sbcom_horde)
    {
        cout << "Set all Horde standing in `characters` table to 0... ";
        if (Characters.PExecute("UPDATE `characters` SET `honor_standing` = '0' WHERE `race` IN(2,5,6,8)"))
        cout << "Done!\n";
    }
}
 
void getOldKillsList()
{
    int honor_type, guid;

    time_t rawtime;
    time( &rawtime );
    tm* now = localtime( &rawtime );
    int today = GetDateFromDatabase();
    int thisWeekBegin = today - now->tm_wday;
    int lastWeekBegin = thisWeekBegin - 7;
    cout << "Today: " << today << endl;
    cout << "Last week begin: " << lastWeekBegin << endl;
    cout << "Getting players old kills list...\n" << flush;

    QueryResult *result = Characters.PQuery("SELECT DISTINCT `guid` FROM `character_honor`");
    if(result)
    {
        m_playersOldKillsList.clear();
        do
        {
            Field *fields = result->Fetch();
            guid = fields[0].GetInt();
            //cout << "Getting player " << guid<< "\n" << flush;
            PlayerOldKills playerOldKills;
            playerOldKills.guid = guid;
            QueryResult *result_hk = Characters.PQuery("SELECT count(*) FROM `character_honor` WHERE `guid` = '%d' AND`date` < '%d' AND `type` = '%d'", guid, lastWeekBegin, HONORABLE_KILL);
            if(result_hk)
            {
                Field *fields_hk = result_hk->Fetch();
                playerOldKills.hk = fields_hk[0].GetFloat();
                delete result_hk;
            }
            else continue;
            QueryResult *result_dk = Characters.PQuery("SELECT count(*) FROM `character_honor` WHERE `guid` = '%d' AND`date` < '%d' AND `type` = '%d'", guid, lastWeekBegin, DISHONORABLE_KILL);
            if(result_dk)
            {
                Field *fields_dk = result_dk->Fetch();
                playerOldKills.dk = fields_dk[0].GetFloat();
                delete result_dk;
            }
            else continue;
            m_playersOldKillsList.push_back(playerOldKills);            
                }
        while(result->NextRow());
        delete result;
    }
    cout << "Done!\n";
}

void getDataFields()
{
    int value,i,guid;
    string ofile = "DataFields.txt";
    cout << "Enter character GUID: ";
    cin >> guid;
    std::ofstream outfile(ofile.c_str());
    for (i = 0; i < 1282; i++)
    {
        QueryResult *result = Characters.PQuery("SELECT CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(`data`, ' ', %u + 1), ' ', -1) AS UNSIGNED) FROM `characters` WHERE `guid` = %u", i, guid);
        if (result)
        {
            Field *fields = result->Fetch();
            value = fields[0].GetInt();
            outfile << "Field number: " << i << " | " << value << endl;
            //cout << "Field number: " << i << " | " << value << endl;
        }
    }
}

void showOldKillsList()
{
    cout << "Players Old Kills List:\n";
    for (PlayersOldKillsList::iterator itr = m_playersOldKillsList.begin(); itr != m_playersOldKillsList.end() ; ++itr)
    {
        cout << "========\n";
        cout << "Guid: " << itr->guid << " ";
        cout << "HK: " << itr->hk << " ";
        cout << "DK: " << itr->dk << "\n ";
    }
}

void updateOldKills()
{
    time_t rawtime;
    time( &rawtime );
    tm* now = localtime( &rawtime );
    int today = GetDateFromDatabase();
    int thisWeekBegin = today - now->tm_wday;
    int lastWeekBegin = thisWeekBegin - 7;
    
    cout << "Updating kills... "<< flush;
    for (PlayersOldKillsList::iterator itr = m_playersOldKillsList.begin(); itr != m_playersOldKillsList.end() ; ++itr)
    Characters.PExecute("UPDATE `characters` SET `stored_dishonorable_kills` = `stored_dishonorable_kills` + %d, `stored_honorable_kills` = `stored_honorable_kills` + %d WHERE `guid` = '%d'",itr->dk, itr->hk, itr->guid);
    Characters.PExecute("DELETE FROM character_honor WHERE date < '%d'",lastWeekBegin);
    cout << "Done!\n";
    
}

void getPlayersList(Commands fraction)
{
    int guid, kills;
    
    time_t rawtime;
    time( &rawtime );
    tm* now = localtime( &rawtime );
    int today = GetDateFromDatabase();
    int thisWeekBegin = today - now->tm_wday;
    int lastWeekBegin = thisWeekBegin - 7;
    cout << "Today: " << today << endl;

    QueryResult *result = NULL;
    if (fraction == sbcom_alliance)
    {
        cout << "Getting Alliance players list... " << flush;
        result = Characters.PQuery("SELECT `guid`, `level`, `honor_highest_rank`, `honor_rank_points` FROM `characters` WHERE `race` IN(1,3,4,7)");
    }
    else if (fraction == sbcom_horde)
    {
        cout << "Getting Horde players list... " << flush;
        result = Characters.PQuery("SELECT `guid`, `level`, `honor_highest_rank`, `honor_rank_points` FROM `characters` WHERE `race` IN(2,5,6,8)");
    }

    if(result)
    {
        m_playersHonorList.clear();
        
        do
        {
            Field *fields = result->Fetch();
            guid = fields[0].GetInt();
            QueryResult *result_kills = Characters.PQuery("SELECT count(*) FROM `character_honor` WHERE `guid` = '%d' AND `type` = '%d' AND `date` > '%d'", guid, HONORABLE_KILL, today - 7);
            if(result_kills)
            {
                Field *fields_kills = result_kills->Fetch();
                kills = fields_kills[0].GetInt();
                delete result_kills;
            }
            else continue;
            if(kills >= MIN_KILLS)
            {
                PlayerHonor playerHonor;
                playerHonor.guid            = guid;
                playerHonor.kills           = kills;
                playerHonor.standing        = int(0);
                playerHonor.level           = fields[1].GetInt();
                playerHonor.highest_rank    = fields[2].GetInt();
                playerHonor.rank_points     = fields[3].GetFloat();
                QueryResult *result_honor = Characters.PQuery("SELECT SUM(honor) FROM `character_honor` WHERE `guid` = '%d' AND `type` <> '%d' AND `date` > '%d'", guid, DISHONORABLE_KILL, today - 7);
                if(result_honor)
                {
                    Field *fields_honor = result_honor->Fetch();
                    playerHonor.contribution_points = fields_honor[0].GetFloat();
                    delete result_honor;
                }
                else continue;
                m_playersHonorList.push_back(playerHonor);
            }
            
        }
        while(result->NextRow());
        delete result;
    }
    
    cout << "Done!\n";
}

void showPlayersList()
{
    cout << "Players List:\n";
    for (PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end() ; ++itr)
    {
        cout << "========\n";
        cout << "Guid: " << itr->guid << " ";
        cout << "kills: " << itr->kills << " ";
        cout << "standing: " << itr->standing << " ";
        cout << "CP: " << itr->contribution_points << " ";
        cout << "RP: " << itr->rank_points << " ";
        cout << "highest rank: " << itr->highest_rank << "\n";
    }
}

void updateWeeklyStanding()
{
    int standing = 0;
    cout << "Update Weekly Standing... ";
    m_playersHonorList.sort(sort_cp);
    for(PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end(); ++itr)
        itr->standing = ++standing;
    cout << "Done!\n";
}
void calculatePointsTable()
{
    /*
    # Variables:
    #   NR    = total number of ranked players ont he server/side
    #   @CP   = array of the CP scores for each of the ranked 
    #           players, indexed by their WS
    #   @FX   = the X (CP) value of the 15 function control points
    #   @FY   = the Y (RP) value of the 15 function control points
    # 
    # Before any scoring can be done, we need to determine 
    # the parameters of the piecewise-linear function for 
    # this week. This is done with the following function call:
    #
    (@FX, @FY) = GenerateFunction(NR, @CP);
    sub GenerateFunction (NR, @CP) {
      #
      # initialize the breakpoint values
      BRK[14] = 0.002;
      BRK[13] = 0.007;
      BRK[12] = 0.017;
      BRK[11] = 0.037;
      BRK[10] = 0.077;
      BRK[ 9] = 0.137;       
      BRK[ 8] = 0.207;       
      BRK[ 7] = 0.287;       
      BRK[ 6] = 0.377;       
      BRK[ 5] = 0.477;       
      BRK[ 4] = 0.587;      
      BRK[ 3] = 0.715;      
      BRK[ 2] = 0.858;
      #
      # get the WS scores at the top of each break point
      foreach i (2..14) {
          BRK[i] = round( BRK[i] * NR );
      }     
      #
      # set the high point
      FX[15] = CP[1];   # top scorer
      FY[15] = 13000;   # ... gets 13000 RP
      #
      # set the low point
      FX[ 1] = 0;
      FY[ 1] = 0;
      #
      # the Y values for each breakpoint are fixed
      FY[ 2] = 400;
      foreach i (3..14) {
          FY[i] = (i-2) * 1000;
      }
      #
      # the X values for each breakpoint are found from the CP scores
      # of the players around that point in the WS scores
      foreach i (2..14) {
          FX[i] ={ CP( BRK[i] ) + CP( BRK[i]+1 ) }/ 2;
      }
      # 
      # function is complete, return the arrays
      return (@FX, @FY);
    }
    */
    float brp[16] = {0.0f, 1.0f, 0.845f, 0.697f, 0.556f, 0.436f, 0.327f, 0.228f, 0.159f, 0.1f, 0.06f, 0.035f, 0.02f, 0.008f, 0.003f, 0.0f};
    int NR = m_playersHonorList.size();
	m_controlPointsList.clear();
    int cp_up;
    int cp_down;
    for(int i = 1; i < 16; i++)
    {
        ControlPoint controlPoint;
        controlPoint.BRP = int(round(brp[i]*NR));
        controlPoint.pointer = i;
        cp_up = 0;
        cp_down = 0;
        if(i == 1)
        {
            controlPoint.RP = 0;
            controlPoint.CP = 0;
        }
        else if(i == 2)
        {
            controlPoint.RP = 400;
            for(PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end(); ++itr)
            {
                if(itr->standing == controlPoint.BRP)
                    cp_up = itr->contribution_points;
                if(itr->standing == controlPoint.BRP+1)
                    cp_down = itr->contribution_points;
                if(cp_up !=0 && cp_down !=0)
                {
                    controlPoint.CP = int(round((cp_up + cp_down)/2));
                    break;
                }
            }
        }
        else if(i == 15)
        {
            controlPoint.RP = 13000;
            for(PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end(); ++itr)
                if(itr->standing == 1)
                {
                    controlPoint.CP = itr->contribution_points;
                    break;
                }
        }
        else
        {
            controlPoint.RP = (i - 2) * 1000;
            for(PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end(); ++itr)
            {
                if(itr->standing == controlPoint.BRP)
                    cp_up = itr->contribution_points;
                if(itr->standing == controlPoint.BRP+1)
                    cp_down = itr->contribution_points;
                if(cp_up !=0 && cp_down !=0)
                {
                    controlPoint.CP = int(round((cp_up + cp_down)/2));
                    break;
                }
            }
        }
        m_controlPointsList.push_back(controlPoint);
        cout << controlPoint.pointer << " " << controlPoint.BRP << " " << controlPoint.CP << " " << controlPoint.RP << "\n";
    }
}

void calculateRankPoints()
{
    /*
    # Variables:
    #   CP    = the given player's CP score for the week
    #   @FX   = function params from above
    #   @FY   = function params from above
    #   RP    = the given player's RP earning for the week
    #
    # RP is found by a linear fit to one segment of the 
    # generated function.
    # 
    RP = LinearFit(CP, @FX, @FY);
    sub LinearFit (CP, @FX, @FY) {
      #
      # search the function for the two points that bound the given CP
      i = 15;
      while ((i>0) and (FX[i-1] > CP)) {
          i--;
      }
      # 
      # we now have i such that FX[i] > CP >= FX[i-1]
      # so interpolate
      RP = (FY[i] - FY[i-1]) * (CP - FX[i-1]) / (FX[i] - FX[i-1]) + FY[i-1];
      #
      # that's all there is to it
      return(RP);
    }
    */
    
    float earning;
    float delta;
    
    cout << "Calculating earning, decay and delta... ";
    for(PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end(); ++itr)
    {
        earning = 0.0;
        ControlPointsList::iterator curr = m_controlPointsList.end();
        ControlPointsList::iterator prev = m_controlPointsList.end()--;
        while(prev->CP > itr->contribution_points && curr !=m_controlPointsList.begin())
        {
            --curr;
            --prev;
        }
        
        if((curr->CP - prev->CP) == 0)
            earning = curr->RP;
        else
            earning = (curr->RP - prev->RP) * (itr->contribution_points - prev->CP) / (curr->CP - prev->CP) + prev->RP;
 
        delta = earning - itr->rank_points * 0.2;
        if(delta < 0.0)
            delta *= 0.5;
        if(delta < -2500.0)
            delta = -2500.0;
        itr->rank_points += delta;
        itr->rank_points = (itr->rank_points < capRankPoints(itr->level)) ?
             itr->rank_points : capRankPoints(itr->level);
        itr->highest_rank = (itr->highest_rank > calculateHonorRank(itr->rank_points)) ?
             itr->highest_rank : calculateHonorRank(itr->rank_points);
    }
    cout << "Done!\n";
}

void updateHonor(Commands fraction)
{
    cout << "Updating honor... ";
    for(PlayersHonorList::iterator itr = m_playersHonorList.begin(); itr != m_playersHonorList.end(); ++itr)
    Characters.PExecute("UPDATE `characters` SET `honor_standing` = '%d', `honor_highest_rank` = '%d', `honor_rank_points`  = '%d' WHERE `guid` = '%d'",itr->standing, itr->highest_rank, int(round(itr->rank_points)), itr->guid);
    if (fraction == sbcom_alliance)
        Characters.PExecute("UPDATE `characters` SET `honor_rank_points` = `honor_rank_points` * 0.9 WHERE `honor_standing` = '0' AND `honor_rank_points` > '0' AND `race` IN (1,3,4,7)");
    else if (fraction == sbcom_horde)
        Characters.PExecute("UPDATE `characters` SET `honor_rank_points` = `honor_rank_points` * 0.9 WHERE `honor_standing` = '0' AND `honor_rank_points` > '0' AND `race` IN (2,5,6,8)");
    cout << "Done!\n";
    
}
float capRankPoints(int level)
{
    int cap;
    if(level > 51)
        cap = 44200 + (level - 52) * 2600;
    else if(level  > 42)
        cap = 23725 + (level - 43) * 2275;
    else if(level > 38)
        cap = 17225 + (level - 39) * 1625;
    else if(level > 34)
        cap = 12025 + (level - 35) * 1300;
    else if(level > 29)
        cap = 7150 + (level - 30) * 975;
    else cap = 6500;
    return (float) cap;
}
        
int calculateHonorRank(float rank_points)
{
    int rank = 0;
    if       (rank_points <= -2000.0) rank = 1;     // Pariah (-4)
    else if(rank_points <= -1000.0) rank = 2;       // Outlaw (-3)
    else if(rank_points <= -500.0) rank = 3;        // Exiled (-2)
    else if(rank_points < 0.0) rank = 4;            // Dishonored (-1)
    else if(rank_points == 0) rank = 0;
    else if(rank_points <  2000.00) rank = 5;
    else if(rank_points > (HONOR_RANK_COUNT-3)*5000) rank = HONOR_RANK_COUNT+5;
    else rank = 6 + int(rank_points / 5000);

    return rank;
}