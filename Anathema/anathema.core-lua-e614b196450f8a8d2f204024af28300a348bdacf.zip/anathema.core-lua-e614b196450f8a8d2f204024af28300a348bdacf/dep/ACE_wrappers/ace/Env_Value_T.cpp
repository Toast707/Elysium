// $Id: Env_Value_T.cpp 80826 2008-03-04 14:51:23Z wotte $

#ifndef ACE_ENV_VALUE_T_CPP
#define ACE_ENV_VALUE_T_CPP

#include "ace/Env_Value_T.h"

#if ! defined (__ACE_INLINE__)
#include "ace/Env_Value_T.inl"
#endif /* __ACE_INLINE__ */

#endif /* ACE_ENV_VALUE_T_CPP */
