execute make vmaps.bat to make vmaps step by sep
execute makevmaps_SIMPLE.bat to so it in one step no quesions final screen [recommended]

put vmaps folder in mangos main folder to enable LOS [Line Of Sight]