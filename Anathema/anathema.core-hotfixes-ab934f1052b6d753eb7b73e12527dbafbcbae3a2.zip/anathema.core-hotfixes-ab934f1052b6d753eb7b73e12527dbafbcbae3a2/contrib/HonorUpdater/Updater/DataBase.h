#ifndef _DATABASE_H_
#define _DATABASE_H_

#include <stdarg.h>

class DataBase
{
    public:
        DataBase();
        ~DataBase();
        bool Init(const char *host, const char *user, const char *pass, const char *db);
        QueryResult* PQuery(const char *format,...);
        QueryResult* Query(const char *sql);
        bool PExecute(const char *format,...);
        bool Execute(const char *sql);
    private:
        MYSQL *mMysql;
        bool _Query(const char *sql, MYSQL_RES **pResult, MYSQL_FIELD **pFields, int* pRowCount, int* pFieldCount);
};

DataBase::DataBase()
{
}

DataBase::~DataBase()
{
    if(mMysql)
        mysql_close(mMysql);
}

bool DataBase::Init(const char *host, const char *user, const char *pass, const char *db)
{
    MYSQL *mysqlInit;
    mysqlInit = mysql_init(NULL);
    
    mMysql = mysql_real_connect(mysqlInit,host,user,pass,db,0,NULL,0);
    
    if(mMysql)
    {
        PExecute("SET NAMES `utf8`");
        PExecute("SET CHARACTER SET `utf8`");
        
        return true;
    }
    else
    {
        printf("Could not connect to MySQL database: %s\n",mysql_error(mysqlInit));
        mysql_close(mysqlInit);
        
        return false;
    }
}

QueryResult* DataBase::PQuery(const char *format,...)
{
    if(!format) return NULL;

    va_list args;
    char szQuery[MAX_QUERY_LEN];
    va_start(args, format);
    int res = vsnprintf(szQuery, MAX_QUERY_LEN, format, args);
    va_end(args);

    if(res==-1)
    {
        printf("SQL Query truncated (and not execute) for format: %s\n",format);
        return false;
    }

    return Query(szQuery);
}

QueryResult* DataBase::Query(const char *sql)
{
    MYSQL_RES *result = NULL;
    MYSQL_FIELD *fields = NULL;
    int rowCount = 0;
    int fieldCount = 0;

    if(!_Query(sql,&result,&fields,&rowCount,&fieldCount))
        return NULL;

    QueryResult *queryResult = new QueryResult(result, fields, rowCount, fieldCount);

    queryResult->NextRow();

    return queryResult;
}

bool DataBase::PExecute(const char *format,...)
{
    if (!format)
        return false;

    va_list args;
    char szQuery[MAX_QUERY_LEN];
    va_start(args, format);
    int res = vsnprintf(szQuery, MAX_QUERY_LEN, format, args);
    va_end(args);
    
    if(res==-1)
    {
        printf("SQL Query truncated (and not execute) for format: %s\n",format);
        return false;
    }
    
    return Execute(szQuery);
}

bool DataBase::Execute(const char *sql)
{
    if (!mMysql)
        return false;

    if(mysql_query(mMysql, sql))
    {
        printf("SQL: %s\n", sql);
        printf("SQL ERROR: %s\n", mysql_error(mMysql));
        return false;
    }
    
    return true;
}

bool DataBase::_Query(const char *sql, MYSQL_RES **pResult, MYSQL_FIELD **pFields, int* pRowCount, int* pFieldCount)
{
    if (!mMysql)
        return 0;

    if(mysql_query(mMysql, sql))
    {
        printf( "SQL: %s\n", sql );
        printf("query ERROR: %s\n", mysql_error(mMysql));
        return false;
    }
    *pResult = mysql_store_result(mMysql);
    *pRowCount = mysql_affected_rows(mMysql);
    *pFieldCount = mysql_field_count(mMysql);
    
    if (!*pResult )
        return false;

    if (!*pRowCount)
    {
        mysql_free_result(*pResult);
        return false;
    }

    *pFields = mysql_fetch_fields(*pResult);
    return true;
}

#endif
