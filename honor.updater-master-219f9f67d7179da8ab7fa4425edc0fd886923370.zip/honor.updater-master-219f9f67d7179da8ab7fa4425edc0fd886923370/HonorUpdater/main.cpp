#include "Updater.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Updater* window = new Updater;
    window->show();
    return app.exec();
}