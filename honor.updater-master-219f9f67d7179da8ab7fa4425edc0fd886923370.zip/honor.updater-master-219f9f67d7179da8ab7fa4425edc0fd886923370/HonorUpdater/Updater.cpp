#include "Updater.h"
#include "Threads.h"
#include <QMessageBox>

Updater::Updater(QMainWindow* parent)
    : QMainWindow(parent), counter(0)
{
    setupUi(this);

    QCoreApplication::setOrganizationName("HonorUpdater");
    QCoreApplication::setApplicationName("HonorUpdater");

    QSettings settings(QCoreApplication::organizationName(), QCoreApplication::applicationName());

    if (settings.allKeys().isEmpty())
    {
        settings.setValue("hostname", "localhost");
        settings.setValue("username", "root");
        settings.setValue("password", "");
        settings.setValue("dbname", "characters");
        settings.sync();
    }

    actionConnect = toolBar->addAction(QIcon(":/Updater/connect.png"), "Connect to database");
    labelConnect = new QLabel;
    labelConnect->setText(QString(" <b><font color=red>Not connected!</font></b>"));
    toolBar->addWidget(labelConnect);
    toolBar->addSeparator();
    actionAbout = toolBar->addAction(QIcon(":/Updater/about.png"), "About program");

    connect(actionConnect, SIGNAL(triggered()), this, SLOT(slotConnectPopup()));
    connect(actionAbout, SIGNAL(triggered()), this, SLOT(slotAbout()));
    connect(buttonUpdate, SIGNAL(clicked()), this, SLOT(slotCalculate()));
}

Updater::~Updater()
{
}

Connect::Connect(Updater* form)
    : m_form(form)
{
    setupUi(this);

    QSettings settings(QCoreApplication::organizationName(), QCoreApplication::applicationName());

    QString host = settings.value("hostname").toString();

    editHostname->setText(settings.value("hostname").toString());
    editUsername->setText(settings.value("username").toString());
    editPassword->setText(settings.value("password").toString());
    editDbname->setText(settings.value("dbname").toString());
    connect(connectButton, SIGNAL(clicked()), this, SLOT(slotConnect()));
}

Connect::~Connect()
{
}

void Updater::slotConnectPopup()
{
    Connect* connectWindow = new Connect(this);
    connectWindow->show();
}

void Connect::slotConnect()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");

    QString host;
    QString port("3306");

    if (editHostname->text().contains(':'))
    {
        host = editHostname->text().left(editHostname->text().indexOf(':'));
        port = editHostname->text().right(editHostname->text().length() - host.length() - 1);
    }
    else
        host = editHostname->text();

    db.setHostName(host);
    db.setPort(port.toInt());
    db.setUserName(editUsername->text());
    db.setPassword(editPassword->text());
    db.setDatabaseName(editDbname->text());

    if (!db.open())
    {
        QMessageBox::warning(this, tr("Unable to open database"), tr("An error occured while opening the connection: ") + db.lastError().text());
        m_form->setConnectLabel(false);
    }
    else
    {
        m_form->setConnectLabel(true);
        m_form->initializeCalculator();
        close();
    }

    QSettings settings(QCoreApplication::organizationName(), QCoreApplication::applicationName());
    settings.setValue("hostname", editHostname->text());
    settings.setValue("username", editUsername->text());
    settings.setValue("password", editPassword->text());
    settings.setValue("dbname", editDbname->text());
    settings.sync();
}

void Updater::initializeCalculator()
{
    calculator = new Calculator(this);
}

void Updater::setConnectLabel(bool ok)
{
    if (ok)
        labelConnect->setText(QString("<b><font color=green> Connected!</font></b>"));
    else
        labelConnect->setText(QString("<b><font color=red> Not connected!</font></b>"));
}

void Updater::slotAbout()
{
	About* about = new About(0);
	about->show();
}

bool Updater::event(QEvent* t_event)
{
    switch (t_event->type())
    {
        case ObjectBar::TypeId:
        {
            ObjectBar* bar = (ObjectBar*)t_event;
            
            switch (bar->GetId())
            {
                case BAR_STEP:
                {
                    progressBar->setValue(bar->GetStep());
                    return true;
                }
                case BAR_SIZE:
                {
                    progressBar->setMaximum(bar->GetSize());
                    return true;
                }
            }

            break;
        }
        case ObjectText::TypeId:
        {
            ObjectText* p_text = (ObjectText*)t_event;

            switch (p_text->GetId())
            {
                case OBJ_STATUS_LABEL:
                {
                    statusLabel->setText(p_text->GetText());
                    return true;
                }
                /*case OBJ_PLR_COUNT:
                {
                    QTableWidgetItem* item = new QTableWidgetItem(p_text->GetText());
                    tableWidget->setItem(counter, 1, item);
                    return true;
                }*/
                case OBJ_PLR_STCOUNT:
                {
                    QTableWidgetItem* item = new QTableWidgetItem(p_text->GetText());
                    tableWidget->setItem(0, counter, item);
                    counter++;
                    if (counter > 1)
                        counter = 0;
                    return true;
                }
            }

            break;
        }
    }

    return QWidget::event(t_event);
}

void Updater::beginThread(int id)
{
    for (ThreadList::iterator itr = threads.begin(); itr != threads.end(); ++itr)
        if ((*itr) && (*itr)->Done())
            delete (*itr);
        else return;

    threads.clear();

    threads.push_back(new Thread(id, calculator));
    
    for (ThreadList::iterator itr = threads.begin(); itr != threads.end(); ++itr)
        if ((*itr) && !(*itr)->Done())
            (*itr)->start();
}

void Updater::slotCalculate()
{
    buttonUpdate->setEnabled(false);
    beginThread(THREAD_CALCULATE);
}

About::About(QDialog* parent)
	: QDialog(parent)
{
	setupUi(this);
}

About::~About()
{
}
