#ifndef THREADOBJ_H
#define THREADOBJ_H

#include <iostream>
#include "Updater.h"
#include "Definitions.h"

class Calculator;

class Thread: public QThread
{
    public:
        Thread(int id, Calculator* obj) : t_id(id), t_done(false), calculator(obj) {}
        virtual void run()
        {
            switch (t_id)
            {
                case THREAD_CALCULATE:
                    calculator->flushRankPoints();
                    t_done = true;
                    break;
            }
        }
        int GetId() { return t_id; }
        bool Done() const { return t_done; }
    private:
        int t_id;
        bool t_done;

        Calculator* calculator;
};

#endif