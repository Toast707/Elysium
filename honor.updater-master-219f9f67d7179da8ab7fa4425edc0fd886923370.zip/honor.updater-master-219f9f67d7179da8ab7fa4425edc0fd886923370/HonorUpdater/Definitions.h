#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include <QString>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <cmath>
#include <list>
#include <time.h>
#include <math.h>
#include <map>
#include <iostream>
#include <fstream>

#define MIN_KILLS 25
#define HONOR_RANK_COUNT 16

enum Threads
{
    THREAD_CALCULATE    = 0,
    MAX_THREADS         = 1
};

enum TextObjects
{
    OBJ_NONE            = 0,
    OBJ_STATUS_LABEL    = 1,
    OBJ_PLR_COUNT       = 2,
    OBJ_PLR_STCOUNT     = 3,
    MAX_OBJ             = 4
};

enum ValuesType
{
    BAR_STEP            = 1,
    BAR_SIZE            = 2
};

enum Fraction
{
    NONE        = 0,
    ALLIANCE    = 1,
    HORDE       = 2
};

enum State
{
    OLD        = 0,
    NEW        = 1,
    MAX_STATE  = 2
};

enum HonorType
{
    HONORABLE_KILL    = 1,
    DISHONORABLE_KILL = 2,
    BONUS_HONOR_UNIT  = 3,
    QUEST             = 4,
    OTHER             = 5,
};

#endif