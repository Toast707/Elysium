#include "Calculator.h"
#include "Language.h"

Calculator::Calculator(Updater* form):
    m_form(form)
{
    m_form->spinBox->setValue(getDateFromDatabase());
    m_form->dateValue->setText(QString("<b>Date from database: %0</b>").arg(getDateFromDatabase()));
}

Calculator::~Calculator()
{
}

quint32 Calculator::getDateFromDatabase() const 
{
    QSqlQuery query("SELECT TO_DAYS(NOW())");
    if (query.next())
        return query.value(0).toUInt();

    return 0;
}

HonorStandingList Calculator::getStandingListBySide(quint8 side)
{
    switch (side)
    {
        case ALLIANCE: return m_allianceStandingList;
        case HORDE:    return m_hordeStandingList;
        default:       return m_allianceStandingList;
    }
}

float Calculator::getHonorStandingByPosition(quint32 position, quint8 side)
{
    HonorStandingList standingList = getStandingListBySide(side);
    quint32 pos = 1;

    for (auto itr : standingList)
    {
        if (pos == position)
            return itr.cp;
        pos++;
    }

    return 0.0f;
}

void Calculator::flushRankPoints()
{
    quint32 today = m_form->spinBox->value();

    QSqlQuery("UPDATE `characters` SET `honor_standing` = '0'");

    loadStandingList(today - 7);

    distributeRankPoints(ALLIANCE);
    distributeRankPoints(HORDE);

    QApplication::postEvent(m_form, new ObjectText(StatusText[18], OBJ_STATUS_LABEL));
    QSqlQuery selQuery(QString("SELECT `guid`, `type`, COUNT(*) AS `kills` FROM `character_honor` WHERE `date` < '%0' AND victim_type > 0 GROUP BY `guid`, `type`").arg(today - 7));

    quint32 step = 0;

    QApplication::postEvent(m_form, new ObjectBar(selQuery.size(), BAR_SIZE));
    QApplication::postEvent(m_form, new ObjectBar(step, BAR_STEP));
    while (selQuery.next())
    {
        step++;
        quint32 guid   = selQuery.value(0).toInt();
        quint8  type   = selQuery.value(1).toInt();
        quint32 kills  = selQuery.value(2).toInt();

        if (type == HONORABLE_KILL)
            QSqlQuery(QString("UPDATE characters SET stored_honorable_kills = stored_honorable_kills + %0 WHERE guid = %1").arg(kills).arg(guid));
        else if (type == DISHONORABLE_KILL)
            QSqlQuery(QString("UPDATE characters SET stored_dishonorable_kills = stored_dishonorable_kills + %0 WHERE guid = %1").arg(kills).arg(guid));

        QApplication::postEvent(m_form, new ObjectBar(step, BAR_STEP));
    }

    // temp -10% rp if not in standing
    QSqlQuery("UPDATE `characters` SET `honor_rank_points` = `honor_rank_points` * '0.9' WHERE `honor_standing` = 0 AND `honor_rank_points` > 0");

    // cleanin ALL cp before dateTop
    QSqlQuery(QString("DELETE FROM `character_honor` WHERE `date` < %0").arg(today - 7));

    // truncate static table
    QSqlQuery("TRUNCATE TABLE `character_honor_static`");

    QApplication::postEvent(m_form, new ObjectText(StatusText[0], OBJ_STATUS_LABEL));
    m_form->buttonUpdate->setEnabled(true);
}

void Calculator::distributeRankPoints(quint8 team)
{
    HonorStandingList slist = getStandingListBySide(team);

    if (slist.empty())
        return;

    HonorScores scores = generateScores(slist,team);

    quint32 standing = 1;

    if (team == ALLIANCE)
        QApplication::postEvent(m_form, new ObjectText(StatusText[15], OBJ_STATUS_LABEL));
    else
        QApplication::postEvent(m_form, new ObjectText(StatusText[16], OBJ_STATUS_LABEL));

    quint32 size = slist.size();
    QString sizeStr = QString("%1").arg(size);
    QApplication::postEvent(m_form, new ObjectText(sizeStr, OBJ_PLR_STCOUNT));
    QApplication::postEvent(m_form, new ObjectBar(size, BAR_SIZE));

    quint32 step = 0;
    QApplication::postEvent(m_form, new ObjectBar(step, BAR_STEP));

    for (auto itr : slist)
    {
        QSqlQuery selQuery(QString("SELECT `honor_rank_points`, `level` FROM `characters` WHERE `guid` = %0").arg(itr.guid));

        if (selQuery.next())
        {
            float rpEarning = calculateRpEarning(itr.cp, scores);
            itr.rp          = calculateRpDecay(rpEarning, selQuery.value(0).toFloat());
            quint8 level    = selQuery.value(1).toUInt();

            if (level < 30)
                level = 1;
            else if (level > 60)
                level = 32;
            else
                level = level - 28;

            if (itr.rp > levelCapRP[level])
                itr.rp = levelCapRP[level];

            QSqlQuery(QString("UPDATE `characters` SET `honor_standing` = '%0', `honor_rank_points` = '%1' WHERE `guid` = '%2'").arg(standing).arg(int(itr.rp)).arg(itr.guid));
            standing++;
        }

        step++;
        QApplication::postEvent(m_form, new ObjectBar(step, BAR_STEP));
    }
    QApplication::postEvent(m_form, new ObjectText(StatusText[0], OBJ_STATUS_LABEL));
}

bool honorLessThan(const HonorStanding &stand1, const HonorStanding &stand2)
{
    return stand1.cp > stand2.cp;
}

void Calculator::loadStandingList(quint32 dateBegin)
{
    HonorStanding standing;

    // needed for reload case
    m_allianceStandingList.clear();
    m_hordeStandingList.clear();

    // this query create an ordered standing list
    QSqlQuery selQuery(QString("SELECT `guid`, SUM(`honor`) as `honor_sum` FROM `character_honor` WHERE `type` != '%0' AND `date` > '%1' GROUP BY `guid` ORDER BY `honor_sum` DESC")
              .arg(DISHONORABLE_KILL).arg(dateBegin));

    quint32 size = selQuery.size();
    quint32 step = 0;
    QApplication::postEvent(m_form, new ObjectBar(size, BAR_SIZE));
    QApplication::postEvent(m_form, new ObjectBar(step, BAR_STEP));
    QApplication::postEvent(m_form, new ObjectText(StatusText[17], OBJ_STATUS_LABEL));

    while (selQuery.next())
    {
        quint32 guid  = selQuery.value(0).toInt();
        quint32 kills = 0;
        quint8 side = getPlayerTeamByGuid(guid);

        // kills count with victim setted ( not zero value )
        QSqlQuery sqlQueryCount(QString("SELECT COUNT(*) FROM `character_honor` WHERE `guid` = '%0' AND `type` = '%1' AND `date` > '%2'")
                                .arg(guid).arg(HONORABLE_KILL).arg(dateBegin));
        if (sqlQueryCount.next())
            kills = sqlQueryCount.value(0).toInt();

        if (kills >= MIN_KILLS)
        {
            standing.guid = guid;
            standing.cp = selQuery.value(1).toInt();
            standing.honorKills = kills;

            if (side == ALLIANCE)
                m_allianceStandingList.push_back(standing);
            else if (side == HORDE)
                m_hordeStandingList.push_back(standing);
        }

        step++;
        QApplication::postEvent(m_form, new ObjectBar(step, BAR_STEP));
    }

    // make sure all things are sorted
    qSort(m_allianceStandingList.begin(), m_allianceStandingList.end(), honorLessThan);
    qSort(m_hordeStandingList.begin(), m_hordeStandingList.end(), honorLessThan);

    QApplication::postEvent(m_form, new ObjectText(StatusText[0], OBJ_STATUS_LABEL));
}

HonorScores Calculator::generateScores(HonorStandingList standingList, quint8 team)
{
    HonorScores sc;

    // initialize the breakpoint values
    sc.BRK[13] = 0.003f;
    sc.BRK[12] = 0.008f;
    sc.BRK[11] = 0.020f;
    sc.BRK[10] = 0.035f;
    sc.BRK[ 9] = 0.060f;
    sc.BRK[ 8] = 0.100f;
    sc.BRK[ 7] = 0.159f;
    sc.BRK[ 6] = 0.228f;
    sc.BRK[ 5] = 0.327f;
    sc.BRK[ 4] = 0.436f;
    sc.BRK[ 3] = 0.566f;
    sc.BRK[ 2] = 0.697f;
    sc.BRK[ 1] = 0.845f;
    sc.BRK[ 0] = 1.000f;

    // get the WS scores at the top of each break point
    for (quint8 group = 0; group < 14; group++)
        sc.BRK[group] = floor((sc.BRK[group] * standingList.size()) + 0.5f);

    // initialize RP array
    // set the low point
    sc.FY[ 0] = 0;

    // the Y values for each breakpoint are fixed
    sc.FY[ 1] = 400;
    for (quint8 i = 2; i <= 13; i++)
        sc.FY[i] = (i - 1) * 1000;

    // and finally
    sc.FY[14] = 13000;   // ... gets 13000 RP

    // the X values for each breakpoint are found from the CP scores
    // of the players around that point in the WS scores
    //HonorStanding *tempSt;
    float honor;
    float temp_honor;

    // initialize CP array
    sc.FX[ 0] = 0;

    bool top = false;
    for (quint8 i = 1; i <= 13; i++)
    {
        honor = 0.0f;
        temp_honor = 0.0f;
        temp_honor = getHonorStandingByPosition(sc.BRK[i], team);

        if (temp_honor)
        {
            honor += temp_honor;
            temp_honor = 0.0f;
            temp_honor = getHonorStandingByPosition(sc.BRK[i] + 1, team);

            if (temp_honor)
                honor += temp_honor;
        }

        sc.FX[i] = honor ? honor / 2 : 0;

        if (!top && !honor)
        {
            // top scorer
            sc.FX[i] = sc.FX[i - 1] ? standingList.begin()->cp : 0;
            top = true;
        }
    }

    // set the high point if FX full filled before
    sc.FX[14] = !top ? standingList.begin()->cp : 0;   // top scorer

    if (sc.BRK[13] == 1)
        sc.FX[13] = getHonorStandingByPosition(sc.BRK[12], team);

    return sc;
}

float Calculator::calculateRpEarning(float CP, HonorScores sc)
{
    // search the function for the two points that bound the given CP
    quint8 i = 0;
    while (i < 14 && sc.BRK[i] > 0 && sc.FX[i] <= CP)
        i++;

    // we now have i such that FX[i] > CP >= FX[i-1]
    // so interpolate
    if (sc.FX[i] > CP && CP >= sc.FX[i - 1])
        return (sc.FY[i] - sc.FY[i - 1]) * (CP - sc.FX[i - 1]) / (sc.FX[i] - sc.FX[i - 1]) + sc.FY[i - 1];

    return sc.FY[i];
}

float Calculator::calculateRpDecay(float rpEarning, float RP)
{
    float Decay = floor((0.2f * RP) + 0.5f);
    float Delta = rpEarning - Decay;

    if (Delta < 0)
        Delta = Delta / 2;

    if (Delta < -2500)
        Delta = -2500;

    return RP + Delta;
}

quint8 Calculator::getPlayerTeamByGuid(quint32 guid)
{
    QString selStr;
    QSqlQuery selQuery;
    quint8 race;
    selStr = QString("SELECT race FROM characters WHERE guid = %0").arg(guid);
    if (selQuery.exec(selStr))
    {
        selQuery.next();
        race = selQuery.value(0).toInt();
        selQuery.clear();
    }

    if (race == 1 || race == 3 || race == 4 || race == 7)
        return ALLIANCE;
    else
        return HORDE;
}
