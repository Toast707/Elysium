#ifndef HONORUPDATER_H
#define HONORUPDATER_H

#include <QApplication>
#include <QtGui>
#include <QMainWindow>
#include <QDialog>
#include <QPushButton>
#include <QLabel>
#include <QtSql>
#include <QTableView>
#include <QItemSelectionModel>
#include <QStandardItemModel>
#include <QEvent>
#include <QSettings>
#include "ui_Connect.h"
#include "ui_Updater.h"
#include "ui_AboutDialog.h"
#include "Calculator.h"
#include "Definitions.h"

class Updater;
class Calculator;
class Thread;

using namespace std;

class Connect : public QDialog, public Ui::ConnectClass
{
    Q_OBJECT

    public:
        Connect(Updater* form);
        ~Connect();

    private slots:
        void slotConnect();

    private:
        Ui::ConnectClass ui;
        Updater* m_form;
};

class About : public QDialog, public Ui::AboutDialog
{
    Q_OBJECT
public:
	About(QDialog* parent = 0);
	~About();

private:
    Ui::AboutDialog ui;
};

class Updater : public QMainWindow, public Ui::UpdaterClass
{
    Q_OBJECT

    public:
        Updater(QMainWindow* parent = 0);
        ~Updater();

        bool event(QEvent* e);
        void beginThread(int id);
        void setConnectLabel(bool ok);
        void initializeCalculator();
        
    private slots:
        void slotConnectPopup();
        void slotCalculate();
	    void slotAbout();

    private:
        Ui::UpdaterClass ui;
        Calculator* calculator;

        QAction* actionConnect;
        QAction* actionAbout;
        QLabel* labelConnect;

        typedef list<Thread*> ThreadList;
        ThreadList threads;

        quint8 counter;
};

class ObjectBar : public QEvent
{
public:
    enum 
    {
        TypeId = QEvent::User + 1
    };
    ObjectBar(int value, int id)
        : QEvent(QEvent::Type(ObjectBar::TypeId)), bar_step(value), bar_size(value), op_id(id) {}

    int GetId() const { return op_id; }
    int GetStep() const { return bar_step; }
    int GetSize() const { return bar_size; }
private:
    int bar_step;
    int bar_size; 
    int op_id; 
};

class ObjectText : public QEvent
{
public:
    enum { TypeId = QEvent::User + 2 };
    ObjectText(QString txt, int id)
        : QEvent(QEvent::Type(ObjectText::TypeId)), curr_text(txt), obj_id(id) {}

    QString GetText() const { return curr_text; }
    int GetId() const { return obj_id; }
private:
    QString curr_text;
    int obj_id;
};

#endif // HONORUPDATER_H