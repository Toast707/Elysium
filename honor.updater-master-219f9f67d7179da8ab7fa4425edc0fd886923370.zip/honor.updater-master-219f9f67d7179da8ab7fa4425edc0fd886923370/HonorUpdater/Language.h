#ifndef LANGUAGE_H
#define LANGUAGE_H

#include <QString>

QString StatusText[] = 
{
    QString("Done!"),                                       // 0
    QString("Failed!"),                                     // 1
    QString("Get Alliance killers count..."),               // 2
    QString("Get Horde killers count..."),                  // 3
    QString("Get players for standing..."),                 // 4
    QString("Unset Alliance Standing..."),                  // 5
    QString("Unset Horde Standing..."),                     // 6
    QString("Select Fraction or run automatic calculate!"), // 7
    QString("Update Alliance Weekly Standing..."),          // 8
    QString("Update Horde Weekly Standing..."),             // 9
    QString("Calculate Breakpoints table..."),              // 10
    QString("Calculate Rank Points..."),                    // 11
    QString("Update `characters` table..."),                // 12
    QString("Get old kills..."),                            // 13
    QString("Update lifetime kills in `characters`..."),    // 14
    // ----------------------------------------------------------
    QString("Distribute Alliance rank points..."),           // 15
    QString("Distribute Horde rank points..."),              // 16
    QString("Load standing lists..."),                       // 17
    QString("Flush rank points...")                          // 18
};

#endif