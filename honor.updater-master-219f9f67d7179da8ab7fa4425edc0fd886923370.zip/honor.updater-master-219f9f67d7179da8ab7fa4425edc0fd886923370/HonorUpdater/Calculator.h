#ifndef CALCOBJECT_H
#define CALCOBJECT_H

#include "Updater.h"
#include "Definitions.h"

class Updater;

struct PlayerInfo
{
    QString name;
    quint32 level;
    quint32 kills;
    quint32 cp;
    quint32 standing[2];
    quint32 hr[2];
    quint32 rp[2];
};

struct HonorScores
{
    float FX[15];
    float FY[15];
    float BRK[14];


};

static quint32 levelCapRP[33] =
{
    0,      // none
    6500,   // 1-29
    7150,   // 30
    8125,   // 31
    9100,   // 32
    10075,  // 33
    11050,  // 34
    12025,  // 35
    13325,  // 36
    14625,  // 37
    15925,  // 38
    17225,  // 39
    18850,  // 40
    20475,  // 41
    22100,  // 42
    23725,  // 43
    26000,  // 44
    28275,  // 45
    30550,  // 46
    32825,  // 47
    35100,  // 48
    37375,  // 49
    39650,  // 50
    41925,  // 51
    44200,  // 52
    46800,  // 53
    49400,  // 54
    52000,  // 55
    54600,  // 56
    57200,  // 57
    59800,  // 58
    62400,  // 59
    65000   // 60
};

class HonorStanding
{
    public:
        HonorStanding()
        {
            guid        = 0;
            honorKills  = 0;
            cp          = 0;
            rp          = 0;
        }

        quint32 guid;
        quint32 honorKills;
        float cp;
        float rp;

        // create the standing order
        bool operator < (const HonorStanding& rhs)
        {
            return cp > rhs.cp;
        }
};

typedef QList<HonorStanding> HonorStandingList;

class Calculator
{
    public:
        Calculator(Updater* form = NULL);
        ~Calculator();

        quint32 getDateFromDatabase() const;
        float getHonorStandingByPosition(quint32 position, quint8 side);
        HonorStandingList getStandingListBySide(quint8 side);
        void flushRankPoints();
        void distributeRankPoints(quint8 team);
        void loadStandingList(quint32 dateBegin);
        HonorScores generateScores(HonorStandingList standingList, quint8 team);
        float calculateRpEarning(float CP, HonorScores sc);
        float calculateRpDecay(float rpEarning, float RP);
        quint8 getPlayerTeamByGuid(quint32 guid);

    private:
        Updater* m_form;

        int m_inStanding;
        int m_oldKills;

        HonorStandingList m_hordeStandingList;
        HonorStandingList m_allianceStandingList;

        QList<PlayerInfo> m_alliancePlayers;
        QList<PlayerInfo> m_hordePlayers;

        HonorScores m_scores;
};

#endif
