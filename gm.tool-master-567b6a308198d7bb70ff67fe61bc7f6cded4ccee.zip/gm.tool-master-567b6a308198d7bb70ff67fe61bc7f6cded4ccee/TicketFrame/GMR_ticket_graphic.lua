if not GMR then 
	GMR = {} 
end

function GMR.CreateTicketFrame()
	local f = CreateFrame("Frame", "TicketTable", UIParent)
	GMR.MakeMoovable(f)
	--f:SetFrameStrata("HIGH")
	f:SetWidth(1024)
	f:SetHeight(768)
	f:SetBackdrop( { 
  		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", 
  		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", 
  		tile = true, tileSize = 32, edgeSize = 32, 
  		insets = { left = 11, right = 12, top = 12, bottom = 11 }})
	f:SetPoint("CENTER", UIParent, "CENTER")
	GMR.AddCloseButton(f)
	f:Hide()
	return f
end

GMR.CurrentTicketTableElements = {}

GMR.ButtonChilds = {}

function GMR.UpdateTicketTableElement(Button, value, text_update)
	
	if not GMR.ButtonChilds[Button] then
		GMR.ButtonChilds[Button] = {}
	end

	for key, val in pairs(GMR.ButtonChilds[Button]) do
		val:ClearAllPoints()
		val:Hide()
	end
	local elem_l
	if text_update then
		offset = 10
		for iter = 1, getn(text_update) do			
			t = GMR.CreateTitle(Button:GetName().."_"..iter, offset, 0, Button, "")
			GMR.ButtonChilds[Button][t:GetName()] = t
			t:SetPoint("LEFT", Button, "LEFT", offset, 0)
			t:SetText(text_update[iter])
			elem_l = GMR.TicketButtonText.elem_length[iter]
			offset = 10 + elem_l + 10*iter
			t:Show()
		end		
		local n = getn(GMR.TicketButtonText.elem_length)
		local max_l = 10 + GMR.TicketButtonText.elem_length[n] + 10*n
		Button:SetWidth(max(GMR.Tables["Ticket"]:GetWidth(), max_l))
	end	

	Button:SetScript("OnEnter", 
		function()
		    GameTooltip:ClearAllPoints()
		    GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		    if GMR.TicketData[GMR.CurrentTicketTableElements[value]] and GMR.TicketData[GMR.CurrentTicketTableElements[value]].num then
			    GameTooltip:AddLine("TIcket Data:")
			    GameTooltip:AddLine("Creator: "..GMR.TicketData[GMR.CurrentTicketTableElements[value]].creator)
			    GameTooltip:AddLine("Created: "..GMR.TicketData[GMR.CurrentTicketTableElements[value]].created)
			    if GMR.TicketData[GMR.CurrentTicketTableElements[value]].changed then
					GameTooltip:AddLine("Changed: "..GMR.TicketData[GMR.CurrentTicketTableElements[value]].changed)
				end
			    if GMR.TicketData[GMR.CurrentTicketTableElements[value]].assigned then
			    	GameTooltip:AddLine("Assigned: "..GMR.TicketData[GMR.CurrentTicketTableElements[value]].assigned)
			    end
			    GameTooltip:AddLine("Ticket id: "..GMR.TicketData[GMR.CurrentTicketTableElements[value]].num)
			end
			GameTooltip:Show();
		end
	)
	Button:SetScript("OnClick", 
		function()
		    if not GMR.BlockTicketLoad then
		       	GMR.LoadTicket(GMR.CurrentTicketTableElements[value]);
		       	GMR.BlockTicketLoad = true
		    end
	    end
	)
	if MouseIsOver(Button) then
		Button:GetScript("OnLeave")()
		Button:GetScript("OnEnter")()
	end
	if not text_update then
		SLib.CallStack.NewCall(GMR.UpdateButtonsText, 0.01, value)
	end
end

function GMR.CreateTicketTableElemets(number)
	local f, t
	local result = {}
	for i = 1, number do
		f = CreateFrame("Button", "ButtonTicketTable"..i, nil, "CommandButtonTemplate")
		--f:SetFrameStrata("HIGH")
		f:SetHeight(20)
		f:SetWidth(200)
		f:SetScript("OnLeave", 
			function()
		       GameTooltip:Hide();
		    end
		)		
		t = f:GetFontString()
		t:SetPoint("LEFT", f, "LEFT", 15, 0)
		GMR.Buttons["ButtonTicketTable"..i] = f
		result[getn(result)+1] = f
	end	
	return result
end

function GMR.SortTicketTable()
--[[	local mas = GMR.CurrentTicketTableElements
	if mas then
		local access = GMR.CheckButtons["accesssortTicketTable"]:GetChecked()
		if not access then
			function sort_rule(a, b)
				return a < b
			end
		else
			function sort_rule(a, b)
				if tonumber(GMR_command_data[a][1]) == tonumber(GMR_command_data[b][1]) then
					return a < b
				else
					return (tonumber(GMR_command_data[a][1]) < tonumber(GMR_command_data[b][1]))
				end
			end
		end
		table.sort(mas, sort_rule)
	end]]
end

function GMR.FindInTicketTable(str)
	local left_v = GMR.EditNumBoxes["TicketLeftBound"]:GetText()
	local str_find
	if left_v == "" then
		left_v = "1"
	end
	local right_v = GMR.EditNumBoxes["TicketRightBound"]:GetText()
	if right_v == "" then
		right_v = tostring(GMR.MAX_TICKETS)
	end
	GMR.CurrentTicketTableElements = {}
	local iter = 1
	for i = tonumber(left_v), tonumber(right_v) do
		if GMR.TicketData[i] then
			if not GMR.TicketData[i].created then
				GMR.Print("index "..i)
				GMR.Print("creator ")
				GMR.Print(GMR.TicketData[i].creator)
				GMR.Print("created ")
				GMR.Print(GMR.TicketData[i].created)
				GMR.Print("changed ")
				GMR.Print(GMR.TicketData[i].changed)
				GMR.Print("assigned ")
				GMR.Print(GMR.TicketData[i].assigned)
			end
			str_find = GMR.TicketData[i].creator.." "..GMR.TicketData[i].created..GMR.TicketData[i].assigned
			local name = GMR.TicketData[i].creator
			if GMR.CheckButtons["Characters scan type"]:GetChecked() and GMR.CharacterBase[name] then
				for k = 1, getn(GMR.CharacterBase[name]) do
					str_find =  str_find..GMR.CharacterBase[name][k]
				end
			end
			if string.find(string.lower(str_find), str) then
				GMR.CurrentTicketTableElements[iter] = i
				iter = iter + 1
			end
		end
	end
	return getn(GMR.CurrentTicketTableElements)
end

GMR.TICKET_BUTTONS_NUM = 20

GMR.MAX_TICKETS = 1000000

GMR.TicketScanType = "online"

function GMR.AddTicketNumBoxes()
	local nb1, nb2, nb3
 	nb1 = GMR.CreateEditNumberBox("TicketLeftBound", 10, -35, GMR.Tables["Ticket"], 50, 20, "BOTTOMLEFT", "TOPLEFT", {"Lower bound of searching tickets", "Tips: mousewheel enabled"})
 	nb2 = GMR.CreateEditNumberBox("TicketRightBound", -10, -35, GMR.Tables["Ticket"], 50, 20, "BOTTOMRIGHT", "TOPRIGHT", {"Upper bound of searching tickets", "Tips: mousewheel enabled"})
 	nb3 = GMR.CreateEditNumberBox("TicketCurrent", 0, -35, GMR.Tables["Ticket"], 50, 20, "BOTTOM", "TOP", {"Go to ticket", "Tips: mousewheel enabled"})
 	nb1:SetText("1")
 	nb2:SetText(GMR.MAX_TICKETS)
	nb1:SetScript("OnMouseWheel", 
		function()
			local temp_t = this:GetText()
			if not string.find(temp_t, "%d+") then
				temp_t = "1"
			end
			temp_t = tonumber(temp_t)
			temp_t = temp_t+arg1
			if temp_t < 1 then
				temp_t = GMR.MAX_TICKETS
			elseif temp_t > GMR.MAX_TICKETS then
				temp_t = 1
			end
			this:SetText(temp_t)
		end
	)
	nb2:SetScript("OnMouseWheel", 
		function()
			local temp_t = this:GetText()
			if not string.find(temp_t, "%d+") then
				temp_t = "1"
			end
			temp_t = tonumber(temp_t)
			temp_t = temp_t+arg1
			if temp_t < 1 then
				temp_t = GMR.MAX_TICKETS
			elseif temp_t > GMR.MAX_TICKETS then
				temp_t = 1
			end
			this:SetText(temp_t)
		end
	)
	nb3:SetScript("OnMouseWheel", 
		function()
			local temp_t = this:GetText()
			if not string.find(temp_t, "%d+") then
				temp_t = "1"
			end
			temp_t = tonumber(temp_t)
			temp_t = temp_t+arg1
			if temp_t < 1 then
				temp_t = GMR.MAX_TICKETS
			elseif temp_t > GMR.MAX_TICKETS then
				temp_t = 1
			end
			this:SetText(temp_t)
		end
	)
	nb1:SetScript("OnTextChanged",
		function()
			local temp_t = this:GetText()
			temp_t = gsub(temp_t, "([^0-9])", "")
			if temp_t ~= "" then
				temp_t = tonumber(temp_t)
				if temp_t < 1 then
					temp_t = 1
				elseif temp_t > GMR.MAX_TICKETS then
					temp_t = GMR.MAX_TICKETS 
				end
			end
			this:SetText(temp_t)
			GMR.Tables._Update("Ticket")
		end
	)
	nb2:SetScript("OnTextChanged",
		function()
			local temp_t = this:GetText()
			temp_t = gsub(temp_t, "([^0-9])", "")
			if temp_t ~= "" then
				temp_t = tonumber(temp_t)
				if temp_t < 1 then
					temp_t = 1
				elseif temp_t > GMR.MAX_TICKETS then
					temp_t = GMR.MAX_TICKETS 
				end
			end
			this:SetText(temp_t)
			GMR.Tables._Update("Ticket")
		end
	)
	nb3:SetScript("OnTextChanged",
		function()
			local temp_t = this:GetText()
			temp_t = gsub(temp_t, "([^0-9])", "")
			if temp_t ~= "" then
				temp_t = tonumber(temp_t)
				if temp_t < 1 then
					temp_t = 1
				elseif temp_t > GMR.MAX_TICKETS then
					temp_t = GMR.MAX_TICKETS 
				end
			end
			this:SetText(temp_t)
			GMR.Tables._Update("Ticket", tonumber(this:GetText()))
		end
	)
end

function GMR.SetDropDownFrameWidth(frame, width)
	frame:SetWidth(width)
	local t = getglobal(frame:GetName().."Middle")
	t:SetWidth(width)
end

function GMR.SaveTicletTemplateStatusQuo(name)
	GMR.Buttons[name.."Save"]:Show()
	GMR.EditBoxes[name.."TemplateName"]:Hide()
	GMR.EditBoxes[name.."TemplateGroup"]:Hide()
end

function GMR.CreateSaveTicketTemplateGraphic(name, parent, x, y)
	local b1, e1, e2, t1, t2, e1s1, e2s2, e1s2, e2s1
	b1 = GMR.CreateButton(name.."Save",  x, y, 150, 30, parent, "TOPLEFT", "TOPLEFT", "Save as Template", {"Save "..name.." as template.", "Just click here"})
	b1:SetScript("OnClick", 
		function()
			this:Hide()
			GMR.EditBoxes[name.."TemplateName"]:Show()
			GMR.EditBoxes[name.."TemplateGroup"]:Show()
		end
	)
	e1 = GMR.CreateEditBox(name.."TemplateName", x + 60, y-5, parent, 100, 25, "TOPLEFT", "TOPLEFT", {"Write template name", "When you'll ready press Enter"})
	e1:SetScript("OnEnterPressed", 
		function()
			if this:GetText() ~= "" then
				GMR.SaveTicketTemplate(this:GetText(), GMR.EditBoxes[name.."TemplateGroup"]:GetText(), GMR.EditScrollBoxes[name]:GetText(), name)
				this:Hide()
				GMR.EditBoxes[name.."TemplateGroup"]:Hide()
				GMR.Tables._Update("TicketTemplate"..name)
				GMR.Buttons[name.."Save"]:Show()
			end
		end
	)
	t1 = GMR.CreateTitle(name.."TemplateName", -12, 0, e1, "Name:", "RIGHT", "LEFT")
	e2 = GMR.CreateEditBox(name.."TemplateGroup", x + 60, y+15, parent, 100, 25, "TOPLEFT", "TOPLEFT", {"Write template group", "(templates will be sorted by groups)\n When you'll ready press Enter"})
	e2:SetScript("OnEnterPressed", 
		function()
			if GMR.EditBoxes[name.."TemplateName"]:GetText() ~= "" then
				GMR.SaveTicketTemplate(GMR.EditBoxes[name.."TemplateName"]:GetText(), this:GetText(), GMR.EditScrollBoxes[name]:GetText(), name)
				this:Hide()
				GMR.EditBoxes[name.."TemplateName"]:Hide()
				GMR.Tables._Update("TicketTemplate"..name)
				GMR.Buttons[name.."Save"]:Show()
			end
		end
	)
	t2 = GMR.CreateTitle(name.."TemplateGroup", -12, 0, e2, "Group:", "RIGHT", "LEFT")
	e1:Hide()
	e2:Hide()

	e1s1 = e1:GetScript("OnEnter")
	e1:SetScript("OnShow", function() SLib.CallStack.NewCall(GMR.SaveTicletTemplateStatusQuo, 7, name) end)
	e1:SetScript("OnTextChanged", function() SLib.CallStack.NewCall(GMR.SaveTicletTemplateStatusQuo, 7, name) end)
	e1:SetScript("OnEnter", function() e1s1() SLib.CallStack.NewCall(GMR.SaveTicletTemplateStatusQuo, 7, name) end)

	e2s1 = e2:GetScript("OnEnter")
	e2:SetScript("OnShow", function() SLib.CallStack.NewCall(GMR.SaveTicletTemplateStatusQuo, 7, name) end)
	e2:SetScript("OnTextChanged", function() SLib.CallStack.NewCall(GMR.SaveTicletTemplateStatusQuo, 7, name) end)
	e2:SetScript("OnEnter", function() e2s1() SLib.CallStack.NewCall(GMR.SaveTicletTemplateStatusQuo, 7, name) end)
	return e1, e2
end

function GMR.CreateTicketTemplate(name, parent, width, point, rel_point, x, y)
	GMR.BuildTicketTemplateFrame(name)
	local b = CreateFrame("Frame", "GMR_"..name, GMR.TicketFrame, "GMRDropDown")
	GMR.SetDropDownFrameWidth(b, width)
	b:SetPoint(point, parent, rel_point, x - 20, -y)
	b = getglobal(b:GetName().."Button")
	b:SetScript("OnClick", 
		function()
			if GMR.Tables["TicketTemplate"..name]:IsShown() then
				GMR.Tables["TicketTemplate"..name]:Hide()
			else
				GMR.CurrentTicketTemplate = name
				GMR.Tables["TicketTemplate"..name]:SetPoint("TOPLEFT", GMR.TicketFrame, "TOPLEFT", this:GetParent():GetLeft()-GMR.TicketFrame:GetLeft() + 20, this:GetParent():GetTop() - GMR.TicketFrame:GetTop() - 50)
				GMR.Tables["TicketTemplate"..name]:Show()
				GMR.Tables._Update("TicketTemplate"..name)
			end
		end
	)
	return b
end

function GMR.FillTicketFrame()
	local b, b1, b2, b3, b4, b5, b6, e1, e2, e3, t_b, s, s1, b7, b8, b9, num_l, char_l
	local offs_x = GMR.Tables["Ticket"]:GetWidth() + 75
	local offs_y = 50

	local t = GMR.CreateTitle("TotalTickets", 0, -60, GMR.Tables["Ticket"], "Total Tickets: "..GMR.MAX_TICKETS, "BOTTOM", "TOP")
 	t:Show()

	b = GMR.CreateButton("ScanTicketCharacter",  0, -75, 130, 30, GMR.Tables["Ticket"], "BOTTOM", "TOP", "Scan Char", "Get full info about ticket's creator.")
	b:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.creator then 
				GMR.ScanTarget(GMR.CurrentTicketInfo.creator)
			end
		end
	)

	b9 = GMR.CreateButton("RefreshTickets",  0, 460, 130, 30, GMR.Tables["Ticket"], "BOTTOM", "TOP", "Refresh", "You may refresh ticket data (auto refresh every 2 minutes.")
	b9:SetScript("OnClick",
		function()
			GMR.UpdateMaxTickets()
		end
	)

	b7 = GMR.CreateButton("CloseTicket",  offs_x, offs_y-35, 130, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Close", "Close this ticket")
	b7:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.num then 
				GMR.SendCommandSafe(".ticket close "..GMR.CurrentTicketInfo.num, "ticket close")
				GMR.Print(SLib.GetRandomColor().."Ticket "..GMR.CurrentTicketInfo.num.." closed and archived.".."\124r")
			end
		end
	)

	char_l = GMR.CreateTitle("CurrentTicketCreator", offs_x+130+20+130+10, offs_y-33, GMR.TicketFrame, "Character: ", "TOPLEFT", "TOPLEFT")
	num_l = GMR.CreateTitle("CurrentTicketNum", offs_x+130+20+130+10, offs_y-20, GMR.TicketFrame, "Ticket num: ", "TOPLEFT", "TOPLEFT")

	b8 = GMR.CreateButton("GotoTicketerCreator",  offs_x+130+20, offs_y-35, 130, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Go to player", "Click and teleport to ticket creator")
	b8:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.creator then 
				GMR.SendCommandSafe(".goname "..GMR.CurrentTicketInfo.creator, "goname")
			end
		end
	)

	GMR.CreateEditScrollBox("TicketReportText", offs_x, offs_y, GMR.TicketFrame, 400, 100, "TOPLEFT", "TOPLEFT", _, true)
	

	t_b = GMR.CreateTicketTemplate("GMnames", GMR.TicketFrame, 100, "TOPLEFT", "TOPLEFT", offs_x + 300, offs_y + 100 + 15)
	GMR_GMnames:SetScript("OnShow", function() SLib.CallStack.NewCall(GMR.ShowFrame, 7,  GMR.EditBoxes["GMnames"]) SLib.CallStack.NewCall(GMR.HideFrame, 7, GMR_GMnames) end)
	s = t_b:GetScript("OnClick")
	t_b:SetScript("OnClick", function() 
		s()
		SLib.CallStack.NewCall(GMR.ShowFrame, 7,  GMR.EditBoxes["GMnames"])
		SLib.CallStack.NewCall(GMR.HideFrame, 7, GMR_GMnames)
	end)
	GMR_GMnames:Hide()

	local temp_tab = GMR.Tables["TicketTemplateGMnames"]
	s1 = temp_tab:GetScript("OnHide")
	temp_tab:SetScript("OnHide", function() GMR.EditBoxes["GMnames"]:SetText(GMR_GMnamesText:GetText() or "") GMR_GMnames:Hide() GMR.EditBoxes["GMnames"]:Show() end)

	b5 = GMR.CreateButton("AssignTicket",  offs_x, offs_y + 100+ 15, 130, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Assign", {"Give this ticket to anybody.", " If textbox empty - assign to yourself."})
	b5:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.num then 
				SendChatMessage(".ticket unassign "..GMR.CurrentTicketInfo.num, "GUILD")
				local assigned_person = GMR.EditBoxes["GMnames"]:GetText()
				if assigned_person == "" then assigned_person = UnitName("player") end
				SendChatMessage(".ticket assign "..GMR.CurrentTicketInfo.num.." "..assigned_person, "GUILD")
				if assigned_person == UnitName("player") then GMR.Print(SLib.GetRandomColor().."Assigned to "..assigned_person.."\124r") end
			end
		end
	)

	e3 = GMR.CreateEditBox("GMnames", offs_x + 300, offs_y + 100 + 15, GMR.TicketFrame, 100, 25, "TOPLEFT", "TOPLEFT", "Use enter to show select mode")
	e3:SetScript("OnEnterPressed", function() GMR_GMnames:Show() this:Hide() end)

	e1, e2 = GMR.CreateSaveTicketTemplateGraphic("GMnames", GMR.TicketFrame, offs_x + 135, offs_y + 100 + 15)
	e1:SetScript("OnEnterPressed", 
		function()
			local name = "GMnames"
			if this:GetText() ~= "" then
				GMR.SaveTicketTemplate(this:GetText(), GMR.EditBoxes[name.."TemplateGroup"]:GetText(), GMR.EditBoxes["GMnames"]:GetText(), name)
				this:Hide()
				GMR.EditBoxes[name.."TemplateGroup"]:Hide()
				GMR.Tables._Update("TicketTemplate"..name)
				GMR.Buttons[name.."Save"]:Show()
			end
		end
	)
	e2:SetScript("OnEnterPressed", 
		function()
			local name = "GMnames"
			if GMR.EditBoxes[name.."TemplateName"]:GetText() ~= "" then
				GMR.SaveTicketTemplate(GMR.EditBoxes[name.."TemplateName"]:GetText(), this:GetText(), GMR.EditBoxes["GMnames"]:GetText(), name)
				this:Hide()
				GMR.EditBoxes[name.."TemplateName"]:Hide()
				GMR.Tables._Update("TicketTemplate"..name)
				GMR.Buttons[name.."Save"]:Show()
			end
		end
	)

	GMR.CreateTicketTemplate("TicketMailAnswer", GMR.TicketFrame, 390, "TOPLEFT", "TOPLEFT", offs_x, offs_y + 300 + 50)
	GMR.CreateEditScrollBox("TicketMailAnswer", offs_x, offs_y + 350 + 50, GMR.TicketFrame, 400, 100, "TOPLEFT", "TOPLEFT")

	b1 = GMR.CreateButton("EscalateTicket",  offs_x, offs_y + 300 + 15, 130, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Escalate to Rank "..min(4, (GMR.AccessLevel+1)), "Give this problem to GM with higher rank, take a rest.")
	b1:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.num then 
				GMR.SendCommandSafe(".ticket escalate "..GMR.CurrentTicketInfo.num, "ticket escalate")
			end
		end
	)

	GMR.CreateSaveTicketTemplateGraphic("TicketMailAnswer", GMR.TicketFrame, offs_x + 135, offs_y + 500 + 15)

	b2 = GMR.CreateButton("TicketSendMailResponce",  offs_x + 300, offs_y + 500 + 15, 100, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Send mail", "Creator of this ticket will get mail.")
	b2:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.creator then 
				local text = GMR.GetTextTable(GMR.EditScrollBoxes["TicketMailAnswer"]:GetText(), 255-strlen(".send mail "..GMR.CurrentTicketInfo.creator.." \" Ticket Answer\" ".."\"\"")-1)
				for i = 1, getn(text) do
					GMR.SendCommandSafe(".send mail "..GMR.CurrentTicketInfo.creator.." \" Ticket Answer\" ".."\""..text[i].."\"", "send mail")
				end
			end
		end
	)

	GMR.CreateTicketTemplate("TicketWhisperAnswer", GMR.TicketFrame, 390, "TOPLEFT", "TOPLEFT", offs_x, offs_y + 100 + 50)
	GMR.CreateEditScrollBox("TicketWhisperAnswer", offs_x, offs_y + 150 + 50, GMR.TicketFrame, 400, 100, "TOPLEFT", "TOPLEFT")

	GMR.CreateSaveTicketTemplateGraphic("TicketWhisperAnswer", GMR.TicketFrame, offs_x + 135, offs_y + 300 + 15)
	b3 = GMR.CreateButton("TicketSendWhisperResponce",  offs_x + 300, offs_y + 300 + 15, 100, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Send \\w", "Creator of this ticket will get this text now.")
	b3:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.creator then 
				local text = GMR.GetTextTable(GMR.EditScrollBoxes["TicketWhisperAnswer"]:GetText(), 255)
				for i = 1, getn(text) do
					SendChatMessage(text[i], "WHISPER", nil, GMR.CurrentTicketInfo.creator)
				end
			end
		end
	)

	GMR.CreateTicketTemplate("TicketComment", GMR.TicketFrame, 390, "TOPLEFT", "TOPLEFT", offs_x, offs_y + 500 + 50)
	GMR.CreateEditScrollBox("TicketComment", offs_x, 650, GMR.TicketFrame, 400, 50, "TOPLEFT", "TOPLEFT")

	GMR.CreateSaveTicketTemplateGraphic("TicketComment", GMR.TicketFrame, offs_x + 135, offs_y + 650 + 15)
	b4 = GMR.CreateButton("SetTicketComment",  offs_x + 300, offs_y + 650 + 15, 100, 30, GMR.TicketFrame, "TOPLEFT", "TOPLEFT", "Set comment", "Change this comment if you want.")
	b4:SetScript("OnClick",
		function()
			if GMR.CurrentTicketInfo and GMR.CurrentTicketInfo.num then 
				GMR.SendCommandSafe(".ticket comment "..GMR.CurrentTicketInfo.num.." "..GMR.EditScrollBoxes["TicketComment"]:GetText(), "ticket comment")
			end
		end
	)
end

function GMR.BuildTicketFrame()
	local s1, s2, cb1, cb2, cb3, s3
	GMR.TicketFrame = GMR.CreateTicketFrame()
	local buttons_mas = GMR.CreateTicketTableElemets(GMR.TICKET_BUTTONS_NUM)
 	GMR.Tables._Init("Ticket", buttons_mas, GMR.UpdateTicketTableElement, GMR.FindInTicketTable, GMR.SortTicketTable)
 	GMR.Tables._CreateTable("Ticket", GMR.TicketFrame, 20, 200, "TOPLEFT", "TOPLEFT", 40, -200, "Interface\\RaidFrame\\UI-RaidFrame-GroupBg.blp", true, true)
 	GMR.AddTicketNumBoxes()
 	cb1 = GMR.CreateCheckButton("Ticket scan type", 0, -5, GMR.Tables["Ticket"], "BOTTOMRIGHT", "TOPRIGHT", "Enable only online tickets")
 	s1 = cb1:GetScript("OnClick")
 	cb1:SetScript("OnClick", 
 	function() 
 		if this:GetChecked() then
 			GMR.TicketScanType = "online"
 			GMR.CheckButtons["Escalate Scan"]:SetChecked(false)
 		else
 			GMR.TicketScanType = "list"
 		end
 		s1()
 		SLib.CallStack.NewCall(GMR.UpdateMaxTickets, 1, 0)
 	end)

 	cb2 = GMR.CreateCheckButton("Escalate Scan", -25, -5, GMR.Tables["Ticket"], "BOTTOMRIGHT", "TOPRIGHT", "Scan escalatedlist")
 	s2 = cb2:GetScript("OnClick")
 	cb2:SetScript("OnClick", 
 	function()
  		if this:GetChecked() then
  			GMR.CheckButtons["Ticket scan type"]:SetChecked(false)
 			GMR.TicketScanType = "escalatedlist"
 		else
 			GMR.TicketScanType = "online"
 		end
 		SLib.CallStack.NewCall(GMR.UpdateMaxTickets, 1, 0)
 		s2()
 	end)

 	cb3 = GMR.CreateCheckButton("Characters scan type", -50, -5, GMR.Tables["Ticket"], "BOTTOMRIGHT", "TOPRIGHT", "Enable full creators info mode")
 	s3 = cb2:GetScript("OnClick")
 	cb3:SetScript("OnClick", 
 	function() 
 		SLib.CallStack.NewCall(GMR.UpdateMaxTickets, 1, 0)
 		s3()
 	end)

 	cb1:Click()
	GMR.Tables._Update("Ticket")
	GMR.TempObjects.FirstTicketUpdate = true

	GMR.FillTicketFrame()
end