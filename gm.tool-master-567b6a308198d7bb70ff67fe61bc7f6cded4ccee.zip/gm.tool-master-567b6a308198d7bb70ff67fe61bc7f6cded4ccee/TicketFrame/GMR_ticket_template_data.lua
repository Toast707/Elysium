if not GMR then 
	GMR = {} 
end

GMR.ticket_template_data = {
	TicketMailAnswer = {
			["Greetings"] = {
				["all ok"] = "Greetings, thanks for bringing this to our attention, we will look into this matter.",
				["can't help"] = "Greetings, I am afraid that the GM team is not able to assist you in this matter.",
				["go to bugtracketer"] = "Greetings, Please can you report all bugs on our Bug tracker as GMs are not able to deal with them.",
				["In English"] = "Greetings, Please can you explain your full problem to us in English.",
				["point on goldseller"] = "Greetings, Thank you for reporting this gold seller to us, we will look into this."
			},
			["Warnings"] = {
				["Multiboxer"] = "Greetings, you appear to be multiboxing...",
				["BG AFK"] = "Greetings, You are reminded that being AFK in a BG is against our rules, doing this again may lead to further action being taken.",
				["Safe spotting"] = "Greetings, Safe Spotting is against our rules. I will be placing a warning on your account. Performing this action again may result in further sanction being taken."
			}
	},
	TicketWhisperAnswer = {
			["Greetings"] = {
				["all ok"] = "Greetings, thanks for bringing this to our attention, we will look into this matter.",
				["can't help"] = "Greetings, I am afraid that the GM team is not able to assist you in this matter.",
				["go to bugtracketer"] = "Greetings, Please can you report all bugs on our Bug tracker as GMs are not able to deal with them.",
				["In English"] = "Greetings, Please can you explain your full problem to us in English.",
				["point on goldseller"] = "Greetings, Thank you for reporting this gold seller to us, we will look into this."
			},
			["Warnings"] = {
				["Multiboxer"] = "Greetings, you appear to be multiboxing...",
				["BG AFK"] = "Greetings, You are reminded that being AFK in a BG is against our rules, doing this again may lead to further action being taken.",
				["Safe spotting"] = "Greetings, Safe Spotting is against our rules. I will be placing a warning on your account. Performing this action again may result in further sanction being taken."
			}
	},
	Mail = {
			["Greetings"] = {
				["all ok"] = "Greetings, thanks for bringing this to our attention, we will look into this matter.",
				["can't help"] = "Greetings, I am afraid that the GM team is not able to assist you in this matter.",
				["go to bugtracketer"] = "Greetings, Please can you report all bugs on our Bug tracker as GMs are not able to deal with them.",
				["In English"] = "Greetings, Please can you explain your full problem to us in English.",
				["point on goldseller"] = "Greetings, Thank you for reporting this gold seller to us, we will look into this."
			},
			["Warnings"] = {
				["Multiboxer"] = "Greetings, you appear to be multiboxing...",
				["BG AFK"] = "Greetings, You are reminded that being AFK in a BG is against our rules, doing this again may lead to further action being taken.",
				["Safe spotting"] = "Greetings, Safe Spotting is against our rules. I will be placing a warning on your account. Performing this action again may result in further sanction being taken."
			}
	},
	TicketComment = {
			["Greetings"] = {
				["all ok"] = "Greetings, thanks for bringing this to our attention, we will look into this matter.",
				["can't help"] = "Greetings, I am afraid that the GM team is not able to assist you in this matter.",
				["go to bugtracketer"] = "Greetings, Please can you report all bugs on our Bug tracker as GMs are not able to deal with them.",
				["In English"] = "Greetings, Please can you explain your full problem to us in English.",
				["point on goldseller"] = "Greetings, Thank you for reporting this gold seller to us, we will look into this."
			},
			["Warnings"] = {
				["Multiboxer"] = "Greetings, you appear to be multiboxing...",
				["BG AFK"] = "Greetings, You are reminded that being AFK in a BG is against our rules, doing this again may lead to further action being taken.",
				["Safe spotting"] = "Greetings, Safe Spotting is against our rules. I will be placing a warning on your account. Performing this action again may result in further sanction being taken."
			}
	}
}