#ifndef G3D_POSITIONTRAIT_H
#define G3D_POSITIONTRAIT_H

template<typename Value>
struct PositionTrait{};

#endif
