cat ../sql/updates/world/*.sql > world_update.sql
