#!/bin/bash
perl -wpi -e "s/ +$//g" $1
