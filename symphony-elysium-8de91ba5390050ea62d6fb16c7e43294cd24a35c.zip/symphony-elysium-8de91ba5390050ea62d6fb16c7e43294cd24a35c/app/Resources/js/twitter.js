"use strict";

$(document).ready(function(){
    setTimeout(function () {
        $('#twitter-widget-0').ready(function(){
            $('#twitter-widget-0').contents().find('head').append('<style type="text/css"> ::-webkit-scrollbar {width: 10px; height: 10px; background-color:#101010}::-webkit-scrollbar-thumb {background: #464646;} body, .SandboxRoot.env-bp-820 .timeline-Tweet-text {font-family: "Roboto", sans-serif; font-size: 100% !important; line-height: 1.4;} .SandboxRoot.env-bp-820 .TweetAuthor-name, .timeline-Tweet-text {font-size: 16px !important;} </style>');
        });
    }, 1500);
});