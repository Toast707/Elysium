var Vote = {
    init: function init() {
        $('.card').click(function(e){
            e.stopPropagation();
            if (e.target.localName == 'a' || e.target.className.indexOf('issue-score') !== -1 || e.target.className.indexOf('issue-vote') !== -1)
                return;
            $(this).find('.issue-data').slideToggle();
        });
        $('.issue-vote').click(function (e) {
            var id = $(this).data();
            $(this).parent('.issue-score').toggleClass('upvoted');
            if ($(this).parent().hasClass('upvoted'))
                $(this).next('span').text(parseInt($(this).next('span').text()) + 1);
            else
                $(this).next('span').text(parseInt($(this).next('span').text()) - 1);

            $.ajax({
                method: "POST",
                url: "/bugtracker/issue/" + id.issue + "/vote",
                statusCode: {
                    404: function () {
                        alert('This issue does not exist.');
                    },
                    403: function () {
                        window.location.replace("/control");
                    }
                }
            });
        });
    }
};
module.exports = Vote;