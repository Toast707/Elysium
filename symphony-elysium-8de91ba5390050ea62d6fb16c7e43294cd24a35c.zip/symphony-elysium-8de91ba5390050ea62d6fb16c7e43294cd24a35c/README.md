ElysiumWeb
==========

# Requirements
* HTTP server handling php (nginX for Linux and [WTServer](https://wtserver.wtriple.com/) for Windows locally)
* [Composer](https://getcomposer.org/)
* [NodeJS](https://nodejs.org/en/download/)
* [Redis](https://redis.io/download) (already packaged in WTServer)

# Install
1. Clone this repository into a folder of your choice.
2. Move to this repository
3. Move to the Elyium branch with `git checkout elysium`
4. Back-end:
  1. Install the following databases:
    * `ely_tools`
    * `bugtracker`
  2. Edit `app/config/parameters.yml` to connect to the remote databases or install the following databases:
    * `auth` (can be used for `auth_ely`)
    * `realmX`: a character database
    * `logX`: a log database corresponding to `realmX`
  3. Run `composer install`
5. Front-end:
  1. Run `npm install`
  2. Run `npm install bower -g`
  3. Run `npm install brunch -g`
  4. Run `bower install`
  5. Run `brunch build`
6. Login on an admin account
7. Go to `/admin/update/realms`
8. Go to `/admin/update/reputation`
9. Go to `/bugtracker/update/dev`
10. Install the following cronjobs (bugtracker statistics) with the command `crontab -e`:
  * `*/5 * * * * php /var/www/elysium-project.org/bin/console bt:stats status`
  * `*/5 * * * * php /var/www/elysium-project.org/bin/console bt:stats label`

# Back-end organisation
Everything back-end related will be found in the `/src` directory. It contains all the part of the application:

* `AboveBundle`: the bugtracker
* `AppBundle`: the website
* `AuthBundle`: everything related to the auth database and authentication
* `CharacterBundle`: everything related to the characters database
* `DBCBundle`: everything related with the use of DBC
* `LogBundle`: everything related with the log databases
* `StreamBundle`: the stream feature

# Front-end organisation
The front-end is using NPM, Bower and Brunch.

* SCSS is located in `/app/Resources/scss`
* JS is located in `/app/Resources/js`
* The views are located in `/app/Resources/views` or `app/Resources/AboveBundle` for the bugtracker

* Use `brunch watcher` or `brunch w` to automatically recompile the SCSS/JS when you work on it.
* Use `brunch build` or `brunch b` to build the assets. Add the argument `--production` or `-p` for production build.