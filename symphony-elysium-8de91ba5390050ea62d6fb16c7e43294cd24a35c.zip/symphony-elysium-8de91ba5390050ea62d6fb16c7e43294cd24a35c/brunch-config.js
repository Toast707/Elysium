'use strict';

module.exports = {
    paths: {
        'public': 'web/assets',
        'watched': ['app/Resources']
    },
    files: {
        javascripts: {
            joinTo: {
                'js/vendor.js': /^(?!app\/)/,
                'js/onepage-scroll.js': /^app\/Resources\/js\/onepage-scroll.js/,
                'js/app.js': /^app/
            }
        },
        stylesheets: {
            joinTo: {
                'css/style.css': /^app\/Resources\/scss\/style.scss/,
                'css/fullpage.css': /^app\/Resources\/scss\/fullpage.scss/,
                'css/onepage-scroll.css': /^app\/Resources\/scss\/onepage-scroll.scss/,
                'css/bugtracker.css': /^app\/Resources\/scss\/bugtracker.scss/,
                'css/timeline.css': /^app\/Resources\/scss\/timeline.scss/,
                'css/context.css': /^bower_components\/jQuery-contextMenu\/dist\/jquery.contextMenu.css/
            }
        }
    },
    conventions: {
        assets: /^app\/Resources\/assets/
    },
    plugins: {
        on: ['autoprefixer-brunch', 'clean-css-brunch', 'uglify-js-brunch'],
        babel: {
            pattern: /\.(js|jsx)$/
        },
        sass: {
            allowCache: true,
            options: {
                includePaths: ["node_modules/bootstrap-sass/assets/stylesheets"], // tell sass-brunch where to look for files to @import
                precision: 8 // minimum precision required by bootstrap-sass
            }
        },
        uglify: {
            mangle: true,
            compress: {
                global_defs: {
                    DEBUG: false
                }
            }
        },
        cleancss: {
            keepSpecialComments: 0,
            removeEmpty: true
        }
    },
    modules: {
        autoRequire: {
            'js/app.js': ['Resources/js/external']
        }
    }
};
