<?php

namespace AboveBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AboveBundle extends Bundle
{
}
