<?php

namespace AboveBundle\Service;

use CharacterBundle\Entity\Characters;
use CharacterBundle\Entity\Guild;
use Doctrine\ORM\Query\Expr;
use SunManager\Entity\Auth\Account;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;

class CacheService
{
    private $redis;
    private $em;
    private $access;
    private $serializer;
    private $service;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->redis     = $container->get('snc_redis.default');
        $this->em        = $container->get('doctrine');
        $this->access    = $container->get('security.authorization_checker');
        $this->service   = $container->get('character.service');

        $encoder = new JsonEncoder();
        $normalizer = new ObjectNormalizer();

        $normalizer->setCircularReferenceHandler(function ($object) {
            if($object instanceof Account)
                return $object->getUsername();
            if($object instanceof Characters)
                return $object->getGuid();
            if($object instanceof Guild)
                return $object->getGuildid();
            else
                return $object->getId();
        });

        $this->serializer = new Serializer(array($normalizer), array($encoder));
    }
    
    public function getFrontIssues($page)
    {
        $issues = $this->redis->get("bugtracker:front_issues_{$page}");
        $issues = false;
        if(!$issues)
        {
            $qb = $this->em->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
            $issues = $qb
                ->select('i')
                ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
                ->addSelect('l')
                ->addSelect('s')
                ->addSelect('c')
                ->addSelect('m')
                ->join('i.status', 's')
                ->leftJoin('i.labels', 'l')
                ->leftJoin('i.comments', 'c')
                ->leftJoin('i.milestone', 'm')
                ->where('i.status IN (1,2,5,6,7)') // New, Need sources, Confirmed, WIP, PTR
                ->andwhere('i.trash = 0')
                ->andwhere('i.private = 0')
                ->orderBy('scoring', 'DESC')
                ->getQuery();
            $encoder = new JsonEncoder();
            $normalizer = new ObjectNormalizer();

            $normalizer->setCircularReferenceHandler(function ($object) {
                return $object->getId();
            });

            $serializer = new Serializer(array($normalizer), array($encoder));
            $this->redis->set("bugtracker:front_issues_{$page}", $serializer->serialize($issues, 'json'));
            $this->redis->expire("bugtracker:front_issues_{$page}", 60);
            $this->redis->ttl("bugtracker:front_issues_{$page}");
        }
        else
            $issues = unserialize($issues);
        return $issues;
    }

    public function getPrivateIssues($page)
    {
        $issues = $this->redis->get("bugtracker:private_issues_{$page}");
        if(!$issues)
        {
            $issues = $this->em->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i')
                ->select('i, (SUBSTRING(i.score, 3) * 1 as scoring')
                ->addSelect('l')
                ->addSelect('s')
                ->addSelect('c')
                ->join('i.status', 's')
                ->join('i.labels', 'l')
                ->leftJoin('i.comments', 'c')
                ->where('i.status IN (1,2,5,6,7)') // New, Need sources, Confirmed, WIP, Test fix
                ->andwhere('i.trash = 0')
                ->andwhere('i.private = 0')
                ->orderBy('scoring', 'DESC')
                ->getQuery()
                ->getResult();
            $result = [];
            foreach($issues as $issue)
            {
                $issue[0]->setScoring((int)$issue['scoring']);
                $result[] = $issue[0];
            }
            $this->redis->set("bugtracker:private_issues_{$page}", serialize($issues));
            $this->redis->expire("bugtracker:private_issues_{$page}", 60);
            $this->redis->ttl("bugtracker:private_issues_{$page}");
        }
        else
            $issues = unserialize($issues);

        return $issues;
    }

    /**
     * @return mixed
     */
    public function getStatuses()
    {
        $statuses = $this->redis->get('bugtracker:statuses');
        if(!$statuses)
        {
            $statuses = $this->em->getRepository('AboveBundle:Status', 'tracker')->findAll();
            $this->redis->set('bugtracker:statuses', serialize($statuses));
            $this->redis->ttl('bugtracker:statuses');
        }
        else
            $statuses = unserialize($statuses);

        $countStatus = $this->redis->get('bugtracker:stats_status');
        if(!$countStatus)
        {
            $countStatus = $this->em->getRepository('AboveBundle:Issue', 'tracker')->countStatuses();
            $this->redis->set('bugtracker:stats_status', serialize($countStatus));
            $this->redis->ttl('bugtracker:stats_status');
        }

        return $statuses;
    }

    /**
     * @return mixed
     */
    public function getLabels()
    {
        $labels = $this->redis->get('bugtracker:labels');
        if(!$labels)
        {
            $labels = $this->em->getRepository('AboveBundle:Label', 'tracker')->findAll();
            $this->redis->set('bugtracker:labels', serialize($labels));
            $this->redis->ttl('bugtracker:labels');
        }
        else
            $labels = unserialize($labels);

        $countLabel = $this->redis->get('bugtracker:stats_label');
        if(!$countLabel)
        {
            $countLabel = $this->em->getRepository('AboveBundle:Issue', 'tracker')->countLabels();
            $this->redis->set('bugtracker:stats_label', serialize($countLabel));
            $this->redis->ttl('bugtracker:stats_label');
        }

        return $labels;
    }

    /**
     * @return mixed
     */
    public function getMilestones()
    {
        $milestones = $this->redis->get('bugtracker:milestones');
        if(!$milestones)
        {
            $milestones = $this->em->getRepository('AboveBundle:Milestone', 'tracker')->findAll();
            $this->redis->set('bugtracker:milestones', serialize($milestones));
            $this->redis->ttl('bugtracker:milestones');
        }
        else
            $milestones = unserialize($milestones);

        return $milestones;
    }

    /**
     * @return mixed
     */
    public function getDevelopers()
    {
        if($this->access->isGranted('ROLE_ISSUE_ASSIGN'))
        {
            $devs = $this->redis->get('bugtracker:devs');
            if(!$devs)
            {
                $accs = $this->em->getRepository('AuthBundle:AccountAccess', 'auth')->findBySuperiorGmLevel(2, array(10,11,-1));
                $chars = [];
                foreach($accs as $acc)
                    $chars[] = $acc->getId()->getId();
                $devs = $this->em->getRepository('CharacterBundle:Characters', 'realm1')->findOnePerAccount($chars);
                $this->redis->set('bugtracker:devs', serialize($devs));
                $this->redis->ttl('bugtracker:devs');
            }
            else
                $devs = unserialize($devs);
        }
        else
            $devs = null;

        return $devs;
    }

    /**
     * @return mixed
     */
    public function getActivity()
    {
        $logs = $this->redis->get('bugtracker:activity');
        if(!$logs)
        {
            $logs = $this->em->getRepository('Gedmo\Loggable\Entity\LogEntry', 'tracker')->createQueryBuilder('l')
                ->select('l as activity, i.title, i.account, i.realm, i.guid, i.buggedInfo, i.correctInfo, i.sources, i.assignedTo, i.private, i.trash, m.name as milestone, s.name as status')
                ->innerJoin('AboveBundle:Issue', 'i', 'WITH', 'i.id = l.objectId')
                ->leftJoin('AboveBundle:Milestone', 'm', 'WITH', 'i.milestone = m.id')
                ->leftJoin('AboveBundle:Status', 's', 'WITH', 'i.status = s.id')
                ->orderBy('l.loggedAt', 'DESC')
                ->setMaxResults(17)
                ->getQuery()
                ->getResult();
            $this->redis->set('bugtracker:activity', serialize($logs));
            $this->redis->expire('bugtracker:activity', 60);
            $this->redis->ttl('bugtracker:activity');
        }
        else
            $logs = unserialize($logs);

        return $logs;
    }

}