<?php

namespace AboveBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Doctrine\ORM\EntityRepository;

class IssueSearchType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('text', TextType::class, array(
                'required' => false,
            ))
            ->add('status', EntityType::class, array(
                'class'     => 'AboveBundle:Status',
                'multiple'  => true,
                'required'  => false,
            ))
            ->add('labels', EntityType::class, array(
                'class'     => 'AboveBundle:Label',
                'multiple'  => true,
                'required'  => false,
            ))
            ->add('milestone', EntityType::class, array(
                'class'     => 'AboveBundle:Milestone',
                'required'  => false,
            ));

        if($options['access'])
        {
            $builder = $builder
                ->add('assignedTo', EntityType::class, array(
                    'class'     => 'AuthBundle:Account',
                    'query_builder' => function(EntityRepository $er) use ($options) {
                        return $er->fetchByRoles($options['hierarchy']);
                    },
                    'required'  => false,
                ));
        }

        $builder = $builder->add('search', SubmitType::class);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'access' => false,
            'hierarchy' => array('ROLE_DEV', 'ROLE_ADMIN', 'ROLE_SUPER_ADMIN'),
            'csrf_protection' => false,
            'data_class' => 'AboveBundle\Model\IssueSearch'
        ));
    }

    public function getName()
    {
        return 'issue_search_type';
    }
}