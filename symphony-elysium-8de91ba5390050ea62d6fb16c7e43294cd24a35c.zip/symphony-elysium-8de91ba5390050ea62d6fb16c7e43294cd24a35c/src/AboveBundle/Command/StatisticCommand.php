<?php

namespace AboveBundle\Command;

use Exception;
use Abraham\TwitterOAuth\TwitterOAuth;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class StatisticCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName("bt:stats")
            ->addArgument('type', InputArgument::REQUIRED, 'The username of the user.')
            ->setDescription("Update the Bugtracker's statistics of label or status.");
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $redis = $this->getContainer()->get('snc_redis.default');
        $em = $this->getContainer()->get('doctrine');

        switch($input->getArgument('type'))
        {
            case 'label':
                $countLabel = $em->getRepository('AboveBundle:Issue', 'tracker')->countLabels();
                $redis->set('bugtracker:stats_label', serialize($countLabel));
                $redis->ttl('bugtracker:stats_label');
                break;
            case 'status':
                $countStatus = $em->getRepository('AboveBundle:Issue', 'tracker')->countStatuses();
                $redis->set('bugtracker:stats_status', serialize($countStatus));
                $redis->ttl('bugtracker:stats_status');
                break;
            default: return;
        }
    }
}