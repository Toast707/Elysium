<?php

namespace AboveBundle\Twig;

use AboveBundle\Service\CacheService;
use AboveBundle\Service\MarkdownService;
use Doctrine\ORM\EntityManager;

/**
 * Class AppExtension
 * @package AboveBundle\Twig
 */
class AppExtension extends \Twig_Extension
{
    protected $em;
    private $parser;
    private $cache;

    /**
     * @param                 $em
     * @param MarkdownService $parser
     * @param CacheService    $cache
     */
    public function __construct($em, MarkdownService $parser, CacheService $cache)
    {
        $this->em = $em;
        $this->parser = $parser;
        $this->cache = $cache;
    }

    /**
     * @return array
     */
    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('username', array($this, 'getUsername')),
            new \Twig_SimpleFilter('name', array($this, 'getKeyName')),
            new \Twig_SimpleFilter('statusName', array($this, 'getStatusName')),
            new \Twig_SimpleFilter('getIssueMethodName', array($this, 'getIssueMethodName')),
            new \Twig_SimpleFilter('md2html', array($this, 'markdownToHtml'), array('is_safe' => array('html'))),
            new \Twig_SimpleFilter('getStatusByName', array($this, 'getStatusByName')),
            new \Twig_SimpleFilter('getStatusById', array($this, 'getStatusById')),
            new \Twig_SimpleFilter('getMilestoneById', array($this, 'getMilestoneById')),
        );
    }

    public function getStatusByName($name)
    {
        $statuses = $this->cache->getStatuses();
        foreach($statuses as $status)
        {
            if($status->getName() === $name)
                return $status;
        }
        return 'error';
    }

    public function getStatusById($id)
    {
        $statuses = $this->cache->getStatuses();
        foreach($statuses as $status)
        {
            if($status->getId() === $id)
                return $status;
        }
        return 'error';
    }

    public function getMilestoneById($id)
    {
        $milestones = $this->cache->getMilestones();
        foreach($milestones as $milestone)
        {
            if($milestone->getId() === $id)
                return $milestone;
        }
        return 'error';
    }

    /**
     * @param $content
     * @return mixed
     */
    public function markdownToHtml($content)
    {
        return $this->parser->toHtml(htmlspecialchars($content));
    }

    /**
     * @param $id
     * @return mixed
     */
    public function getUsername($id)
    {
        $user = $this->em->getRepository('AuthBundle:Account')->find($id);
        return $user->getUsername();
    }

    /**
     * @param $name
     * @return mixed
     */
    public function getKeyName($id, $name)
    {
        $key = ucfirst($name);
        $name = $this->em->getRepository("AboveBundle:{$key}", 'tracker')->find($id);
        return $name->getName();
    }

    /**
     * @param $id
     * @return mixed
     */
    public function getStatusName($id)
    {
        $status = $this->em->getManager('tracker')->getRepository('AboveBundle:Status', 'tracker')->find($id);
        return $status->getName();
    }

    /**
     * @param $key
     * @return mixed
     */
    public function getIssueMethodName($key)
    {
        switch($key)
        {
            case 'assignedTo':      return 'Issue has been assigned to'; break;
            case 'buggedInfo':      return 'Bugged behavior'; break;
            case 'correctInfo':     return 'Correct behavior'; break;
            case 'milestone':       return 'Milestone'; break;
            case 'sources':         return 'Sources'; break;
            case 'status':          return 'Status'; break;
            case 'title':           return 'Title'; break;
            case 'private':
            case 'trash':           return 'Accessibility'; break;
            default:                return ''; break;
        }
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'above_extension';
    }
}