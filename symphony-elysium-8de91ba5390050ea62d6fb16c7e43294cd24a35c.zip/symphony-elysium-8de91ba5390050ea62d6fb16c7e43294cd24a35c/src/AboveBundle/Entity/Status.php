<?php

namespace AboveBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="status")
 * @ORM\HasLifecycleCallbacks()
 */
class Status implements \Serializable
{
    const NONE          = 1;
    const NEED_SOURCES  = 2;
    const INVALID       = 3;
    const DUPLICATE     = 4;
    const CONFIRMED     = 5;
    const WIP           = 6;
    const RESOLVED      = 7;

    /**
     * @var $id
     *
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var $name
     *
     * @ORM\Column(type="string")
     */
    protected $name;

    /**
     * @var $color
     *
     * @ORM\Column(type="string")
     */
    protected $color;

    /**
     * @var $border
     *
     * @ORM\Column(type="string")
     */
    protected $border;

    /**
     * @var $issue
     *
     * @ORM\OneToMany(targetEntity="AboveBundle\Entity\Issue", mappedBy="status")
     */
    protected $issue;

    /**
     * @var $count
     */
    protected $count;

    public function __toString() {
        return $this->name;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     * @ORM\PostPersist
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getColor()
    {
        return $this->color;
    }

    /**
     * @param mixed $color
     */
    public function setColor($color)
    {
        $this->color = $color;
    }

    /**
     * @return mixed
     */
    public function getBorder()
    {
        return $this->border;
    }

    /**
     * @param mixed $border
     */
    public function setBorder($border)
    {
        $this->border = $border;
    }

    /**
     * @return mixed
     */
    public function getIssue()
    {
        return $this->issue;
    }

    /**
     * @param mixed $issue
     */
    public function setIssue($issue)
    {
        $this->issue = $issue;
    }

    /**
     * @return mixed
     */
    public function getCount()
    {
        return $this->count;
    }

    /**
     * @param mixed $count
     */
    public function setCount($count)
    {
        $this->count = $count;
    }

    /**
     * Add issue
     *
     * @param \AboveBundle\Entity\Issue $issue
     *
     * @return Status
     */
    public function addIssue(\AboveBundle\Entity\Issue $issue)
    {
        $this->issue[] = $issue;

        return $this;
    }

    /**
     * Remove issue
     *
     * @param \AboveBundle\Entity\Issue $issue
     */
    public function removeIssue(\AboveBundle\Entity\Issue $issue)
    {
        $this->issue->removeElement($issue);
    }

    /**
     * @return string
     */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->name,
            $this->color,
            $this->border
        ));
    }

    /**
     * @param string $serialized
     */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->name,
            $this->color,
            $this->border
            ) = unserialize($serialized);
    }
}
