<?php

namespace AboveBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity(repositoryClass="AboveBundle\Repository\IssueRepository")
 * @ORM\Table(name="issue")
 * @Gedmo\Loggable
 */
class Issue implements \Serializable
{
    /**
     * @var $id
     *
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="account", type="integer")
     * @Gedmo\Versioned
     */
    protected $account;

    /**
     * @var integer
     *
     * @ORM\Column(name="realm", type="integer")
     * @Gedmo\Versioned
     */
    protected $realm;

    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @Gedmo\Versioned
     */
    protected $guid;

    /**
     * @var $title
     *
     * @ORM\Column(type="string", length=255)
     * @Gedmo\Versioned
     */
    protected $title;

    /**
     * @var $status
     *
     * @ORM\ManyToOne(targetEntity="AboveBundle\Entity\Status", inversedBy="issue")
     * @ORM\JoinColumn(name="status", referencedColumnName="id")
     * @Gedmo\Versioned
     */
    protected $status;

    /**
     * @var \DateTime $createdAt
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    protected $createdAt;

    /**
     * @var \DateTime $updatedAt
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     * @Gedmo\Timestampable(on="change")
     */
    protected $updatedAt;

    /**
     * @var integer
     *
     * @ORM\Column(name="assignedTo", type="integer", nullable=true)
     */
    protected $assignedTo;

    /**
     * @var $buggedInfo
     *
     * @ORM\Column(type="text")
     * @Gedmo\Versioned
     */
    protected $buggedInfo;

    /**
     * @var $correctInfo
     *
     * @ORM\Column(type="text")
     * @Gedmo\Versioned
     */
    protected $correctInfo;

    /**
     * @var $sources
     *
     * @ORM\Column(type="text")
     * @Gedmo\Versioned
     */
    protected $sources;

    /**
     * @var $refers
     *
     * @ORM\Column(type="array", nullable=true)
     * @Gedmo\Versioned
     */
    protected $refers;

    /**
     * @var $score
     *
     * @ORM\Column(type="array")
     */
    protected $score;

    /**
     * @var $score
     */
    protected $scoring;

    /**
     * @var $labels
     *
     * @ORM\ManyToMany(targetEntity="AboveBundle\Entity\Label", cascade={"persist"})
     */
    protected $labels;

    /**
     * @var $milestones
     *
     * @ORM\ManyToOne(targetEntity="AboveBundle\Entity\Milestone", inversedBy="issue")
     * @ORM\JoinColumn(name="milestone", referencedColumnName="id")
     * @Gedmo\Versioned
     */
    protected $milestone;

    /**
     * @var $private
     *
     * @ORM\Column(type="boolean", options={"default":false})
     * @Gedmo\Versioned
     */
    protected $private;

    /**
     * @var $trash
     *
     * @ORM\Column(type="boolean", options={"default":false})
     * @Gedmo\Versioned
     */
    protected $trash;

    /**
     * @var $tweet
     *
     * @ORM\Column(type="boolean", options={"default":false})
     * @Gedmo\Versioned
     */
    protected $tweet;

    /**
     * @ORM\OneToMany(targetEntity="AboveBundle\Entity\Comment", mappedBy="issue")
     */
    protected $comments;

    /**
     * @var $characters
     */
    protected $characters;

    /**
     * @var $characters
     */
    protected $username;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->comments = new ArrayCollection();
        $this->labels   = new ArrayCollection();
    }

    /**
     * @return mixed
     */
    public function __toString()
    {
        return $this->buggedInfo;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getAccount()
    {
        return $this->account;
    }

    /**
     * @param int $account
     */
    public function setAccount($account)
    {
        $this->account = $account;
    }

    /**
     * @return int
     */
    public function getRealm()
    {
        return $this->realm;
    }

    /**
     * @param int $realm
     */
    public function setRealm($realm)
    {
        $this->realm = $realm;
    }

    /**
     * @return int
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * @param int $guid
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;
    }

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param mixed $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param \DateTime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * @param \DateTime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
    }

    /**
     * @return mixed
     */
    public function getAssignedTo()
    {
        return $this->assignedTo;
    }

    /**
     * @param mixed $assignedTo
     */
    public function setAssignedTo($assignedTo)
    {
        $this->assignedTo = $assignedTo;
    }

    /**
     * @return mixed
     */
    public function getBuggedInfo()
    {
        return $this->buggedInfo;
    }

    /**
     * @param mixed $buggedInfo
     */
    public function setBuggedInfo($buggedInfo)
    {
        $this->buggedInfo = $buggedInfo;
    }

    /**
     * @return mixed
     */
    public function getCorrectInfo()
    {
        return $this->correctInfo;
    }

    /**
     * @param mixed $correctInfo
     */
    public function setCorrectInfo($correctInfo)
    {
        $this->correctInfo = $correctInfo;
    }

    /**
     * @return mixed
     */
    public function getSources()
    {
        return $this->sources;
    }

    /**
     * @param mixed $sources
     */
    public function setSources($sources)
    {
        $this->sources = $sources;
    }

    /**
     * @return mixed
     */
    public function getRefers()
    {
        return $this->refers;
    }

    /**
     * @param mixed $refers
     */
    public function setRefers($refers)
    {
        $this->refers = $refers;
    }

    /**
     * @return mixed
     */
    public function getScore()
    {
        return $this->score;
    }

    /**
     * @param mixed $score
     */
    public function setScore($score)
    {
        $this->score = $score;
    }

    /**
     * @return mixed
     */
    public function getScoring()
    {
        return $this->scoring;
    }

    /**
     * @param mixed $scoring
     */
    public function setScoring($scoring)
    {
        $this->scoring = $scoring;
    }

    /**
     * @return mixed
     */
    public function getLabels()
    {
        return $this->labels;
    }

    /**
     * @param mixed $labels
     */
    public function setLabels($labels)
    {
        $this->labels = $labels;
    }

    /**
     * Get milestone
     *
     * @return \AboveBundle\Entity\Milestone
     */
    public function getMilestone()
    {
        return $this->milestone;
    }

    /**
     * Set milestone
     *
     * @param \AboveBundle\Entity\Milestone $milestone
     *
     * @return Issue
     */
    public function setMilestone(\AboveBundle\Entity\Milestone $milestone = null)
    {
        $this->milestone = $milestone;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * @param mixed $comments
     */
    public function setComments($comments)
    {
        $this->comments = $comments;
    }

    /**
     * Add comment
     *
     * @param \AboveBundle\Entity\Comment $comment
     *
     * @return Issue
     */
    public function addComment(\AboveBundle\Entity\Comment $comment)
    {
        $this->comments[] = $comment;

        return $this;
    }

    /**
     * Remove comment
     *
     * @param \AboveBundle\Entity\Comment $comment
     */
    public function removeComment(\AboveBundle\Entity\Comment $comment)
    {
        $this->comments->removeElement($comment);
    }

    /**
     * @return mixed
     */
    public function getPrivate()
    {
        return $this->private;
    }

    /**
     * @param mixed $private
     */
    public function setPrivate($private)
    {
        $this->private = $private;
    }

    /**
     * @return mixed
     */
    public function getTrash()
    {
        return $this->trash;
    }

    /**
     * @param mixed $trash
     */
    public function setTrash($trash)
    {
        $this->trash = $trash;
    }

    /**
     * @return mixed
     */
    public function getTweet()
    {
        return $this->tweet;
    }

    /**
     * @param mixed $tweet
     */
    public function setTweet($tweet)
    {
        $this->tweet = $tweet;
    }

    /**
     * Add label
     *
     * @param \AboveBundle\Entity\Label $label
     *
     * @return Issue
     */
    public function addLabel(\AboveBundle\Entity\Label $label)
    {
        $this->labels[] = $label;

        return $this;
    }

    /**
     * Remove label
     *
     * @param \AboveBundle\Entity\Label $label
     */
    public function removeLabel(\AboveBundle\Entity\Label $label)
    {
        $this->labels->removeElement($label);
    }

    /**
     * Add status
     *
     * @param \AboveBundle\Entity\Status $status
     *
     * @return Issue
     */
    public function addStatus(\AboveBundle\Entity\Status $status)
    {
        $this->status[] = $status;

        return $this;
    }

    /**
     * Remove status
     *
     * @param \AboveBundle\Entity\Status $status
     */
    public function removeStatus(\AboveBundle\Entity\Status $status)
    {
        $this->status->removeElement($status);
    }

    /**
     * @return mixed
     */
    public function getCharacters()
    {
        return $this->characters;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @param mixed $characters
     */
    public function setCharacters($characters)
    {
        $this->characters = $characters;
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->status,
            $this->labels,
            $this->buggedInfo,
            $this->correctInfo,
            $this->sources,
            $this->private,
            $this->trash
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->status,
            $this->labels,
            $this->buggedInfo,
            $this->correctInfo,
            $this->sources,
            $this->private,
            $this->trash
            ) = unserialize($serialized);
    }
}
