<?php

namespace AboveBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="milestone")
 * @ORM\HasLifecycleCallbacks()
 */
class Milestone
{
    /**
     * @var $id
     *
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var $name
     *
     * @ORM\Column(type="string")
     */
    protected $name;

    /**
     * @var $issue
     *
     * @ORM\OneToMany(targetEntity="AboveBundle\Entity\Issue", mappedBy="milestone")
     */
    protected $issue;

    public function __toString() {
        return $this->name;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Milestone
     * @ORM\PostPersist
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set issue
     *
     * @param \AboveBundle\Entity\Issue $issue
     *
     * @return Milestone
     */
    public function setIssue(\AboveBundle\Entity\Issue $issue = null)
    {
        $this->issue = $issue;

        return $this;
    }

    /**
     * Get issue
     *
     * @return \AboveBundle\Entity\Issue
     */
    public function getIssue()
    {
        return $this->issue;
    }

    /**
     * Constructor
     *
     * @param null $name
     */
    public function __construct($name = null)
    {
        if($name != null)
            $this->name = $name;

        $this->issue = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add issue
     *
     * @param \AboveBundle\Entity\Issue $issue
     *
     * @return Milestone
     */
    public function addIssue(\AboveBundle\Entity\Issue $issue)
    {
        $this->issue[] = $issue;

        return $this;
    }

    /**
     * Remove issue
     *
     * @param \AboveBundle\Entity\Issue $issue
     */
    public function removeIssue(\AboveBundle\Entity\Issue $issue)
    {
        $this->issue->removeElement($issue);
    }
}
