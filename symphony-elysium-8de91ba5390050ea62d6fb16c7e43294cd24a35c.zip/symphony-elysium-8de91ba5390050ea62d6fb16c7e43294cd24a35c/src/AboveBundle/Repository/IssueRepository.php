<?php

namespace AboveBundle\Repository;

use AboveBundle\Model\IssueSearch;
use Gedmo\Loggable\Entity\Repository\LogEntryRepository;
use AboveBundle\Entity\Label;

/**
 * Class IssueRepository
 * @package AboveBundle\Repository
 */
class IssueRepository extends LogEntryRepository
{
    /**
     * @param $id
     * @return array
     */
    public function getByStatus($id)
    {
        $qb = $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i')
            ->select('COUNT(i)')
            ->join('i.status', 's')
            ->where('s.id = :id')
            ->setParameter('id', $id)
            ->getQuery()
            ->getSingleScalarResult();
        return $qb;
    }

    /**
     * @return array
     */
    public function countStatuses()
    {
        $result = $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i')
            ->join('i.status', 's')
            ->select('s.id')
            ->addSelect('COUNT(i.id) as amount')
            ->groupBy('s.id')
            ->getQuery()
            ->getResult();
        $countStatus = [];
        foreach($result as $count)
            $countStatus[$count['id']] = (int) $count['amount'];
        return $countStatus;
    }

    /**
     * @param $id
     * @return array
     */
    public function getByLabel($id)
    {
        $qb = $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i')
            ->select('COUNT(i)')
            ->join('i.labels', 'l')
            ->where('l.id = :id')
            ->setParameter('id', $id)
            ->getQuery()
            ->getSingleScalarResult();
        return $qb;
    }

    /**
     * @return array
     */
    public function countLabels()
    {
        $result = $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i')
            ->innerJoin('i.labels', 'l')
            ->select('l.id')
            ->addSelect('COUNT(i.id) as amount')
            ->groupBy('l.id')
            ->getQuery()
            ->getResult();
        $countLabel = [];
        foreach($result as $count)
            $countLabel[$count['id']] = (int) $count['amount'];
        return $countLabel;
    }

    /**
     * @param int $offset
     * @param int $limit
     * @return array
     */
    public function getOpenIssues($offset = 0, $limit = 50)
    {
        $qb = $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');

        return $qb->where('i.status NOT IN (3,4,7)')
            ->andwhere('i.private = 0')
            ->andwhere('i.trash = 0')
            ->setFirstResult($offset)
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }

    /**
     * @param $status
     * @return array
     */
    public function countStatusIssues($status)
    {
        $qb = $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');

        return $qb->select('count(i.id)')
            ->where('i.status IN (:status)')
            ->andwhere('i.trash = 0')
            ->andwhere('i.private = 0')
            ->setParameter('status', $status)
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param $label
     * @return array
     */
    public function countLabelIssues(Label $label)
    {
        return $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i')
            ->select('count(i.id)')
            ->innerJoin('i.labels', 'l', 'WITH', 'l.id = :label')
            ->andwhere('i.trash = 0')
            ->andwhere('i.private = 0')
            ->setParameter('label', $label->getId())
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param IssueSearch $issueSearch
     * @param             $granted
     * @return null|object
     */
    public function search(IssueSearch $issueSearch, $granted = false)
    {

        $boolQuery = new \Elastica\Query\BoolQuery();

        if($issueSearch->getText() != '' && $issueSearch != '')
        {
            $query = new \Elastica\Query\Match();
            $query->setFieldQuery('title', $issueSearch->getText());
        }
        else
            $query = new \Elastica\Query\MatchAll();

        $boolQuery->addMust($query);

        if($issueSearch->getStatus() != '')
        {
            $tagsQuery = new \Elastica\Query\Terms();
            $tagsQuery->setTerms('status.id', array($issueSearch->getStatus()));
            $boolQuery->addShould($tagsQuery);
        }

        if($issueSearch->getLabels() != '')
        {
            $tagsQuery = new \Elastica\Query\Terms();
            $tagsQuery->setTerms('label.id', array($issueSearch->getLabels()));
            $boolQuery->addShould($tagsQuery);
        }

        if($issueSearch->getMilestone() != '')
        {
            $tagsQuery = new \Elastica\Query\Terms();
            $tagsQuery->setTerms('milestone.id', array($issueSearch->getMilestone()));
            $boolQuery->addShould($tagsQuery);
        }

        if($granted && $issueSearch->getAssignedTo() != '')
        {
            $tagsQuery = new \Elastica\Query\Terms();
            $tagsQuery->setTerms('assignedTo.id', array($issueSearch->getAssignedTo()));
            $boolQuery->addShould($tagsQuery);
        }

        return $boolQuery;

        /*
        $scoreQuery = new \Elastica\Query\FunctionScore($boolQuery);
        $script = new \Elastica\Script\Script("doc['score'].values * 0.2");
        $scoreQuery->addScriptScoreFunction($script);

        $boolQuery = new \Elastica\Query($scoreQuery);
        */
    }

    public function countStatus()
    {
        $qb= $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $qb->addSelect('s')
            ->join('i.status','s')
            ->groupBy('s.id')
            ->getQuery()->getResult();
        return $qb;
    }

    public function countLabel()
    {
        $qb= $this->getEntityManager()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $qb
            ->innerJoin('i.labels', 'l')
            ->select('l.id')
            ->addSelect('COUNT(i.id) as amount')
            ->groupBy('l.id')
            ->getQuery()
            ->getResult();
        return $qb;
    }
}