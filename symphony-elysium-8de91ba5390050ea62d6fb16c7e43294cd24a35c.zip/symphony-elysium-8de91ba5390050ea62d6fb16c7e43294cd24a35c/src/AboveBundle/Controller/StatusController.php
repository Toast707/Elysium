<?php

namespace AboveBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AboveBundle\Entity\Status;
use Doctrine\ORM\Tools\Pagination\Paginator;

/**
 * Class StatusController
 * @package AboveBundle\Controller
 */
class StatusController extends Controller
{
    /**
     * @Route("/status", name="bugtracker_status")
     */
    public function indexAction(Request $request)
    {
        $cache = $this->get('app.service.cache.tracker');
        $status = $cache->getStatuses();

        return $this->render('AboveBundle:status:index.html.twig', array(
            'status' => $status
        ));
    }

    /**
     * @Route("/status/{name}", name="bugtracker_status_view")
     */
    public function viewAction(Request $request, $name)
    {
        $em = $this->getDoctrine()->getManager('tracker');

        $status = $em->getRepository('AboveBundle:Status')->findOneByName($name);

        if($status == null)
            throw $this->createNotFoundException();

        $qb = $this->getDoctrine()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $issues = $qb
            ->select('i')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->addSelect('l')
            ->addSelect('s')
            ->addSelect('c')
            ->join('i.status', 's')
            ->leftJoin('i.labels', 'l')
            ->leftJoin('i.comments', 'c')
            ->where('i.status = :status')
            ->setParameter('status', $status)
            ->orderBy('scoring', 'DESC')
            ->getQuery();

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($issues, $request->query->getInt('page', 1), $this->getParameter('knp_paginator.page_range'));

        $cache = $this->get('app.service.cache.tracker');
        $labels     = $cache->getLabels();
        $statuses   = $cache->getStatuses();
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();

        return $this->render('AboveBundle:search:index.html.twig', array(
            'labels'    => $labels,
            'statuses'  => $statuses,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination,
        ));
    }
}