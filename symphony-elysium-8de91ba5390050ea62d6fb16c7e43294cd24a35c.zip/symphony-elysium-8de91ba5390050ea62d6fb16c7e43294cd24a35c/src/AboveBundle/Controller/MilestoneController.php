<?php

namespace AboveBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Tools\Pagination\Paginator;

/**
 * Class MilestoneController
 * @package AboveBundle\Controller
 */
class MilestoneController extends Controller
{
    /**
     * @Route("/milestone", name="bugtracker_milestone")
     */
    public function indexAction(Request $request)
    {
        $cache = $this->get('app.service.cache.tracker');
        $milestones = $cache->getMilestones();

        return $this->render('AboveBundle:milestone:index.html.twig', array(
            'milestones' => $milestones
        ));
    }

    /**
     * @Route("/milestone/{name}", name="bugtracker_milestone_view")
     */
    public function viewAction(Request $request, $name)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $milestone = $em->getRepository('AboveBundle:Milestone')->findOneByName($name);

        if($milestone == null)
            throw $this->createNotFoundException();

        $qb = $em->getRepository('AboveBundle:Issue')->createQueryBuilder('i');
        $issues = $qb->join('i.milestone', 'l')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->where('l.id = :id')
            ->setParameter('id', $milestone->getId())
            ->orderBy('scoring', 'DESC')
            ->getQuery();

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($issues, $request->query->getInt('page', 1), $this->getParameter('knp_paginator.page_range'));

        $cache = $this->get('app.service.cache.tracker');
        $labels     = $cache->getLabels();
        $statuses   = $cache->getStatuses();
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();

        return $this->render('AboveBundle:search:index.html.twig', array(
            'labels'    => $labels,
            'statuses'  => $statuses,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination,
        ));
    }
}