<?php

namespace AboveBundle\Controller;

use Elastica\QueryBuilder;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Elastica\Query;
use League\HTMLToMarkdown\HtmlConverter;

/**
 * Class DefaultController
 * @package AboveBundle\Controller
 */
class DefaultController extends Controller
{
    /**
     * @Route("/", name="bugtracker")
     */
    public function indexAction(Request $request)
    {
        $page = $request->query->getInt('page', 1);

        $cache = $this->get('app.service.cache.tracker');
        $redis = $this->get('snc_redis.default');
        //$issues     = $cache->getFrontIssues($page);

        $qb = $this->getDoctrine()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $issues = $qb
            ->select('i')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->addSelect('l')
            ->addSelect('s')
            ->addSelect('c')
            ->addSelect('m')
            ->join('i.status', 's')
            ->leftJoin('i.labels', 'l')
            ->leftJoin('i.comments', 'c')
            ->leftJoin('i.milestone', 'm')
            ->where('i.status IN (1,2,5,6,7)') // New, Need sources, Confirmed, WIP, PTR
            ->andwhere('i.trash = 0')
            ->andwhere('i.private = 0')
            ->orderBy('scoring', 'DESC')
            ->getQuery();


        $labels     = $cache->getLabels();
        $countLabels= unserialize($redis->get('bugtracker:stats_label'));
        $statuses   = $cache->getStatuses();
        $countStatus= unserialize($redis->get('bugtracker:stats_status'));
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();
        $logs       = $cache->getActivity();

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($issues, $page, $this->getParameter('knp_paginator.page_range'));

        return $this->render('AboveBundle:default:index.html.twig', array(
            'labels'    => $labels,
            'countLabel'=> $countLabels,
            'statuses'  => $statuses,
            'countStatus'=> $countStatus,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination,
            'logs'      => $logs,
        ));
    }

    /**
     * @Route("/search", name="bugtracker_search")
     */
    public function searchAction(Request $request)
    {
        $security = $this->get('security.authorization_checker');
        $params = $request->query->all();
        $finder = $this->container->get('fos_elastica.finder.app.issue');
        $q = new Query();
        $boolQuery = new Query\BoolQuery();

        if(isset($params['title']) && $params['title'] != '')
        {
            $query = new Query\Match();
            $query->setFieldQuery('title', $params['title']);
        }
        else
            $query = new Query\MatchAll();

        $q->addSort(array('createdAt' => array('order' => 'desc')));

        $boolQuery->addMust($query);

        if(isset($params['status']) && $params['status'] != '')
        {
            $tagsQuery = new Query\Terms();
            $tagsQuery->setTerms('status.id', $params['status']);
            $boolQuery->addMust($tagsQuery);
        }

        if(isset($params['labels']) && $params['labels'] != '')
        {
            foreach($params['labels'] as $label)
            {
                $schoolsTermQuery = new Query\Match();
                $schoolsTermQuery->setField("labels.id", $label);
                $schoolsBoolQuery = new Query\BoolQuery();
                $schoolsBoolQuery->addMust($schoolsTermQuery);
                $nestedQuery = new Query\Nested();
                $nestedQuery->setPath("labels");
                $nestedQuery->setQuery($schoolsBoolQuery);
                $boolQuery->addMust($nestedQuery);
            }
        }

        if (isset($params['milestone']) && $params['milestone'] != '')
        {
            $tagsQuery = new Query\Terms();
            $tagsQuery->setTerms('milestone.id', array($params['milestone']));
            $boolQuery->addMust($tagsQuery);
        }

        if ($security->isGranted('ROLE_ISSUE_ASSIGN') && isset($params['assignedTo']) && $params['assignedTo'] != '')
        {
            $tagsQuery = new Query\Terms();
            $tagsQuery->setTerms('assignedTo.id', array($params['assignedTo']));
            $boolQuery->addMust($tagsQuery);
        }

        $q = $q->setQuery($boolQuery);

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($finder->createPaginatorAdapter($q), $request->query->getInt('page', 1), $this->getParameter('knp_paginator.page_range'));

        $cache = $this->get('app.service.cache.tracker');
        $labels     = $cache->getLabels();
        $statuses   = $cache->getStatuses();
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();

        return $this->render('AboveBundle:search:elastica.html.twig', array(
            'labels'    => $labels,
            'statuses'  => $statuses,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination,
        ));
    }

    /**
     * @Route("/stats", name="stats")
     */
    public function statsAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $cache = $this->get('app.service.cache.tracker');
        $statuses   = $cache->getStatuses();

        /*
         * Stats per month
         * Each status
         * Labels
         * best dev
         */

        $score = $em->getRepository('AboveBundle\Entity\Issue')->createQueryBuilder('i')
            ->join('i.assignedTo', 'u')
            ->select('u.id, u.username')
            ->addSelect('COUNT(u.id) as amount')
            ->groupBy('u.id')
            ->where('i.status = :status')
            ->setParameter('status', $statuses[7])
            ->andWhere("i.assignedTo != 'NULL'")
            ->getQuery()
            ->getResult();

        return $this->render('default/stats.html.twig', array(
            'statuses'  => $statuses,
            'score'     => $score,
        ));
    }

    /**
     * @Route("/stats/data", name="stats_data")
     */
    public function statsDataAction(Request $request)
    {
        $start = $request->query->get('start');
        $end = $request->query->get('end');

        $em = $this->getDoctrine()->getManager('tracker');
        $cache = $this->get('app.service.cache.tracker');
        $statuses   = $cache->getStatuses();

        /*
         * Stats per month
         * Each status
         * Labels
         * best dev
         */

        $score = $em->getRepository('AboveBundle\Entity\Issue')->createQueryBuilder('i')
            ->join('i.assignedTo', 'u')
            ->select('u.id, u.username')
            ->addSelect('COUNT(u.id) as amount')
            ->groupBy('u.id')
            ->where('i.status = :status')
            ->setParameter('status', $statuses[7])
            ->andWhere("i.assignedTo != 'NULL'")
            ->andWhere('i.createdAt BETWEEN :start AND :end')
            ->setParameter('start', $start)
            ->setParameter('end', $end)
            ->getQuery()
            ->getResult();

        var_dump($score);

        return new Response('<html><body></body></html>');

        return $this->json(json_encode($score));
    }

    /**
     * @Route("/parse", name="parse")
     */
    public function parseAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $issues = $em->getRepository('AboveBundle:Issue', 'tracker')->findAll();
        $converter = new HtmlConverter();
        foreach($issues as $issue)
        {
            $issue->setBuggedInfo($converter->convert($issue->getBuggedInfo()));
            $em->merge($issue);
        }
        $em->flush();
        new Response('Done');
    }
}
