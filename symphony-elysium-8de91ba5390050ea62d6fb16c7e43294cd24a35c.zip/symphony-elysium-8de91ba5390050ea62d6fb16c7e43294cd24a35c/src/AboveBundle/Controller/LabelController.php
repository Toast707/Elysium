<?php

namespace AboveBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AboveBundle\Entity\Status;
use Doctrine\ORM\Tools\Pagination\Paginator;

/**
 * Class LabelController
 * @package AboveBundle\Controller
 */
class LabelController extends Controller
{
    /**
     * @Route("/label", name="bugtracker_label")
     */
    public function indexAction(Request $request)
    {
        $cache = $this->get('app.service.cache.tracker');
        $labels     = $cache->getLabels();

        return $this->render('AboveBundle:label:index.html.twig', array(
            'labels' => $labels,
        ));
    }

    /**
     * @Route("/label/{name}", name="bugtracker_label_view")
     */
    public function viewAction(Request $request, $name)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $cache = $this->get('app.service.cache.tracker');

        $label = $em->getRepository('AboveBundle:Label')->findOneByName($name);

        if($label == null)
            throw $this->createNotFoundException();

        $qb = $this->getDoctrine()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $issues = $qb
            ->select('i')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->addSelect('l')
            ->leftJoin('i.labels', 'l')
            ->where('l.id = :id')
            ->setParameter('id', $label)
            ->orderBy('scoring', 'DESC')
            ->getQuery();

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($issues, $request->query->getInt('page', 1), $this->getParameter('knp_paginator.page_range'));

        $labels     = $cache->getLabels();
        $statuses   = $cache->getStatuses();
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();

        return $this->render('AboveBundle:search:index.html.twig', array(
            'labels'    => $labels,
            'statuses'  => $statuses,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination,
        ));
    }
}