<?php

namespace AboveBundle\Controller;

use CharacterBundle\Service\CharacterService;
use Doctrine\ORM\EntityRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Gedmo\Loggable\Entity\Repository;
use AboveBundle\Entity\Issue;
use AboveBundle\Entity\Comment;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Abraham\TwitterOAuth\TwitterOAuth;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

/**
 * Class IssueController
 * @package AboveBundle\Controller
 */
class IssueController extends Controller
{

    /**
     * @Route("/issue/add", name="bugtracker_issue_add")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function addAction(Request $request)
    {
        $issue = new Issue();

        $form = $this->get('form.factory')->createBuilder(FormType::class, $issue)
            ->add('title',          TextType::class)
            ->add('buggedInfo',     TextareaType::class)
            ->add('correctInfo',    TextareaType::class)
            ->add('sources',        TextareaType::class)
            ->add('private',        CheckboxType::class, array(
                'label' => 'Only display this issue for the Elysium team',
                'required'  => false,
            ))
            ->add('save',           SubmitType::class);

        $security = $this->get('security.authorization_checker');

        if($security->isGranted('ROLE_ISSUE_LABELS'))
            $form = $form->add('labels', EntityType::class, array('class' => 'AboveBundle:Label', 'multiple' => true, 'required' => false));

        if($security->isGranted('ROLE_ISSUE_STATUS'))
            $form = $form->add('status', EntityType::class, array('class' => 'AboveBundle:Status'));

        if($security->isGranted('ROLE_ISSUE_MILESTONE'))
            $form = $form->add('milestone', EntityType::class, array('class' => 'AboveBundle:Milestone', 'placeholder'  => 'Select a milestone', 'required' => false));

        if(!$security->isGranted('ROLE_QA1') && !$security->isGranted('ROLE_GM1'))
        {
            $characters = $this->get('character.service')->getAccountCharacters($this->getUser()->getId(), true);
            $realms = $this->getParameter('realms');
            $form = $form
                ->add('characters',     ChoiceType::class, array(
                    'choices'       => $characters,
                    'choice_label' => function ($value, $key, $index) use ($realms) {
                        return "{$realms[$value->getRealm()]['name']} - {$value->getName()}";
                    },
                ));
        }

        if($security->isGranted('ROLE_ISSUE_ASSIGN'))
        {
            $devs = unserialize($this->get('snc_redis.default')->get('bugtracker:devs'));
            $form = $form
                ->add('assignedTo',     ChoiceType::class,      array(
                    'choices'       =>  $devs,
                    'choice_label' => function($devs, $key, $index) {
                        return $devs->getName();
                    },
                    'placeholder'   =>  'Select a developer',
                    'required'      =>  false,
                ));
        }

        $form = $form->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $em = $this->getDoctrine();

            if(!$security->isGranted('ROLE_ISSUE_STATUS'))
                $issue->setStatus($this->getDoctrine()->getRepository('AboveBundle:Status', 'tracker')->findOneByName('New'));

            if($security->isGranted('ROLE_QA1'))
            {
                $char = $em->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());
                if($char == NULL)
                {
                    $this->addFlash('danger', 'You must have a character on the first QA realm to add an issue.');
                    return $this->render('AboveBundle:issue:add.html.twig', array(
                        'form' => $form->createView(),
                    ));
                }
                $issue->setRealm(10);
                $issue->setGuid($char->getGuid());
                $issue->setUsername($char->getName());
            }
            elseif($security->isGranted('ROLE_GM1'))
            {
                $char = $em->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
                if($char == NULL)
                {
                    $this->addFlash('danger', 'You must have a character on Nostalrius PvP to add an issue.');
                    return $this->render('AboveBundle:issue:add.html.twig', array(
                        'form' => $form->createView(),
                    ));
                }
                $issue->setRealm(1);
                $issue->setGuid($char->geGuid());
                $issue->setUsername($char->getName());
            }
            else
            {
                $issue->setRealm($issue->getCharacters()->getRealm());
                $issue->setGuid($issue->getCharacters()->getGuid());
                $issue->setUsername($issue->getCharacters()->getName());
            }

            $issue->setCreatedAt(new \DateTime('now' , new \DateTimeZone('Europe/Berlin')));
            $issue->setUpdatedAt(new \DateTime('now' , new \DateTimeZone('Europe/Berlin')));
            $issue->setAccount($this->getUser()->getId());
            $issue->setScore(array($this->getUser()->getId()));
            $issue->setTrash(false);
            $issue->setTweet(false);
            $em->getManager('tracker')->persist($issue);
            $em->getManager('tracker')->flush();

            $this->addFlash('success', 'Thank you for your contribution! You issue was just added.');

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
        }

        return $this->render('AboveBundle:issue:add.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    /**
     * @Route("/issue/private", name="bugtracker_issue_view_private")
     * @Security("has_role('ROLE_ISSUE_PRIVATE')")
     */
    public function privatesAction(Request $request)
    {
        $cache = $this->get('app.service.cache.tracker');
        $labels     = $cache->getLabels();
        $statuses   = $cache->getStatuses();
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();

        $qb = $this->getDoctrine()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $issues = $qb
            ->select('i')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->addSelect('l')
            ->addSelect('s')
            ->addSelect('c')
            ->join('i.status', 's')
            ->leftJoin('i.labels', 'l')
            ->leftJoin('i.comments', 'c')
            ->where('i.private = :true')
            ->setParameter('true', true)
            ->orderBy('scoring', 'DESC')
            ->getQuery();

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($issues, $request->query->getInt('page', 1), $this->getParameter('knp_paginator.page_range'));

        return $this->render('AboveBundle:search:index.html.twig', array(
            'issues'    => $issues,
            'labels'    => $labels,
            'statuses'  => $statuses,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination
        ));
    }

    /**
     * @Route("/issue/trash", name="bugtracker_issue_view_trash")
     * @Security("has_role('ROLE_ISSUE_TRASH')")
     */
    public function trashedAction(Request $request)
    {
        $cache = $this->get('app.service.cache.tracker');
        $labels     = $cache->getLabels();
        $statuses   = $cache->getStatuses();
        $milestones = $cache->getMilestones();
        $devs       = $cache->getDevelopers();

        $qb = $this->getDoctrine()->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $issues = $qb
            ->select('i')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->addSelect('l')
            ->addSelect('s')
            ->addSelect('c')
            ->join('i.status', 's')
            ->leftJoin('i.labels', 'l')
            ->leftJoin('i.comments', 'c')
            ->where('i.trash = :true')
            ->setParameter('true', true)
            ->orderBy('scoring', 'DESC')
            ->getQuery();

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate($issues, $request->query->getInt('page', 1), $this->getParameter('knp_paginator.page_range'));

        return $this->render('AboveBundle:search:index.html.twig', array(
            'issues'    => $issues,
            'labels'    => $labels,
            'statuses'  => $statuses,
            'milestones'=> $milestones,
            'devs'      => $devs,
            'paginate'  => $pagination
        ));
    }

    /**
     * @Route("/issue/{id}", name="bugtracker_issue_view", requirements={
     *     "issue": "\d+"
     * })
     */
    public function indexAction(Request $request, $id)
    {
        $em = $this->getDoctrine();
        $qb = $em->getRepository('AboveBundle:Issue', 'tracker')->createQueryBuilder('i');
        $result = $qb
            ->select('i')
            ->addSelect('(SUBSTRING(i.score, 3) * 1 as scoring')
            ->addSelect('l')
            ->addSelect('s')
            ->addSelect('c')
            ->addSelect('m')
            ->join('i.status', 's')
            ->leftJoin('i.labels', 'l')
            ->leftJoin('i.comments', 'c')
            ->leftJoin('i.milestone', 'm')
            ->where('i.id = :id')
            ->setParameter('id', $id)
            ->getQuery()
            ->getResult();
        if($result == null)
            throw $this->createNotFoundException();
        $issue = $result[0][0];


        $security = $this->get('security.authorization_checker');

        $comments = $issue->getComments();
        $chars = NULL;
        if(!$comments->isEmpty())
        {
            $authors = [];
            foreach($issue->getComments() as $comment)
            {
                if($comment->getPublic() == false && !$security->isGranted('ROLE_COMMENT_PRIVATE'))
                    continue;
                $authors[$comment->getRealm()][] = $comment->getGuid();
            }

            // Add author
            if($security->isGranted('ROLE_ISSUE_AUTHOR'))
                $authors[$issue->getRealm()][] = $issue->getGuid();

            // Add AssignedTo
            if($security->isGranted('ROLE_ISSUE_ASSIGN') && $issue->getAssignedTo() != NULL)
                $authors[10][] = $issue->getAssignedTo();

            $result = [];
            foreach($authors as $realmId => $realm)
            {
                $realm = array_keys(array_flip($realm));
                $result[$realmId] = $em->getRepository('CharacterBundle:Characters', "realm{$realmId}")->findByGuid($realm);
            }

            $chars = [];
            foreach($result as $realmId => $characters)
            {
                foreach($characters as $character)
                    $chars[$realmId][$character->getGuid()] = $character;
            }
        }
        else
        {
            // Add AssignedTo
            if($security->isGranted('ROLE_ISSUE_ASSIGN') && $issue->getAssignedTo() != NULL)
                $chars[10][$issue->getAssignedTo()] = $em->getRepository('CharacterBundle:Characters', 'realm10')->find($issue->getAssignedTo());

            // Add author
            if($security->isGranted('ROLE_ISSUE_AUTHOR'))
            {
                $author = $em->getRepository('CharacterBundle:Characters', "realm{$issue->getRealm()}")->find($issue->getGuid());
                if($author != NULL)
                    $chars[$issue->getRealm()][$issue->getGuid()] = $author;
            }
        }

        if($issue->getPrivate() && $this->getUser() == NULL)
            throw $this->createAccessDeniedException();

        if($issue->getPrivate() == true && !$security->isGranted('ROLE_ISSUE_PRIVATE') && $this->getUser()->getId() != $issue->getAccount())
            throw $this->createAccessDeniedException();

        $history = $em->getRepository('Gedmo\Loggable\Entity\LogEntry', 'tracker')->getLogEntries($issue);

        $myChar = null;
        $formPublic  = null;
        $formPrivate = null;

        if($security->isGranted('IS_AUTHENTICATED_FULLY'))
        {
            $commentPublic = new Comment();
            $formPublic = $this->get('form.factory')->createBuilder(FormType::class, $commentPublic)
                ->add('comment',       TextareaType::class)
                ->add('hash',          HiddenType::class, array(
                    'data' => sha1($issue->getId() . "1e0149cbc5"),
                ))
                ->add('save',           SubmitType::class);

            if($security->isGranted('ROLE_GM1'))
                $myChar = $em->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
            elseif($security->isGranted('ROLE_QA1'))
                $myChar = $em->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());
            else
            {
                $characters = $this->get('character.service')->getAccountCharacters($this->getUser()->getId(), true);
                $realms = $this->getParameter('realms');
                $formPublic = $formPublic
                    ->add('characters',     ChoiceType::class, array(
                        'choices'       => $characters,
                        'choice_label' => function ($value, $key, $index) use ($realms) {
                            return "{$realms[$value->getRealm()]['name']} - {$value->getName()}";
                        },
                    ));
            }

            $formPublic = $formPublic
                ->getForm()
                ->createView();

            if($security->isGranted('ROLE_COMMENT_PRIVATE'))
            {
                $commentPrivate = new Comment();
                $formPrivate = $this->get('form.factory')->createBuilder(FormType::class, $commentPrivate)
                    ->add('comment',        TextareaType::class)
                    ->add('hash',          HiddenType::class, array(
                        'data' => sha1($issue->getId() . "1e0149cbc5"),
                    ))
                    ->add('save',           SubmitType::class)
                    ->getForm()
                    ->createView();
            }
        }

        return $this->render('AboveBundle:issue:index.html.twig', array(
            'myChar'        => $myChar,
            'chars'         => $chars,
            'issue'         => $issue,
            'formPublic'    => $formPublic,
            'formPrivate'   => $formPrivate,
            'history'       => $history,
        ));
    }

    /**
     * @Route("/issue/{id}/comment", name="bugtracker_issue_comment_public", requirements={
     *     "issue": "\d+"
     * })
     * @Method({"POST"})
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function commentPublicAction(Request $request, $id)
    {
        $em = $this->getDoctrine();
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $commentPublic = new Comment();

        $characters = $this->get('character.service')->getAccountCharacters($this->getUser()->getId());
        $realms = $this->getParameter('realms');

        $formPublic = $this->get('form.factory')->createBuilder(FormType::class, $commentPublic)
            ->add('characters',     ChoiceType::class, array(
                'choices'       => $characters,
                'choice_label' => function ($value, $key, $index) use ($realms) {
                    return "{$realms[$value->getRealm()]['name']} - {$value->getName()}";
                },
            ))
            ->add('comment',        TextareaType::class)
            ->add('hash',          HiddenType::class, array(
                'data' => sha1($issue->getId() . "1e0149cbc5"),
            ))
            ->add('save',           SubmitType::class)
            ->getForm();

        $formPublic->handleRequest($request);

        if($formPublic->isSubmitted() && $formPublic->isValid())
        {
            if(sha1($issue->getId() . "1e0149cbc5") != $commentPublic->getHash())
                throw new AccessDeniedHttpException;

            $security = $this->get('security.authorization_checker');
            if(!$security->isGranted('ROLE_QA1') && !$security->isGranted('ROLE_GM1'))
            {
                if($commentPublic->getCharacters() == NULL)
                {
                    $this->addFlash('danger', 'You must have a character to comment.');
                    return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
                }
                $commentPublic->setRealm((int)$commentPublic->getCharacters()->getRealm());
                $commentPublic->setGuid($commentPublic->getCharacters()->getGuid());
            }
            if($security->isGranted('ROLE_GM1') && !$security->isGranted('ROLE_ADMIN'))
            {
                $commentPublic->setRealm(1);
                $char = $em->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
                if($char == NULL)
                {
                    $this->addFlash('danger', 'You must have a character on Nostalrius PvP to comment.');
                    return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
                }
                $commentPublic->setGuid($char->getGuid());
            }
            if($security->isGranted('ROLE_QA1'))
            {
                $commentPublic->setRealm(10);
                $char = $em->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());
                if($char == NULL)
                {
                    $this->addFlash('danger', 'You must have a character on the first QA realm to comment.');
                    return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
                }
                $commentPublic->setGuid($char->getGuid());
            }

            $commentPublic->setAccount($this->getUser()->getId());
            $commentPublic->setIssue($issue);
            $commentPublic->setPublic(true);
            $em->getManager('tracker')->persist($commentPublic);
            $em->getManager('tracker')->flush();

            $this->addFlash('success', 'Thank you for your contribution! Your comment was just added.');

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
        }

        $this->addFlash('danger', 'Something went wrong with your comment.');
        return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
    }

    /**
     * @Route("/issue/{id}/comment-private", name="bugtracker_issue_comment_private", requirements={
     *     "issue": "\d+"
     * })
     * @Method({"POST"})
     * @Security("has_role('ROLE_COMMENT_PRIVATE')")
     */
    public function commentPrivateAction(Request $request, $id)
    {
        $em = $this->getDoctrine();
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $commentPrivate = new Comment();

        $formPrivate = $this->get('form.factory')->createBuilder(FormType::class, $commentPrivate)
            ->add('comment',        TextareaType::class)
            ->add('hash',          HiddenType::class, array(
                'data' => sha1($issue->getId() . "1e0149cbc5"),
            ))
            ->add('save',           SubmitType::class)
            ->getForm();

        $formPrivate->handleRequest($request);

        if($formPrivate->isSubmitted() && $formPrivate->isValid())
        {
            if(sha1($issue->getId() . "1e0149cbc5") != $commentPrivate->getHash())
                throw new AccessDeniedHttpException;

            $security = $this->get('security.authorization_checker');
            if($security->isGranted('ROLE_GM1'))
            {
                $character = $em->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
                if($character == NULL)
                {
                    $this->addFlash('danger', 'You must have a character on Nostalrius PvP to comment.');
                    return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
                }
            }
            else
            {
                $character = $em->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());
                if($character == NULL)
                {
                    $this->addFlash('danger', 'You must have a character on the first QA realm to comment.');
                    return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
                }
            }

            $commentPrivate->setAccount($this->get('security.token_storage')->getToken()->getUser()->getId());
            $commentPrivate->setRealm(1);
            $commentPrivate->setGuid($character->getGuid());
            $commentPrivate->setIssue($issue);
            $commentPrivate->setPublic(false);
            $em = $em->getManager('tracker');
            $em->persist($commentPrivate);
            $em->flush();

            $this->addFlash('success', 'Thank you for your contribution! Your comment was just added.');

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
        }

        $this->addFlash('danger', 'Something went wrong with your comment.');
        return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
    }

    /**
     * @Route("/issue/{id}/vote", name="bugtracker_issue_vote", requirements={
     *     "issue": "\d+"
     * })
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function voteAction(Request $request, $id)
    {
        // Check if issue exists
        $em = $this->getDoctrine()->getManager('tracker');
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue === null)
            throw new NotFoundHttpException;

        if($issue->getStatus()->getName() == 'Invalid' || $issue->getStatus()->getName() == 'Duplicate' || $issue->getStatus()->getName() == 'Resolved')
            return new Response();

        $user = $this->getUser();

        // If user already in score, remove its vote else add it
        $score = $issue->getScore();
        $vote = array_search($user->getId(), $score, true);

        if($vote === false)
            $score[] = $user->getId();
        else
            unset($score[$vote]);

        $issue->setScore(array_unique($score));
        $em->flush();

        return new Response();
    }

    /**
     * @Route("/issue/{id}/edit", name="bugtracker_issue_edit", requirements={
     *     "issue": "\d+"
     * })
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function editAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $user = $this->getUser();

        $security = $this->get('security.authorization_checker');

        if($user->getId() != $issue->getAccount() && !$security->isGranted('ROLE_ISSUE_EDIT'))
                throw $this->createAccessDeniedException();

        $form = $this->get('form.factory')->createBuilder(FormType::class, $issue);

        if($security->isGranted('ROLE_ISSUE_TITLE'))
            $form = $form->add('title', TextType::class);
        else
        {
            $form = $form
                ->add('title', TextType::class, array(
                    'disabled' => true,
                ));
        }

        $redis = $this->get('snc_redis.default');

        if($security->isGranted('ROLE_ISSUE_LABELS'))
            $form = $form->add('labels', EntityType::class, array('class' => 'AboveBundle:Label', 'multiple' => true, 'required' => false));

        if($security->isGranted('ROLE_ISSUE_STATUS'))
            $form = $form->add('status', EntityType::class, array('class' => 'AboveBundle:Status'));

        if($security->isGranted('ROLE_ISSUE_MILESTONE'))
            $form = $form->add('milestone', EntityType::class, array( 'class' => 'AboveBundle:Milestone', 'placeholder'  => 'Select a milestone', 'required' => false));

        if($security->isGranted('ROLE_ISSUE_ASSIGN'))
        {
            $devs = unserialize($this->get('snc_redis.default')->get('bugtracker:devs'));
            $form = $form
                ->add('assignedTo',     ChoiceType::class,      array(
                    'choices'       =>  $devs,
                    'choice_label' => function($devs, $key, $index) {
                        return $devs->getName();
                    },
                    'placeholder'   =>  'Select a developer',
                    'required'      =>  false,
                ));
        }

        $form = $form
            ->add('buggedInfo',     TextareaType::class)
            ->add('correctInfo',    TextareaType::class)
            ->add('sources',        TextareaType::class)
            ->add('save',           SubmitType::class)
            ->add('private',        CheckboxType::class, array(
                'label' => 'Only display this issue for the Elysium team',
                'required'  => false,
            ))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            if($issue->getAssignedTo() != NULL)
                $issue->setAssignedTo($issue->getAssignedTo()->getGuid());

            if($user->getId() == $issue->getAccount() && !$security->isGranted('ROLE_ISSUE_EDIT'))
            {
                $author = $this->getDoctrine()->getRepository('CharacterBundle:Characters', "realm{$issue->getRealm()}")->find($issue->getGuid());
                $issue->setUsername($author->getName());
            }
            else
            {
                if($security->isGranted('ROLE_GM1')  || $security->isGranted('ROLE_ADMIN'))
                {
                    $char = $this->getDoctrine()->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
                    if($char == NULL)
                    {
                        $this->addFlash('danger', 'You must have a character on Nostalrius PvP.');
                        return $this->redirectToRoute('bugtracker_issue_edit', array('id' => $issue->getId()));
                    }
                    $issue->setUsername($char->getName());
                }
                else
                {
                    $char = $this->getDoctrine()->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());
                    if($char == NULL)
                    {
                        $this->addFlash('danger', 'You must have a character on the first QA realm.');
                        return $this->redirectToRoute('bugtracker_issue_edit', array('id' => $issue->getId()));
                    }
                    $issue->setUsername($char->getName());
                }
            }

            if($issue->getStatus()->getName() != 'Resolved' && $issue->getTweet() == true)
                $issue->setTweet(false);

            // Tweet if the issue is resolved
            if($issue->getStatus()->getName() == 'Resolved' && $issue->getTweet() == false && $this->getParameter('twitter_feature') == 'enabled')
            {
                $connection = new TwitterOAuth(
                    $this->getParameter('twitter_consumer_key'),
                    $this->getParameter('twitter_consumer_secret'),
                    $this->getParameter('twitter_access_token'),
                    $this->getParameter('twitter_access_token_secret')
                );

                if(strlen($issue->getTitle()) >= 33)
                    $title = $title = substr($issue->getTitle(), 0, 32) . "…";
                else
                    $title = substr($issue->getTitle(), 0, 33);

                $status = "Issue #{$id}: \"{$title}\" will be resolved after our Friday weekly update. https://elysium-project.org/bugtracker/issue/{$id}";

                $connection->post('statuses/update',['status' => $status]);
                $issue->setTweet(true);
            }
            $em->flush();
            $this->addFlash('success', 'The issue was successfully edited.');

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $id));
        }

        return $this->render('AboveBundle:issue:edit.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    /**
     * @Route("/issue/{id}/trash", name="bugtracker_issue_trash", requirements={
     *     "issue": "\d+"
     * })
     * @Security("has_role('ROLE_ISSUE_TRASH')")
     */
    public function trashAction(Request $request, $id)
    {
        $issue = $this->getDoctrine()->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $form = $this->get('form.factory')->create();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $em = $this->getDoctrine()->getManager('tracker');
            $issue->setTrash(true);
            $issue->setPrivate(false);
            $em->flush();

            $this->addFlash('info', "The issue has been trashed.");

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $id));
        }

        return $this->render('AboveBundle:issue:trash.html.twig', array(
            'issue' => $issue,
            'form'  => $form->createView(),
        ));
    }

    /**
     * @Route("/issue/{id}/assign", name="bugtracker_issue_assign", requirements={
     *     "issue": "\d+"
     * })
     * @Security("has_role('ROLE_ISSUE_ASSIGN')")
     */
    public function assignAction(Request $request, $id)
    {
        $em = $this->getDoctrine();
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        if($this->get('security.authorization_checker')->isGranted('ROLE_ADMIN'))
            $myChar = $em->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
        else
            $myChar = $em->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());

        if($myChar == NULL)
            $this->addFlash('error', 'You need to create a character on QA realms.');
        else
        {
            $issue->setAssignedTo($myChar->getGuid());
            $issue->setUsername($myChar->getName());
            $issue->setStatus($this->getDoctrine()->getRepository('AboveBundle:Status', 'tracker')->findOneByName('WIP'));
            $em->getManager('tracker')->flush();
        }
        $this->addFlash('success', "You are now assigned to issue #{$id}.");

        return $this->redirectToRoute('bugtracker_issue_view', array('id' => $id));
    }

    /**
     * @Route("/issue/{id}/revoke", name="bugtracker_issue_revoke", requirements={
     *     "issue": "\d+"
     * })
     * @Security("has_role('ROLE_ISSUE_ASSIGN')")
     */
    public function revokeAction(Request $request, $id)
    {
        $em = $this->getDoctrine();
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        if($this->get('security.authorization_checker')->isGranted('ROLE_ADMIN'))
            $myChar = $em->getRepository('CharacterBundle:Characters', 'realm1')->findOneByAccount($this->getUser()->getId());
        else
            $myChar = $em->getRepository('CharacterBundle:Characters', 'realm10')->findOneByAccount($this->getUser()->getId());

        if($myChar == NULL)
            $this->addFlash('error', 'You need to create a character on QA realms.');
        else
        {
            $issue->setUsername($myChar->getName());
            $issue->setAssignedTo(NULL);
            $issue->setStatus($em->getRepository('AboveBundle:Status', 'tracker')->findOneByName('Confirmed'));
            $em->getManager('tracker')->flush();
            $this->addFlash('success', "You are not assigned anymore to issue #{$id}.");
        }

        return $this->redirectToRoute('bugtracker_issue_view', array('id' => $id));
    }

    /**
     * @Route("/issue/{id}/untrash", name="bugtracker_issue_untrash", requirements={
     *     "issue": "\d+"
     * })
     * @Security("has_role('ROLE_ISSUE_TRASH')")
     */
    public function untrashAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $form = $this->get('form.factory')->create();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $issue->setTrash(false);
            $em->flush();

            $this->addFlash('info', "The issue has been trashed.");

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $id));
        }

        return $this->render('AboveBundle:issue:trash.html.twig', array(
            'issue' => $issue,
            'form'  => $form->createView(),
        ));
    }

    /**
     * @Route("/issue/{id}/private", name="bugtracker_issue_private", requirements={
     *     "issue": "\d+"
     * })
     * @Security("has_role('ROLE_ISSUE_PRIVATE')")
     */
    public function privateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $form = $this->get('form.factory')->create();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $issue->setPrivate(true);
            $issue->setTrash(false);
            $em->flush();

            $this->addFlash('info', "The issue is now private.");

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
        }

        return $this->render('AboveBundle:issue:private.html.twig', array(
            'issue' => $issue,
            'form'  => $form->createView(),
        ));
    }

    /**
     * @Route("/issue/{id}/unprivate", name="bugtracker_issue_unprivate", requirements={
     *     "issue": "\d+"
     * })
     * @Security("has_role('ROLE_ISSUE_PRIVATE')")
     */
    public function unprivateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager('tracker');
        $issue = $em->getRepository('AboveBundle:Issue', 'tracker')->find($id);

        if($issue == null)
            throw $this->createNotFoundException();

        $form = $this->get('form.factory')->create();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $issue->setPrivate(false);
            $em->flush();

            $this->addFlash('info', "The issue is now public.");

            return $this->redirectToRoute('bugtracker_issue_view', array('id' => $issue->getId()));
        }

        return $this->render('AboveBundle:issue:private.html.twig', array(
            'issue' => $issue,
            'form'  => $form->createView(),
        ));
    }
}
