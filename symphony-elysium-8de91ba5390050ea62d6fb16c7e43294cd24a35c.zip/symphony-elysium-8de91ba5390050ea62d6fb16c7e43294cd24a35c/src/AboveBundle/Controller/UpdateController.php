<?php

namespace AboveBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AboveBundle\Entity\Status;
use Doctrine\ORM\Tools\Pagination\Paginator;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use AuthBundle\Entity\Account;
use CharacterBundle\Entity\Characters;
use CharacterBundle\Entity\Guild;

/**
 * Class UpdateController
 * @package AboveBundle\Controller
 */
class UpdateController extends Controller
{
    /**
     * @Route("/update/dev", name="bugtracker_update_dev")
     * @Security("has_role('ROLE_ADMIN')")
     */
    public function updateDevAction(Request $request)
    {
        $redis = $this->get('snc_redis.default');
        $accs = $this->getDoctrine()->getRepository('AuthBundle:AccountAccess', 'auth')->findBySuperiorGmLevel(2, array(10,11,-1));
        $chars = [];
        foreach($accs as $acc)
            $chars[] = $acc->getId();
        $devs = $this->getDoctrine()->getRepository('CharacterBundle:Characters', 'realm10')->findOnePerAccount($chars);
        $redis->set('bugtracker:devs', serialize($devs));
        $redis->ttl('bugtracker:devs');

        return $this->render('AboveBundle:update:index.html.twig', array('data' => $devs));
    }
}