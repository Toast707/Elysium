<?php

namespace AppBundle\Service;

use Doctrine\ORM\Query\Expr;
use AppBundle\Entity\News;
use Symfony\Component\DependencyInjection\ContainerInterface;

class CacheService
{
    private $redis;
    private $em;
    private $paginator;
    private $container;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $this->redis     = $container->get('snc_redis.default');
        $this->em        = $container->get('doctrine');
        $this->paginator = $container->get('knp_paginator');
    }

    /**
     * @param $redis
     * @param $request
     * @return mixed
     */
    public function get($redis, $request)
    {
        $data = $this->redis->get($redis);
        if(!$data)
        {
            $data = $request;
            $this->redis->set($redis, serialize($data));
            $this->redis->expire($redis, 60);
            $this->redis->ttl($redis);
        }
        else
            $data = unserialize($data);

        return $data;
    }

    /**
     * @param $page
     * @return mixed
     */
    public function getNews($page)
    {
        $news = $this->redis->get("website:news");
        if(!$news)
        {
            $news = $this->em->getManager('web')->getRepository('AppBundle:News')->findBy(array('type' => News::TYPE_NEWS, 'enabled' => true), array('createdAt' => 'DESC'));
            $this->redis->set("website:news", serialize($news));
            $this->redis->expire("website:news", 60);
            $this->redis->ttl("website:news");
        }
        else
            $news = unserialize($news);

        $news = $this->paginator->paginate($news, $page, 3);

        return $news;
    }

    /**
     * @return mixed
     */
    public function getLastPatch()
    {
        $patch = $this->redis->get("website:lastpatch");
        if(!$patch)
        {
            $patch = $this->em->getManager('web')->getRepository('AppBundle:News')->findOneBy(array('type' => News::TYPE_PATCHNOTES, 'enabled' => true), array('createdAt' => 'DESC'));

            $this->redis->set("website:lastpatch", serialize($patch));
            $this->redis->expire("website:lastpatch", 60);
            $this->redis->ttl("website:lastpatch");
        }
        else
            $patch = unserialize($patch);

        return $patch;
    }

    /**
     * @return mixed
     */
    public function getPatches()
    {
        $patch = $this->redis->get("website:patches");
        if(!$patch)
        {
            $patch = $this->em->getManager('web')->getRepository('AppBundle:News')->findBy(array('type' => News::TYPE_PATCHNOTES, 'enabled' => true), array('createdAt' => 'DESC'));

            $this->redis->set("website:patches", serialize($patch));
            $this->redis->expire("website:patches", 60);
            $this->redis->ttl("website:patches");
        }
        else
            $patch = unserialize($patch);

        return $patch;
    }

    /**
     * @return mixed
     */
    public function getGmAccounts()
    {
        $gmAccounts = $this->redis->get("website:gm_accounts");
        if(!$gmAccounts)
        {
            $gmAccounts = $this->em->getRepository('AuthBundle:Account', 'auth')->findGmAccounts();
            foreach($gmAccounts as $account)
                $account->setCharacters($this->container->get('character.service')->getAccountCharacters($account->getId()));
            $this->redis->set("website:gm_accounts", serialize($gmAccounts));
            $this->redis->expire("website:gm_accounts", 3600);
            $this->redis->ttl("website:gm_accounts");
        }
        else
            $gmAccounts = unserialize($gmAccounts);

        return $gmAccounts;
    }

    /**
     * @return array
     */
    public function getRealmStatus()
    {
        $status = $this->redis->get("website:realm_status");
        if(!$status)
        {
            $realms = $this->em->getRepository('AuthBundle:Realmlist', 'auth')->findAll();
            $status = [];
            foreach($realms as $realm)
            {
                $em = false;
                foreach (array_keys($this->em->getManagers()) as $name) {
                    if($name == "realm{$realm->getId()}")
                        $em = true;
                }
                if(!$em)
                    continue;

                $fp = @fsockopen($realm->getAddress(), $realm->getPort(), $errno, $errstr, 0.2);
                $status[$realm->getId()] = [
                    'name' => $realm->getName(),
                ];
                if($fp)
                {
                    fclose($fp);
                    $status[$realm->getId()]['online']  = true;
                    $status[$realm->getId()]['players'] = $this->em->getRepository('CharacterBundle:Characters', "realm{$realm->getId()}")->countOnlinePlayers();
                    $status[$realm->getId()]['horde'] = $this->em->getRepository('CharacterBundle:Characters', "realm{$realm->getId()}")->countHordeOnlinePlayers();
                    $uptime = $this->em->getRepository('AuthBundle:Uptime', 'auth')->findOneBy(array('realmid' => $realm->getId()), array('starttime' => 'DESC'));
                    $status[$realm->getId()]['uptime'] = $uptime->getStarttime();
                }
                else
                {
                    $status[$realm->getId()]['online']  = false;
                    $status[$realm->getId()]['players'] = 0;
                    $status[$realm->getId()]['uptime']  = null;
                }
                $status[$realm->getId()]['security'] = $realm->getAllowedSecurityLevel();
            }
            ksort($status);
            $this->redis->set('website:realm_status', serialize($status));
            $this->redis->expire('website:realm_status', 60);
            $this->redis->ttl('website:realm_status');
        }
        else
            $status = unserialize($status);

        return $status;
    }
}