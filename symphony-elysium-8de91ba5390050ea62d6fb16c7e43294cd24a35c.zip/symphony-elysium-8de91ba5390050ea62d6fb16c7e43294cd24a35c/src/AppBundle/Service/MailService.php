<?php

namespace AppBundle\Service;

use Doctrine\ORM\Query\Expr;
use AppBundle\Entity\News;

class MailService
{
    private $mailer;
    private $templating;

    /**
     * @param $mailer
     * @param $templating
     */
    public function __construct($mailer, $templating)
    {
        $this->mailer = $mailer;
        $this->templating = $templating;
    }

    /**
     * @param           $subject
     * @param array     $to
     * @param           $view
     * @param array     $data
     * @param bool|true $send
     */
    public function sendMail($subject, array $to, $view, array $data, $send = true)
    {
        $message = \Swift_Message::newInstance()
            ->setSubject($subject)
            ->setTo($to)
            ->setBody($this->templating->render("email/{$view}.html.twig", $data),
                'text/html'
            )->addPart(
                $this->templating->render("email/{$view}.txt.twig", $data),
                'text/plain'
            );//->attachSigner(new Swift_Signers_DKIMSigner($this->getParameter('mailer_dkim'), $this->getParameter('mailer_sender'), 'default'));
        if($send)
            $this->mailer->send($message);
    }

    /**
     * @param int $length
     * @return string
     */
    public function getCode($length = 15)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $activationCode = '';
        for ($i = 0; $i < $length; $i++)
            $activationCode .= $characters[rand(0, $charactersLength - 1)];
        return $activationCode;
    }

}