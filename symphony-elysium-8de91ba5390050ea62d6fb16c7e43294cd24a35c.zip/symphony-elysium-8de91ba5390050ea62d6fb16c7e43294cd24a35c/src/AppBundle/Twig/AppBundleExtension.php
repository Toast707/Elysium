<?php

namespace AppBundle\Twig;

class AppBundleExtension extends \Twig_Extension
{
    protected $em;

    public function __construct($em)
    {
        $this->em = $em;
    }

    public function getName() {
        return "AppBundle_extension";
    }

    public function getFilters()
    {
        return array(
            'ApiItemBonding'        => new \Twig_SimpleFilter('ApiItemBonding',         array($this, 'ApiItemBonding')),
            'ApiItemInventoryType'  => new \Twig_SimpleFilter('ApiItemInventoryType',   array($this, 'ApiItemInventoryType')),
            'ApiItemSubclasse'      => new \Twig_SimpleFilter('ApiItemSubclass',        array($this, 'ApiItemSubclass')),
            'ApiItemStat'           => new \Twig_SimpleFilter('ApiItemStat',            array($this, 'ApiItemStat')),
            'ApiItemBonus'          => new \Twig_SimpleFilter('ApiItemBonus',           array($this, 'ApiItemBonus')),
            'ApiItemSpellInfo'      => new \Twig_SimpleFilter('ApiItemSpellInfo',       array($this, 'ApiItemSpellInfo')),
            'ApiItemConditionColor' => new \Twig_SimpleFilter('ApiItemConditionColor',  array($this, 'ApiItemConditionColor')),
            'ApiItemSocketColor'    => new \Twig_SimpleFilter('ApiItemSocketColor',     array($this, 'ApiItemSocketColor')),
            'ApiItemReqClass'       => new \Twig_SimpleFilter('ApiItemReqClass',        array($this, 'ApiItemReqClass')),
            'ApiItemReqRace'        => new \Twig_SimpleFilter('ApiItemReqRace',         array($this, 'ApiItemReqRace')),
            'ApiItemReplaceValue'   => new \Twig_SimpleFilter('ApiItemReplaceValue',    array($this, 'ApiItemReplaceValue')),
            'ApiItemSetBonus'       => new \Twig_SimpleFilter('ApiItemSetBonus',        array($this, 'ApiItemSetBonus')),
            'ApiItemMetaCondition'  => new \Twig_SimpleFilter('ApiItemMetaCondition',   array($this, 'ApiItemMetaCondition')),
            'ApiItemSpellTrigger'   => new \Twig_SimpleFilter('ApiItemSpellTrigger',    array($this, 'ApiItemSpellTrigger')),
            'ApiItemDamageType'     => new \Twig_SimpleFilter('ApiItemDamageType',      array($this, 'ApiItemDamageType')),
            'ApiItemFlags'          => new \Twig_SimpleFilter('ApiItemFlags',           array($this, 'ApiItemFlags')),
            'ApiItemReputationRank' => new \Twig_SimpleFilter('ApiItemReputationRank',  array($this, 'ApiItemReputationRank')),

            'getMoney'              => new \Twig_SimpleFilter('getMoney',               array($this, 'getMoney')),
            'getFactionImage'       => new \Twig_SimpleFilter('getFactionImage',        array($this, 'getFactionImage')),
            'getRaceImage'          => new \Twig_SimpleFilter('getRaceImage',           array($this, 'getRaceImage')),
            'getClassImage'         => new \Twig_SimpleFilter('getClassImage',          array($this, 'getClassImage')),
            'linkify' 	            => new \Twig_SimpleFilter('linkify',                array($this, 'linkify'), array('pre_escape' => 'html', 'is_safe' => array('html'))),
            'timeSince'             => new \Twig_SimpleFilter('timeSince',              array($this, 'timeSince')),
            'secondsToTime'         => new \Twig_SimpleFilter('secondsToTime',          array($this, 'secondsToTime')),
            'getTradeItems'         => new \Twig_SimpleFilter('getTradeItems',          array($this, 'getTradeItems')),
        );
    }

    function ApiItemSetBonus($item)
    {
        $set = $item->getItemSet();
        $bonus = [];
        for($i = 0; $i <= 7; $i++)
        {
            if($set->getSetThreshold($i) > 0)
                $bonus[$set->getSetThreshold($i)] = $i;
        }
        $description = '';
        ksort($bonus);
        foreach($bonus as $k => $b)
        {
            if(get_class($set->getSetSpellid($b)) == 'SpellTemplate')
                $description .= "<span>($k) Set : <a href=\"/spell={$set->getSetSpellid($b)->getEntry()}\">{$this->ApiItemReplaceValue($set->getSetSpellid($b)->getDescription()->getDescriptionLangEnUs(), $set->getSetSpellid($b), $item, $b)}</a></span><br />";
        }
        echo $description;
    }

    function ApiItemMetaCondition($condition, $gems)
    {
        $description = '';
        $q = 0;
        for($i = 0; $i <= 4; $i++)
        {
            if($condition->getOperator($i) == 3)
            {
                if($gems[$this->ApiItemConditionColor($condition->getLtOperandType($i))] > $gems[$this->ApiItemConditionColor($condition->getRtOperandType($i))])
                    $q = 1;
                $description .= "<span class=\"q{$q}\">Requires more {$this->ApiItemConditionColor($condition->getLtOperandType($i))} gems than {$this->ApiItemConditionColor($condition->getRtOperandType($i))} gems</span><br />";

            }
            if($condition->getOperator($i) == 5)
            {
                if($gems[$this->ApiItemConditionColor($condition->getLtOperandType($i))] > $condition->getRtOperand($i))
                    $q = 1;
                $description .= "<span class=\"q{$q}\">Requires at least {$condition->getRtOperand($i)} {$this->ApiItemConditionColor($condition->getLtOperandType($i))} gems</span><br />";
            }
        }
        return [ 'description' => $description, 'boolean' => $q ];
    }

    function ApiItemReplaceValue($description, $spell, $item, $id)
    {
        for($i = 1; $i <= 3; $i++)
        {
            if(preg_match('/\$s([1-3])/', $description, $matches))
                $description = str_replace("\$s{$matches[1]}", abs($spell->getEffectBasePoints($matches[1]) + 1), $description);
            if(preg_match('/\$([0-9]+)s([1-3])/', $description, $matches))
            {
                $trigger = $this->em->getRepository('AppBundle:World\SpellTemplate')->find($matches[1]);
                $description = str_replace("\${$matches[1]}s{$matches[2]}", abs($trigger->getEffectBasePoints($matches[2]) + 1), $description);
            }

            if(preg_match('/\$m([1-3])/', $description, $matches))
                $description = str_replace("\$m{$matches[1]}", $spell->getEffectBasePoints($matches[1]) + 1, $description);
            if(preg_match('/\$([0-9]+)m([1-3])/', $description, $matches))
            {
                $trigger = $this->em->getRepository('AppBundle:World\SpellTemplate')->find($matches[1]);
                $description = str_replace("\${$matches[1]}m{$matches[2]}", $trigger->getEffectBasePoints($matches[2]) + 1, $description);
            }

            if(preg_match('/\$d([0-9]+|)/', $description, $matches))
                $description = str_replace("\$d{$matches[1]}", $this->secondsToTime($spell->getDurationIndex()->getDuration()), $description);
            if(preg_match('/\$([0-9]+)d([0-9]+|)/', $description, $matches))
            {
                $trigger = $this->em->getRepository('AppBundle:World\SpellTemplate')->find($matches[1]);
                $description = str_replace("\${$matches[1]}d{$matches[2]}", $this->secondsToTime($trigger->getDurationIndex()->getDuration()), $description);
            }
            if(preg_match('/\$a([0-9]+|)/', $description, $matches))
                $description = str_replace("\$a{$matches[1]}", $spell->getEffectRadiusIndex($matches[1])->getRadius(), $description);

            if(preg_match('#\$([0-9\/]+);s([1-3])#', $description, $matches))
            {
                $effect = abs($spell->getEffectBasePoints($matches[2]) + 1);
                $description = str_replace("\${$matches[1]};s{$matches[2]}", "\${{$effect}{$matches[1]}}", $description);
            }

            if(preg_match('/\${(.*)}([A-z0-9\.]+|)( |.)/', $description, $matches))
            {
                eval( '$result = (' . $matches[1]. ');' );
                $description = str_replace("{$matches[2]}", '', $description);
                $description = str_replace("\${{$matches[1]}}", (float) number_format($result, 2), $description);
            }
        }
        if($spell->getRecoveryTime() > 0 && $item->getSpellcooldown($id) > 0)
        {
            $time = ucwords($this->secondsToTime($spell->getRecoveryTime()));
            $description .= " ({$time} Cooldown)";
        }
        if($spell->getRecoveryTime() == 0 && $item->getSpellcooldown($id) > 0)
        {
            $time = ucwords($this->secondsToTime($item->getSpellcooldown($id)));
            $description .= " ({$time} Cooldown)";
        }
        $description = str_replace("'", "\'", $description);
        return $description;
    }

    function ApiItemFlags($flags)
    {
        $flags = dechex(intval($flags));
        if($flags & 80000)
            echo '<br />Unique-Equipped';
    }

    function ApiItemReputationRank($rank)
    {
        switch($rank)
        {
            case 0: echo "Hated"; break;
            case 1: echo "Hostile"; break;
            case 2: echo "Unfriendly"; break;
            case 3: echo "Neutral"; break;
            case 4: echo "Friendly"; break;
            case 5: echo "Honored"; break;
            case 6: echo "Revered"; break;
            case 7: echo "Exalted"; break;
            default:;
        }
    }

    function ApiItemDamageType($type)
    {
        switch(intval($type))
        {
            case 0: echo "Damage"; break;
            case 1: echo "Holy Damage"; break;
            case 2: echo "Fire Damage"; break;
            case 3: echo "Nature Damage"; break;
            case 4: echo "Frost Damage"; break;
            case 5: echo "Shadow Damage"; break;
            case 6: echo "Arcane Damage"; break;
            default:;
        }
    }

    function ApiItemSpellTrigger($trigger)
    {
        switch(intval($trigger))
        {
            case 0: echo "Use:"; break;
            case 1: echo "Equip:"; break;
            case 2: echo "Chance on hit:"; break;
            default:;
        }
    }

    function ApiItemReqClass($class)
    {
        $result = '';
        if($class & 1)
            $result .= '<a href="/class=1" class="c1">Warrior</a>, ';
        if($class & 2)
            $result .= '<a href="/class=2" class="c2">Paladin</a>, ';
        if($class & 4)
            $result .= '<a href="/class=3" class="c3">Hunter</a>, ';
        if($class & 8)
            $result .= '<a href="/class=4" class="c4">Rogue</a>, ';
        if($class & 16)
            $result .= '<a href="/class=5" class="c5">Priest</a>, ';
        if($class & 64)
            $result .= '<a href="/class=7" class="c7">Shaman</a>, ';
        if($class & 128)
            $result .= '<a href="/class=8" class="c8">Mage</a>, ';
        if($class & 256)
            $result .= '<a href="/class=9" class="c9">Warlock</a>, ';
        if($class & 1024)
            $result .= '<a href="/class=11" class="c11">Druid</a>';
        echo rtrim($result, ', ');
    }

    function ApiItemReqRace($race)
    {
        $result = '';
        if($race & 1)
            $result .= 'Human, ';
        if($race & 2)
            $result .= 'Orc, ';
        if($race & 4)
            $result .= 'Dwarf, ';
        if($race & 8)
            $result .= 'Night Elf, ';
        if($race & 16)
            $result .= 'Undead, ';
        if($race & 32)
            $result .= 'Tauren, ';
        if($race & 64)
            $result .= 'Gnome, ';
        if($race & 128)
            $result .= 'Troll, ';
        if($race & 512)
            $result .= 'Blood Elf, ';
        if($race & 1024)
            $result .= 'Draenei';
        echo rtrim($result, ', ');
    }

    function ApiItemSocketColor($socket)
    {
        switch(intval($socket))
        {
            case 1: return "Meta"; break;
            case 2: return "Red"; break;
            case 4: return "Yellow"; break;
            case 8: return "Blue"; break;
            default: return;
        }
    }

    function ApiItemConditionColor($socket)
    {
        switch(intval($socket))
        {
            case 2: return "Red"; break;
            case 3: return "Yellow"; break;
            case 4: return "Blue"; break;
            default: return;
        }
    }

    /**     *
     * Convert number of seconds into hours, minutes and seconds
     * and return an array containing those values
     *
     * @param           $inputSeconds
     * @param bool|true $ms
     * @return string
     */
    function secondsToTime($inputSeconds, $ms = true)
    {
        // ms to s
        if($ms === true)
            $inputSeconds = $inputSeconds / 1000;

        $secondsInAMinute = 60;
        $secondsInAnHour  = 60 * $secondsInAMinute;
        $secondsInADay    = 24 * $secondsInAnHour;

        // extract days
        $days = floor($inputSeconds / $secondsInADay);

        // extract hours
        $hourSeconds = $inputSeconds % $secondsInADay;
        $hours = floor($hourSeconds / $secondsInAnHour);

        // extract minutes
        $minuteSeconds = $hourSeconds % $secondsInAnHour;
        $minutes = floor($minuteSeconds / $secondsInAMinute);

        // extract the remaining seconds
        $remainingSeconds = $minuteSeconds % $secondsInAMinute;
        $seconds = ceil($remainingSeconds);

        // return the final array
        $time = array(
            'd' => (int) $days,
            'h' => (int) $hours,
            'm' => (int) $minutes,
            's' => (int) $seconds,
        );

        $for = '';
        if($time['d'] == 1)
            $for .= "{$time['d']} day ";
        if($time['d'] > 1)
            $for .= "{$time['d']} days ";

        if($time['h'] == 1)
            $for .= "{$time['h']} hour ";
        if($time['h'] > 1)
            $for .= "{$time['h']} hours ";

        if($time['m'] == 1)
            $for .= "{$time['m']} min ";
        if($time['m'] > 1)
            $for .= "{$time['m']} min ";

        if($time['s'] == 1)
            $for .= "{$time['s']} sec";
        if($time['s'] > 1)
            $for .= "{$time['s']} sec";
        return $for;
    }

    function ApiItemStat($item)
    {
        $health     = '';
        $mana       = '';
        $agility    = '';
        $strength   = '';
        $intellect  = '';
        $spirit     = '';
        $stamina    = '';
        $hres       = '';
        $fres       = '';
        $nres       = '';
        $f2res      = '';
        $sres       = '';
        $ares       = '';
        
        for($i = 1; $i <= 10; $i++)
        {
            $type = $item->getStatType($i);
            $value = $item->getStatValue($i);
            
            switch(intval($type))
            {
                case 0:
                    if($value != 0)
                    {
                        $mana    = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                        $mana   .= " Mana</span><br />";
                    }
                    break;
                case 1:
                    $health  = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                    $health .= " Health</span><br />";
                    break;
                case 3:
                    $agility  = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                    $agility .= " Agility</span><br />";
                    break;
                case 4:
                    $strength   = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                    $strength  .= " Strength</span><br />";
                    break;
                case 5:
                    $intellect  = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                    $intellect .= " Intellect</span><br />";
                    break;
                case 6:
                    $spirit  = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                    $spirit .= " Spirit</span><br />";
                    break;
                case 7:
                    $stamina  = "<span>" . ($value > 0) ? "+{$value}" : "-{$value}";
                    $stamina .= " Stamina</span><br />";
                    break;
                default:;
            }
        }
        if($item->getHolyRes() > 0)
        {
            $hres  = "<span>" . ($item->getHolyRes() > 0) ? "+{$item->getHolyRes()}" : "-{$item->getHolyRes()}";
            $hres .= " Holy Resistance</span><br />";
        }
        if($item->getFireRes() > 0)
        {
            $fres  = "<span>" . ($item->getFireRes() > 0) ? "+{$item->getFireRes()}" : "-{$item->getFireRes()}";
            $fres .= " Fire Resistance</span><br />";
        }
        if($item->getNatureRes() > 0)
        {
            $nres  = "<span>" . ($item->getNatureRes() > 0) ? "+{$item->getNatureRes()}" : "-{$item->getNatureRes()}";
            $nres .= " Nature Resistance</span><br />";
        }
        if($item->getFrostRes() > 0)
        {
            $f2res  = "<span>" . ($item->getFrostRes() > 0) ? "+{$item->getFrostRes()}" : "-{$item->getFrostRes()}";
            $f2res .= " Frost Resistance</span><br />";
        }
        if($item->getShadowRes() > 0)
        {
            $sres  = "<span>" . ($item->getShadowRes() > 0) ? "+{$item->getShadowRes()}" : "-{$item->getShadowRes()}";
            $sres .= " Shadow Resistance</span><br />";
        }
        if($item->getArcaneRes() > 0)
        {
            $ares  = "<span>" . ($item->getArcaneRes() > 0) ? "+{$item->getArcaneRes()}" : "-{$item->getArcaneRes()}";
            $ares .= " Arcane Resistance</span><br />";
        }

        echo $strength.$agility.$stamina.$intellect.$spirit.$health.$mana.$hres.$fres.$nres.$f2res.$sres.$ares;
    }

    function ApiItemBonus($item)
    {
        $info = '';
        
        for($i = 1; $i <= 10; $i++)
        {
            $type = $item->getStatType($i);

            $value = $item->getStatValue($i);

            switch(intval($type))
            {
                case 12: $info  .= "<span class=\"q2\">Equip: Increases defense rating by {$value}.</span><br />"; break;
                case 13: $info  .= "<span class=\"q2\">Equip: Increases your dodge rating by {$value}.</span><br />"; break;
                case 14: $info  .= "<span class=\"q2\">Equip: Increases your parry rating by {$value}.</span><br />"; break;
                case 15: $info  .= "<span class=\"q2\">Equip: Increases your block rating by {$value}.</span><br />"; break;
                case 16:
                case 31:
                    $info .= "<span class=\"q2\">Equip: Improves hit rating by {$value}.</span><br />"; break;
                case 17: $info  .= "<span class=\"q2\">Equip: Improves ranged hit rating by {$value}.</span><br />"; break;
                case 18: $info  .= "<span class=\"q2\">Equip: Improves spell hit rating by {$value}.</span><br />"; break;
                case 19: $info  .= "<span class=\"q2\">Equip: Improves ranged critical strike rating by {$value}.</span><br />"; break;
                case 20:
                case 32:
                    $info .= "<span class=\"q2\">Equip: Improves critical strike rating by {$value}.</span><br />"; break;
                case 21: $info  .= "<span class=\"q2\">Equip: Improves spell critical strike rating by {$value}.</span><br />"; break;
                case 30: $info  .= "<span class=\"q2\">Equip: Improves spell haste rating by {$value}.</span><br />"; break;
                case 35: $info  .= "<span class=\"q2\">Equip: Improves your resilience rating by {$value}.</span><br />"; break;
                case 36: $info  .= "<span class=\"q2\">Equip: Improves haste rating by {$value}.</span><br />"; break;
                case 37: $info  .= "<span class=\"q2\">Equip: Increases your expertise rating by {$value}.</span><br />"; break;
                default:;
            }
        }
        echo $info;
        return;
    }

    function ApiItemSubclass($class, $subclass)
    {
        switch(intval($class))
        {
            case 0:
                switch($subclass)
                {
                    case 1: echo 'Potion'; break;
                    case 2: echo 'Elixir'; break;
                    case 3: echo 'Flask'; break;
                    case 4: echo 'Scroll'; break;
                    case 5: echo 'Food & Drink'; break;
                    case 6: echo 'Item Enhancement'; break;
                    case 7: echo 'Bandage'; break;
                    case 8: echo 'Other'; break;
                    default: echo 'Consumable';
                }
                break;
            case 1:
                switch($subclass)
                {
                    case 1: echo 'Soul Bag'; break;
                    case 2: echo 'Herb Bag'; break;
                    case 3: echo 'Enchanting Bag'; break;
                    case 4: echo 'Engineering Bag'; break;
                    case 5: echo 'Gem Bag'; break;
                    case 6: echo 'Mining Bag'; break;
                    case 7: echo 'Leatherworking Bag'; break;
                    case 8: echo 'Inscription Bag'; break;
                    default: echo 'Bag';
                }
                break;
            case 2:
                switch($subclass)
                {
                    case 1: echo 'Axe'; break;
                    case 2: echo 'Bow'; break;
                    case 3: echo 'Gun'; break;
                    case 4:
                    case 5: echo 'Mace'; break;
                    case 6: echo 'Polearm'; break;
                    case 7:
                    case 8: echo 'Sword'; break;
                    case 9: echo 'Obsolete'; break;
                    case 10: echo 'Staff'; break;
                    case 11:
                    case 12: echo 'Exotic'; break;
                    case 13: echo 'Fist Weapon'; break;
                    case 14: echo 'Miscellaneous'; break;
                    case 15: echo 'Dagger'; break;
                    case 16: echo 'Thrown'; break;
                    case 17: echo 'Spear'; break;
                    case 18: echo 'Crossbow'; break;
                    case 19: echo 'Wand'; break;
                    case 20: echo 'Fishing Pole'; break;
                    default: echo 'Axe';
                }
                break;
            case 3:
                switch($subclass)
                {
                    case 1: echo 'Blue'; break;
                    case 2: echo 'Yellow'; break;
                    case 3: echo 'Purple'; break;
                    case 4: echo 'Green'; break;
                    case 5: echo 'Orange'; break;
                    case 6: echo 'Meta'; break;
                    case 7: echo 'Simple'; break;
                    case 8: echo 'Prismatic'; break;
                    default: echo 'Red';
                }
                break;
            case 4:
                switch($subclass)
                {
                    case 1: echo 'Cloth'; break;
                    case 2: echo 'Leather'; break;
                    case 3: echo 'Mail'; break;
                    case 4: echo 'Plate'; break;
                    case 5: echo 'Buckler'; break;
                    case 6: echo 'Shield'; break;
                    case 7: echo 'Libram'; break;
                    case 8: echo 'Idol'; break;
                    case 9: echo 'Totem'; break;
                    case 10: echo 'Sigil'; break;
                    default: echo 'Miscellaneous';
                }
                break;
            case 5: echo 'Reagent'; break;
            case 6:
                switch($subclass)
                {
                    case 1: echo 'Bolt'; break;
                    case 2: echo 'Arrow'; break;
                    case 3: echo 'Bullet'; break;
                    case 4: echo 'Thrown'; break;
                    default: echo 'Wand';
                }
                break;
            case 7:
                switch($subclass)
                {
                    case 1: echo 'Parts'; break;
                    case 2: echo 'Explosives'; break;
                    case 3: echo 'Devices'; break;
                    case 4: echo 'Jewelcrafting'; break;
                    case 5: echo 'Cloth'; break;
                    case 6: echo 'Leather'; break;
                    case 7: echo 'Metal & Stone'; break;
                    case 8: echo 'Meat'; break;
                    case 9: echo 'Herb'; break;
                    case 10: echo 'Elemental'; break;
                    case 11: echo 'Other'; break;
                    case 12: echo 'Enchanting'; break;
                    case 13: echo 'Materials'; break;
                    case 14: echo 'Armor Enchantment'; break;
                    case 15: echo 'Weapon Enchantment'; break;
                    default: echo 'Trade Goods';
                }
                break;
            case 8: echo 'Generic'; break;
            case 9:
                switch($subclass)
                {
                    case 1: echo 'Leatherworking'; break;
                    case 2: echo 'Tailoring'; break;
                    case 3: echo 'Engineering'; break;
                    case 4: echo 'Blacksmithing'; break;
                    case 5: echo 'Cooking'; break;
                    case 6: echo 'Alchemy'; break;
                    case 7: echo 'First Aid'; break;
                    case 8: echo 'Enchanting'; break;
                    case 9: echo 'Fishing'; break;
                    case 10: echo 'Jewelcrafting'; break;
                    default: echo 'Book';
                }
                break;
            case 10: echo 'Money'; break;
            case 11:
                if($subclass == 3)
                    echo 'Ammo Pounch';
                else
                    echo 'Quiver';
                break;
            case 12: echo 'Quest'; break;
            case 13:
                if($subclass == 0)
                    echo 'Key';
                else
                    echo 'Lockpick';
                break;
            case 14: echo 'Permanent'; break;
            case 15:
                switch($subclass)
                {
                    case 1: echo 'Reagent'; break;
                    case 2: echo 'Pet'; break;
                    case 3: echo 'Holiday'; break;
                    case 4: echo 'Other'; break;
                    case 5: echo 'Mount'; break;
                    default: echo 'Junk';
                }
                break;
            case 16:
                switch($subclass)
                {
                    case 1: echo 'Warrior'; break;
                    case 2: echo 'Paladin'; break;
                    case 3: echo 'Hunter'; break;
                    case 4: echo 'Rogue'; break;
                    case 5: echo 'Priest'; break;
                    case 7: echo 'Shaman'; break;
                    case 8: echo 'Mage'; break;
                    case 9: echo 'Warlock'; break;
                    case 11: echo 'Druid'; break;
                    default:;
                }
                break;
            default:;
        }
    }

    function ApiItemInventoryType($type)
    {
        switch(intval($type))
        {
            case 1: echo 'Head'; break;
            case 2: echo 'Neck'; break;
            case 3: echo 'Shoulder'; break;
            case 4: echo 'Shirt'; break;
            case 5: echo 'Chest'; break;
            case 6: echo 'Waist'; break;
            case 7: echo 'Legs'; break;
            case 8: echo 'Feet'; break;
            case 9: echo 'Wrists'; break;
            case 10: echo 'Hands'; break;
            case 11: echo 'Finger'; break;
            case 12: echo 'Trinket'; break;
            case 13: echo 'One-Hand'; break;
            case 14: echo 'Shield'; break;
            case 15: echo 'Ranged'; break;
            case 16: echo 'Back'; break;
            case 17: echo 'Two-Hand'; break;
            case 18: echo 'Bag'; break;
            case 19: echo 'Tabard'; break;
            case 20: echo 'Robe'; break;
            case 21: echo 'Main Hand'; break;
            case 22: echo 'Off Hand'; break;
            case 23: echo 'Held in Off-hand'; break;
            case 24: echo 'Ammo'; break;
            case 25: echo 'Thrown'; break;
            case 26: echo 'Ranged'; break;
            case 27: echo 'Quiver'; break;
            case 28: echo 'Relic'; break;
            default:;
        }
    }

    function ApiItemBonding($bonding)
    {
        switch(intval($bonding))
        {
            case 1: echo 'Binds when picked up'; break;
            case 2: echo 'Binds when equipped'; break;
            case 3: echo 'Binds when used'; break;
            case 4:
            case 5: echo 'Quest item'; break;
            default:;
        }
    }

    function getFactionImage($raceId)
    {
        switch(intval($raceId))
        {
            case 1:
            case 3:
            case 4:
            case 7:
                echo '<img src="/bundles/elysium/img/faction/alliance.png" alt="Alliance" /><span class="table-search">Alliance</span>';
                break;
            default:
                echo '<img src="/bundles/elysium/img/faction/horde.png" alt="Horde" /><span class="table-search">Horde</span>';
        }
    }

    function getRaceImage($raceId, $gender, $search)
    {
        switch(intval($raceId))
        {
            case 1:
                echo '<img src="/bundles/elysium/img/races/human' . ($gender ? 'f' : 'm') . '.png" alt="Human ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Human ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 2:
                echo '<img src="/bundles/elysium/img/races/orc' . ($gender ? 'f' : 'm') . '.png" alt="Orc ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Orc ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 3:
                echo '<img src="/bundles/elysium/img/races/dwarf' . ($gender ? 'f' : 'm') . '.png" alt="Dwarf ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Dwarf ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 4:
                echo '<img src="/bundles/elysium/img/races/ne' . ($gender ? 'f' : 'm') . '.png" alt="Night Elf ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Night Elf ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 5:
                echo '<img src="/bundles/elysium/img/races/undead' . ($gender ? 'f' : 'm') . '.png" alt="Undead ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Undead ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 6:
                echo '<img src="/bundles/elysium/img/races/tauren' . ($gender ? 'f' : 'm') . '.png" alt="Tauren ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Tauren ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 7:
                echo '<img src="/bundles/elysium/img/races/gnome' . ($gender ? 'f' : 'm') . '.png" alt="Gnome ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Gnome ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 8:
                echo '<img src="/bundles/elysium/img/races/troll' . ($gender ? 'f' : 'm') . '.png" alt="Troll ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Troll ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 10:
                echo '<img src="/bundles/elysium/img/races/be' . ($gender ? 'f' : 'm') . '.png" alt="Blood Elf ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Blood Elf ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            case 11:
                echo '<img src="/bundles/elysium/img/races/draenei' . ($gender ? 'f' : 'm') . '.png" alt="Draenei ' . ($gender ? 'Fem' : 'M') . 'ale" />' . ($search ? '<span class="table-search">Draenei ' . ($gender ? 'Fem' : 'M') . 'ale</span>' : '');
                break;
            default:
        }
    }

    function getClassImage($classId, $search)
    {
        switch(intval($classId))
        {
            case 1:     echo '<img src="/bundles/elysium/img/classes/warrior.png" alt="Warrior" />'.($search ? '<span class="table-search">Warrior</span>' : ''); break;
            case 2:     echo '<img src="/bundles/elysium/img/classes/paladin.png" alt="Paladin" />'.($search ? '<span class="table-search">Paladin</span>' : ''); break;
            case 3:     echo '<img src="/bundles/elysium/img/classes/hunter.png" alt="Hunter" />'.($search ? '<span class="table-search">Hunter</span>' : ''); break;
            case 4:     echo '<img src="/bundles/elysium/img/classes/rogue.png" alt="Rogue" />'.($search ? '<span class="table-search">Rogue</span>' : ''); break;
            case 5:     echo '<img src="/bundles/elysium/img/classes/priest.png" alt="Priest" />'.($search ? '<span class="table-search">Priest</span>' : ''); break;
            case 7:     echo '<img src="/bundles/elysium/img/classes/shaman.png" alt="Shaman" />'.($search ? '<span class="table-search">Shaman</span>' : ''); break;
            case 8:     echo '<img src="/bundles/elysium/img/classes/mage.png" alt="Mage" />'.($search ? '<span class="table-search">Mage</span>' : ''); break;
            case 9:     echo '<img src="/bundles/elysium/img/classes/warlock.png" alt="Warlock" />'.($search ? '<span class="table-search">Warlock</span>' : ''); break;
            case 11:    echo '<img src="/bundles/elysium/img/classes/druid.png" alt="Druid" />'.($search ? '<span class="table-search">Druid</span>' : ''); break;
            default:    echo '';
        }
    }

    /**
     * Turn all URLs in clickable links.
     *
     * @param string $value
     * @param array  $protocols  http/https, ftp, mail, twitter
     * @param array  $attributes
     * @param string $mode       normal or all
     * @return string
     */
    public function linkify($value, $protocols = array('http', 'mail'), array $attributes = array(), $mode = 'normal')
    {
        if (!isset($value)) return null;

        // Link attributes
        $attr = '';
        foreach ($attributes as $key => $val) {
            $attr .= ' ' . $key . '="' . htmlentities($val) . '"';
        }

        $links = array();

        // Extract existing links and tags
        $value = preg_replace_callback('~(<a .*?>.*?</a>|<.*?>)~i', function ($match) use (&$links) { return '<' . array_push($links, $match[1]) . '>'; }, $value);

        // Extract text links for each protocol
        foreach ((array)$protocols as $protocol) {
            switch ($protocol) {
                case 'http':
                case 'https':   $value = preg_replace_callback($mode != 'all' ? '~(?:(https?)://([^\s<>]+)|(www\.[^\s<>]+?\.[^\s<>]+))(?<![\.,:;\?!\'"\|])~i' : '~(?:(https?)://([^\s<>]+)|([^\s<>]+?\.[^\s<>]+)(?<![\.,:]))~i', function ($match) use ($protocol, &$links, $attr) { if ($match[1]) $protocol = $match[1]; $link = $match[2] ?: $match[3]; return '<' . array_push($links, '<a' . $attr . ' href="' . $protocol . '://' . $link  . '">' . rtrim($link, '/') . '</a>') . '>'; }, $value); break;
                case 'mail':    $value = preg_replace_callback('~([^\s<>]+?@[^\s<>]+?\.[^\s<>]+)(?<![\.,:;\?!\'"\|])~', function ($match) use (&$links, $attr) { return '<' . array_push($links, '<a' . $attr . ' href="mailto:' . $match[1]  . '">' . $match[1] . '</a>') . '>'; }, $value); break;
                case 'twitter': $value = preg_replace_callback('~(?<!\w)[@#](\w++)~', function ($match) use (&$links, $attr) { return '<' . array_push($links, '<a' . $attr . ' href="https://twitter.com/' . ($match[0][0] == '@' ? '' : 'search/%23') . $match[1]  . '">' . $match[0] . '</a>') . '>'; }, $value); break;

                default:
                    if (strpos($protocol, ':') === false) $protocol .= in_array($protocol, array('ftp', 'tftp', 'ssh', 'scp'))  ? '://' : ':';
                    $value = preg_replace_callback($mode != 'all' ? '~' . preg_quote($protocol, '~') . '([^\s<>]+?)(?<![\.,:;\?!\'"\|])~i' : '~([^\s<>]+)(?<![\.,:])~i', function ($match) use ($protocol, &$links, $attr) { return '<' . array_push($links, '<a' . $attr . ' href="' . $protocol . $match[1]  . '">' . $match[1] . '</a>') . '>'; }, $value); break;
            }
        }

        // Insert all link
        return preg_replace_callback('/<(\d+)>/', function ($match) use (&$links) { return $links[$match[1] - 1]; }, $value);
    }

    public function timeSince($time) {

        $since = time() - strtotime($time);

        $string     = '';

        $chunks = array(
            array(60 * 60 * 24 , 'd'),
            array(60 * 60 , 'h'),
            array(60 , 'min'),
            array(1 , 's')
        );

        for ($i = 0, $j = count($chunks); $i < $j; $i++) {
            $seconds = $chunks[$i][0];
            $name = $chunks[$i][1];
            if (($count = floor($since / $seconds)) != 0) {
                break;
            }
        }

        return $count . $name;

    }

    public function getMoney($money)
    {
        $copper = $money % 100;
        $silver = floor(($money % 10000) / 100);
        $gold = floor($money / 10000);
        $result = '';
        if($gold > 0)
            $result .= $gold . '<img src="/assets/img/gold.png" alt="Gold" /> ';
        if($silver > 0)
            $result .= $silver . '<img src="/assets/img/silver.png" alt="Silver" /> ';
        if($copper > 0)
            $result .= $copper . '<img src="/assets/img/copper.png" alt="Copper" />';
        return $result;
    }

    public function getTradeItems($items)
    {
        $items = explode(' ', $items);
        foreach($items as $item)
        {
            if($item == '')
                continue;
            $item = trim($item, ' ');
            $info = explode(':', $item);
            echo "{$info[1]} <a href='https://wowhead.com/?item={$info[0]}'></a><br />";
        }
    }
}