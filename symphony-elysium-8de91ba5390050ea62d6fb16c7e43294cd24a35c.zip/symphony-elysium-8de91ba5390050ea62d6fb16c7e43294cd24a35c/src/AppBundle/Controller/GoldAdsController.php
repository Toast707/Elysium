<?php

namespace AppBundle\Controller;

use AppBundle\Entity\GoldAds;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class GoldAdsController extends Controller
{
    /**
     * @Route("/gm/gold-ads", name="gm_gold_ads")
     * @Security("is_granted('ROLE_GM1')")
     */
    public function goldAdsAction(Request $request)
    {
        $formRealms = [];
        $realms = $this->getParameter('realms');
        foreach($realms as $realmId => $realm)
            $formRealms[$realm['name']] = $realmId;
        $form = $this->createFormBuilder()
            ->add('realms', ChoiceType::class, array(
                'choices' => $formRealms))
            ->add('character', TextType::class, array(
                'constraints' => array(
                    new NotBlank(),
                    new Length(array('min' => 3, 'max' => 12)),
                )))
            ->add('message', TextareaType::class, array(
                'constraints' => array(
                    new NotBlank(),
                )))
            ->add('add', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();

            $character = $this->getDoctrine()->getRepository('CharacterBundle:Characters', "realm{$data['realms']}")->findOneByName($data['character']);
            if(!$character)
                $character = $this->getDoctrine()->getRepository('CharacterBundle:Characters', "realm{$data['realms']}")->findOneBy(array('deleteInfosName' => $data['character']), array('deleteDate' => 'DESC'));
            if(!$character)
            {
                $this->addFlash('danger',"Character {$data['character']} does not exist on {$realms[$data['realms']]['name']}.");
                return $this->render('gm/money/ads.html.twig', array(
                    'form' => $form->createView(),
                ));
            }

            $accountId = $character->getAccount() ? $character->getAccount() : $character->getDeleteInfosAccount();
            $characterName = $character->getName() ? $character->getName() : $character->getDeleteInfosName();

            $characters = $this->getDoctrine()->getRepository('CharacterBundle:Characters', "realm{$data['realms']}")->findBy(array('account' => $accountId));

            $avgLevel = 1;
            $maxLevel = 1;
            foreach($characters as $character)
            {
                $avgLevel += $character->getLevel();
                if($character->getLevel() > $maxLevel)
                    $maxLevel = $character->getLevel();
            }

            $account = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->find($accountId);
            $ad = new GoldAds();
            $ad->setAccountId($accountId);
            $ad->setUsername($account->getUsername());
            $ad->setEmail($account->getEmail());
            $ad->setIp($account->getLastIp());
            $ad->setCreatedAt($account->getJoinDate());
            $ad->setTfa($account->getLocked());
            $ad->setCharsCount(count($characters));
            $ad->setCharsLevelAvg($avgLevel / count($characters));
            $ad->setCharsLevelMax($maxLevel);
            $ad->setRealm($data['realms']);
            $ad->setGuid($character->getGuid());
            $ad->setName($characterName);
            $ad->setLevel($character->getLevel());
            $ad->setRace($character->getRace());
            $ad->setClass($character->getClass());
            $ad->setMoney($character->getMoney());
            $ad->setPlayed($character->getTotaltime());
            $ad->setZone($character->getZone());
            $ad->setArea($character->getArea());
            $ad->setMessage($data['message']);
            $em = $this->getDoctrine()->getManager('web');
            $em->persist($ad);
            $em->flush();

            $this->addFlash('success',"Thank you! {$characterName} ({$realms[$data['realms']]['name']}) message: \"{$data['message']}\" was just added.");
            $this->redirectToRoute('gm_gold_ads');
        }
        return $this->render('gm/money/ads.html.twig', array(
            'form' => $form->createView()
        ));
    }
}