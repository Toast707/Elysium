<?php

namespace AppBundle\Controller;

use AppBundle\Entity\NostalriusToken;
use AuthBundle\Entity\AccountBanned;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use AuthBundle\Entity\Account;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use EWZ\Bundle\RecaptchaBundle\Form\Type\EWZRecaptchaType;
use EWZ\Bundle\RecaptchaBundle\Validator\Constraints\IsTrue as RecaptchaTrue;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Swift_Message;
use Swift_Signers_DKIMSigner;

class TransferController extends Controller
{
    /**
     * @Route("/control/user/transfer/elysium", name="transfer_elysium")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function transferElysiumAction(Request $request)
    {
        if(!$this->getParameter('elysium_token') || !$this->getUser()->isEmailVerif() || $this->getUser()->isNostalriusTokenEnabled() || $this->getUser()->isElysiumTokenEnabled())
            return $this->redirectToRoute('user_panel');

        $form = $this->createFormBuilder()
            ->add('username', TextType::class)
            ->add('password', PasswordType::class, array('required' => false))
            ->add('email',    TextType::class, array('required' => false))
            ->add('transfer', SubmitType::class, array('label' => 'Transfer'))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $em = $this->getDoctrine();
            $user = $this->getUser();

            $account = NULL;

            // Token already use
            if($user->isElysiumTokenEnabled())
                return $this->render('transfer/elysium.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'You already transferred an Elysium account to this account.',
                ));

            // No Password nor Email
            if(!$data['password'] && !$data['email'])
            {
                return $this->render('transfer/elysium.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> "You must fill 'Username' and 'Password' or 'Email'.",
                ));
            }

            // Password & Email
            if($data['password'] && $data['email'])
            {
                $account = $em->getRepository('AuthBundle:Account', 'auth_ely')->findOneBy(array(
                    'username'      => strtoupper($data['username']),
                    'shaPassHash' => strtoupper(sha1(strtoupper($data['username']).':'.strtoupper($data['password'])))
                ));

                if($account == NULL)
                {
                    $email = $this->tokenEmail($data);
                    if($email === true)
                    {
                        $this->addFlash('success',"An email was sent to '{$data['email']}' to activate the Elysium transfer.");
                        return $this->render('transfer/elysium.html.twig', array(
                            'form'      => $form->createView(),
                        ));
                    }
                    else
                    {
                        $this->addFlash('danger',$email);
                        return $this->render('transfer/elysium.html.twig', array(
                            'form'      => $form->createView(),
                        ));
                    }
                }
            }

            // Password
            if($data['password'] && !$data['email'])
            {
                $account = $em->getRepository('AuthBundle:Account', 'auth_ely')->findOneBy(array(
                    'username'      => strtoupper($data['username']),
                    'shaPassHash' => strtoupper(sha1(strtoupper($data['username']).':'.strtoupper($data['password'])))
                ));

                if($account == NULL)
                    return $this->render('transfer/elysium.html.twig', array(
                        'form' => $form->createView(),
                        'error'=> 'Bad credentials.',
                    ));
            }

            // Email
            if(!$data['password'] && $data['email'])
            {
                $email = $this->tokenEmail($data);
                if($email === true)
                {
                    $this->addFlash('success',"An email was sent to '{$data['email']}' to activate the Elysium transfer. : Elysium is sending an industrial amount of emails and we may have reached your provider rate's limit. If you do not receive the email after an hour, please redo the transfer.");
                    return $this->render('transfer/elysium.html.twig', array(
                        'form'      => $form->createView(),
                    ));
                }
                else
                {
                    $this->addFlash('danger',$email);
                    return $this->render('transfer/elysium.html.twig', array(
                        'form'      => $form->createView(),
                    ));
                }
            }

            // No characters on PvP realm
            $characters = $em->getRepository('CharacterBundle:Characters', 'realm1')->findByAccount($user->getId());
            if(!empty($characters))
                return $this->render('transfer/elysium.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'Your account must not have characters on Nostalrius PvP for the transfer to work.',
                ));

            // No characters on PvE realm
            $characters = $em->getRepository('CharacterBundle:Characters', 'realm2')->findByAccount($user->getId());
            if(!empty($characters))
                return $this->render('transfer/elysium.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'Your account must not have characters on Nostalrius PvE for the transfer to work.',
                ));

            if($account == NULL)
                return $this->render('transfer/elysium.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'Something went wrong.',
                ));

            $tokenConsumed = $em->getRepository('AuthBundle:Account', 'auth')->find($account->getId());
            if($tokenConsumed != NULL)
                return $this->render('transfer/elysium.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'This Elysium account was already transferred.',
                ));

            // Update account
            $user->setElysiumEmail($account->getEmail());
            $user->setJoinDate($account->getJoinDate());
            $user->setMutetime($account->getMutetime());
            $user->setMutereason(($account->getMutereason()));
            $user->setMuteby(($account->getMuteby()));
            $user->setFlags(($account->getFlags()));
            $user->setElysiumTokenEnabled(true);
            $em->getManager('auth')->merge($user);
            $em->getManager('auth')->flush();

            $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->updateId($user->getId(), $account->getId());
            $new = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->find($account->getId());
            $this->authenticateUser($new);

            return $this->render('transfer/elysium.html.twig', array(
                'form'      => $form->createView(),
                'success'   => true,
            ));
        }

        return $this->render('transfer/elysium.html.twig', array(
            'form' => $form->createView()
        ));
    }

    /**
     * @Route("/control/user/transfer/elysium/{token}", name="transfer_elysium_email")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function transferElysiumEmailAction(Request $request, $token)
    {
        $em = $this->getDoctrine();
        $user = $this->getUser();

        if(!$this->getUser()->isEmailVerif() || $this->getUser()->isNostalriusTokenEnabled() || $this->getUser()->isElysiumTokenEnabled())
            return $this->redirectToRoute('user_panel');

        // Check token
        if($user->getElysiumToken() == NULL || !$token || strlen($token) != 15 || strtoupper(sha1($token)) != $user->getElysiumToken())
            return $this->render('transfer/elysium.html.twig', array(
                'error'=> 'Your token is invalid.',
            ));

        // Get account with token
        $account = $em->getRepository('AuthBundle:Account', 'auth_ely')->findOneBy(array('elysiumToken' => strtoupper(sha1($token))));

        // Check account and token
        if($account == NULL || $account->getElysiumToken() == NULL)
            return $this->render('transfer/elysium.html.twig', array(
                'error'=> 'Your token is invalid.',
            ));

        // No characters on Nostalrius PvP realm
        $characters = $em->getRepository('CharacterBundle:Characters', 'realm1')->findByAccount($user->getId());
        if(!empty($characters))
            return $this->render('transfer/elysium.html.twig', array(
                'error'=> 'Your account must not have characters on Nostalrius PvP for the transfer to work.',
            ));

        // Update account
        $user->setElysiumEmail($account->getEmail());
        $user->setJoinDate($account->getJoinDate());
        $user->setMutetime($account->getMutetime());
        $user->setMutereason(($account->getMutereason()));
        $user->setMuteby(($account->getMuteby()));
        $user->setFlags(($account->getFlags()));
        $user->setElysiumTokenEnabled(true);
        $user->setElysiumToken(NULL);
        $em->getManager('auth')->merge($user);
        $em->getManager('auth')->flush();

        $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->updateId($user->getId(), $account->getId());
        $new = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->find($account->getId());
        $this->authenticateUser($new);

        return $this->render('transfer/elysium.html.twig', array(
            'success'   => true
        ));
    }

    /**
     * @Route("/control/user/transfer/nostalrius", name="transfer_nostalrius")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function transferNostalriusAction(Request $request)
    {
        if(!$this->getParameter('nostalrius_token') || !$this->getUser()->isEmailVerif() || $this->getUser()->isNostalriusTokenEnabled() || $this->getUser()->isElysiumTokenEnabled())
            return $this->redirectToRoute('user_panel');

        $nostalrius = new NostalriusToken();
        $form = $this->createFormBuilder($nostalrius)
            ->add('token', TextareaType::class)
            ->add('transfer', SubmitType::class, array('label' => 'Transfer'))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            $em = $this->getDoctrine();
            $auth = $em->getEntityManager('auth');

            $user = $this->getUser();
            if($user->isNostalriusTokenEnabled())
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'A Nostalrius token has already been used on this account.',
                ));

            $characters = $em->getRepository('CharacterBundle:Characters', 'realm1')->findByAccount($user->getId());
            if(!empty($characters))
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'Your account must not have characters on Nostalrius PvP for the transfer to work.',
                ));

            $characters = $em->getRepository('CharacterBundle:Characters', 'realm2')->findByAccount($user->getId());
            if(!empty($characters))
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'Your account must not have characters on Nostalrius PvE for the transfer to work.',
                ));

            $error = $nostalrius->extractToken();
            if($error !== true)
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> $error,
                ));

            $data = $nostalrius->getData();

            if($data['transfer_infos']['ip_address'] != $request->getClientIp())
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> 'You must use the same IP to generate and consume the token.',
                ));

            /*
             * Not same email, ask reason
            if($user->$user->getEmail() != $data['account']['account'][0]['email'])
            {
                $user->setNostalriusToken($nostalrius->getToken());
                $auth->merge($user);
                $form = $this->createFormBuilder($user)
                    ->add('nostalriusReason', TextareaType::class)
                    ->add('send', SubmitType::class, array('label' => 'Send'))
                    ->getForm();
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView()
                ));
            }
            */

            // An error occurred
            $tokenConsumed = $auth->getRepository('AuthBundle:Account', 'auth')->find($data['account']['account'][0]['id']);
            if($tokenConsumed != NULL)
                return $this->render('transfer/nostalrius.html.twig', array(
                    'form' => $form->createView(),
                    'error'=> "Your Nostalrius Token was already consumed. You can recover your account <a href='{$this->generateUrl('recover_nostalrius')}'>here</a>.",
                ));

            // Update account
            $user->setNostalriusEmail($data['account']['account'][0]['email']);
            $user->setJoinDate(new \DateTime($data['account']['account'][0]['joindate']));
            $user->setMutetime($data['account']['account'][0]['mutetime']);
            $user->setMutereason($data['account']['account'][0]['mutereason']);
            $user->setMuteby($data['account']['account'][0]['muteby']);
            $user->setFlags($data['account']['account'][0]['flags']);
            $user->setNostalriusLastIp($data['account']['account'][0]['last_ip']);
            $user->setNostalriusToken($nostalrius->getToken());
            $user->setNostalriusTokenEnabled(true);
            $auth->merge($user);

            // Update sanctions
            if(!empty($data['account']['account_banned']))
            {
                foreach($data['account']['account_banned'] as $ban)
                {
                    $b = new AccountBanned();
                    $b->setId($data['account']['account'][0]['id']);
                    $b->setBandate($ban['bandate']);
                    $b->setUnbandate($ban['unbandate']);
                    $b->setBannedby($ban['bannedby']);
                    $b->setBanreason($ban['banreason']);
                    $b->setActive($ban['active']);
                    $b->setRealm($ban['realm']);
                    $b->setGmlevel($ban['gmlevel']);
                    $auth->persist($b);
                }
            }
            $auth->flush();

            $auth->getRepository('AuthBundle:Account', 'auth')->updateId($user->getId(), $data['account']['account'][0]['id']);
            $new = $auth->getRepository('AuthBundle:Account', 'auth')->find($data['account']['account'][0]['id']);
            $this->authenticateUser($new);

            return $this->render('transfer/nostalrius.html.twig', array(
                'form'      => $form->createView(),
                'success'   => true,
            ));
        }

        return $this->render('transfer/nostalrius.html.twig', array(
            'form' => $form->createView()
        ));
    }

    /**
     * @param $data
     * @return Response
     */
    private function tokenEmail($data)
    {
        $account = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth_ely')->findOneBy(array(
            'username'  => strtoupper($data['username']),
            'email'     => $data['email']
        ));

        if($account == NULL)
            return 'Bad credentials.';

        // No characters on PvP realm
        $characters = $this->getDoctrine()->getRepository('CharacterBundle:Characters', 'realm1')->findByAccount($this->getUser()->getId());
        if(!empty($characters))
            return 'Your account must not have characters on Nostalrius PvP for the transfer to work.';

        $characters = $this->getDoctrine()->getRepository('CharacterBundle:Characters', 'realm2')->findByAccount($this->getUser()->getId());
        if(!empty($characters))
            return 'Your account must not have characters on Nostalrius PvE for the transfer to work.';

        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $activationCode = '';
        for ($i = 0; $i < 15; $i++)
            $activationCode .= $characters[rand(0, $charactersLength - 1)];

        $user = $this->getUser();
        $user->setElysiumToken(strtoupper(sha1($activationCode)));
        $account->setElysiumToken(strtoupper(sha1($activationCode)));
        $this->getDoctrine()->getManager('auth')->merge($user);
        $this->getDoctrine()->getManager('auth')->flush();

        $this->getDoctrine()->getManager('auth_ely')->merge($account);
        $this->getDoctrine()->getManager('auth_ely')->flush();

        $this->get('app.service.mail')->sendMail(
            '[Elysium Project] Elysium Transfer Token',
            array($account->getEmail() => $account->getUsername()),
            'elysium_token',
            array(
                'title'     => "Welcome to Elysium, {$this->getUser()->getUsername()}!",
                'username'  => $this->getUser()->getUsername(),
                'cta_link'  => $this->generateUrl('transfer_elysium_email', array('token' => $activationCode)),
                'cta_text'  => 'Transfer your old Elysium characters',
            ));
        return true;
    }
}