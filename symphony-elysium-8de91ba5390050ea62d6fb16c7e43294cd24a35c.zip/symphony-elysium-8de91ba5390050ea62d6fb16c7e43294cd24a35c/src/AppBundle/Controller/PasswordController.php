<?php

namespace AppBundle\Controller;

use AppBundle\Entity\NostalriusToken;
use AuthBundle\Entity\AccountBanned;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use AuthBundle\Entity\Account;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use EWZ\Bundle\RecaptchaBundle\Form\Type\EWZRecaptchaType;
use EWZ\Bundle\RecaptchaBundle\Validator\Constraints\IsTrue as RecaptchaTrue;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Swift_Message;
use Swift_Signers_DKIMSigner;

class PasswordController extends Controller
{
    /**
     * @Route("/password", name="password_reset")
     */
    public function passwordResetAction(Request $request)
    {
        if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_FULLY'))
            return $this->redirectToRoute('user_panel');

        $form = $this->createFormBuilder()
            ->add('username', TextType::class)
            ->add('email',    TextType::class)
            ->add('recaptcha', EWZRecaptchaType::class, array(
                'constraints' => array(
                    new RecaptchaTrue()
                ),
                'attr' => array(
                    'options' => array(
                        'theme' => 'dark',
                        'type'  => 'image',
                        'size'  => 'normal',
                        'defer' => true,
                        'async' => true
                    )
                )))
            ->add('send', SubmitType::class, array('label' => 'Send'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $em = $this->getDoctrine()->getManager('auth');

            $account = $em->getRepository('AuthBundle:Account', 'auth')->findOneBy(array('username' => $data['username'], 'email' => $data['email']));

            if($account == NULL)
            {
                $this->addFlash('danger', 'The username or the email is wrong.');
                return $this->render('default/password.html.twig', array(
                    'form' 	=> $form->createView()
                ));
            }

            if($account->isNostalriusRecover() && $account->isBanned())
            {
                $this->addFlash('danger', 'This account is under the process of Nostalrius account recover.');
                return $this->render('default/password.html.twig', array(
                    'form' 	=> $form->createView()
                ));
            }

            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $activationCode = '';
            for ($i = 0; $i < 15; $i++) {
                $activationCode .= $characters[rand(0, $charactersLength - 1)];
            }

            $account->setPassVerif(sha1($activationCode));
            $em->merge($account);
            $em->flush();

            $this->get('app.service.mail')->sendMail(
                '[Elysium Project] Password reset',
                array($account->getEmail() => $account->getUsername()),
                'password_reset',
                array(
                    'title'     => "Password reset",
                    'username'  => $account->getUsername(),
                    'cta_link'  => $this->generateUrl('password_reset_token', array('token' => $activationCode)),
                    'cta_text'  => 'Reset your password',
                ));
            $this->addFlash('success', "An email was sent to {$account->getEmail()}. Elysium is sending an industrial amount of emails and we may have reached your provider rate's limit. If you do not receive the email after an hour, please retry in an hour.");

            return $this->render('default/password.html.twig', array(
                'form' => $form->createView(),
            ));
        }
        return $this->render('default/password.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    /**
     * @Route("/password/{token}/reset", name="password_reset_token")
     */
    public function passwordResetTokenAction(Request $request, $token)
    {
        if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_FULLY'))
            return $this->redirectToRoute('user_panel');

        $form = $this->createFormBuilder()
            ->add('password', RepeatedType::class, array(
                'type'              => PasswordType::class,
                'invalid_message'   => 'The password fields must match.',
                'options'           => array('attr' => array('class' => 'password-field')),
                'required'          => true,
                'first_options'     => array('label' => 'Password'),
                'second_options'    => array('label' => 'Repeat Password'),
                'constraints' => array(
                    new NotBlank(),
                    new Length(array('min' => 6, 'max' => 16)),
                ),
            ))
            ->add('send', SubmitType::class, array('label' => 'Change your password'))
            ->getForm();

        if(!$token || strlen($token) != 15)
        {
            $this->addFlash('danger', 'Your activation code is invalid.');
            return $this->render('default/password_reset.html.twig', array(
                'form' => $form->createView()
            ));
        }

        $em = $this->getDoctrine()->getManager('auth');
        $account = $em->getRepository('AuthBundle:Account', 'auth')->findOneBy(array('passVerif' => sha1($token)));

        if($account == NULL)
        {
            $this->addFlash('danger', 'Your activation code is not valid.');
            return $this->render('default/password_reset.html.twig', array(
                'form' 	=> $form->createView()
            ));
        }

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $account = $em->getRepository('AuthBundle:Account', 'auth')->findOneBy(array('passVerif' => sha1($token)));

            if($account == NULL)
            {
                $this->addFlash('danger', 'Your activation code is not valid.');
                return $this->render('default/password_reset.html.twig', array(
                    'form' 	=> $form->createView()
                ));
            }

            $data = $form->getData();

            if($account->isNostalriusRecover() && $account->isBanned() && $account->getEmail() != $account->getNostalriusEmail())
                $account->setEmail($account->getNostalriusEmail());
            if($account->isNostalriusRecover() && $account->isBanned())
            {
                $em->getRepository('AuthBundle:AccountBanned', 'auth')->removeWebBan($account->getId());
                $account->setBanned(false);
            }

            $account->setPassVerif(NULL);
            $account->setV(NULL);
            $account->setS(NULL);
            $account->setShaPassHash(strtoupper(sha1(strtoupper($account->getUsername()).':'.strtoupper($data['password']))));
            $em->merge($account);
            $em->flush();

            $this->addFlash('success', "Your password was successfully changed.");
        }
        return $this->render('default/password_reset.html.twig', array(
            'form' => $form->createView(),
        ));
    }
}