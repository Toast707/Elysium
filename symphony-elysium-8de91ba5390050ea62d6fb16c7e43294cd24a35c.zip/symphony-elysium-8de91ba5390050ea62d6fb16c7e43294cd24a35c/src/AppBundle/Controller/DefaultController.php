<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\News;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        $page = $request->query->getInt('page', 1);
        $cache = $this->get('app.service.cache');
        $redis = $this->get('snc_redis.default');

        $streams = json_decode($redis->get('streams'), true);
        $patch = $cache->getLastPatch();
        $news = $cache->getNews($page);

        return $this->render('default/index.html.twig', [
            'news'      => $news,
            'patch'     => $patch,
            'streams'   => $streams,
        ]);
    }

    /**
     * @Route("/news/{title}", name="news")
     */
    public function newsAction(Request $request, $title)
    {
        $page = $request->query->getInt('page', 1);
        $cache = $this->get('app.service.cache');

        $new = $this->getDoctrine()->getRepository('AppBundle:News', 'web')->findOneBy(array('link' => $title, 'type' => News::TYPE_NEWS, 'enabled' => true));
        $news = $cache->getNews($page);

        return $this->render('default/news.html.twig', [
            'new'   => $new,
            'news'  => $news,
        ]);
    }

    /**
     * @Route("/updates", name="updates")
     */
    public function updatesAction(Request $request)
    {
        $cache = $this->get('app.service.cache');

        $patch = $cache->getLastPatch();
        $patches = $cache->getPatches();

        return $this->render('default/updates.html.twig', [
            'patch'     => $patch,
            'patches'   => $patches,
        ]);
    }

    /**
     * @Route("/updates/{date}", name="updates_date")
     */
    public function updatesDateAction(Request $request, $date)
    {
        $date = \DateTime::createFromFormat('Y-m-d', $date);
        $cache = $this->get('app.service.cache');

        $patch = $this->getDoctrine()->getRepository('AppBundle:News', 'web')->findByDate($date);
        $patches = $cache->getPatches();

        return $this->render('default/updates.html.twig', [
            'patch'     => $patch,
            'patches'   => $patches,
        ]);
    }

    /**
     * @Route("/status", name="status")
     */
    public function statusAction(Request $request)
    {
        $cache = $this->get('app.service.cache');

        $news = $cache->getNews(1);
        $realms = $cache->getRealmStatus();

        return $this->render('default/status.html.twig', [
            'news'  => $news,
            'realms'=> $realms,
            'time'  => time()
        ]);
    }

    /**
     * @Route("/about", name="about")
     */
    public function aboutAction(Request $request)
    {
        return $this->render('default/about.html.twig');
    }

    /**
     * @Route("/transfer", name="transfer")
     */
    public function transferAction(Request $request)
    {
        return $this->render('default/transfer.html.twig');
    }

    /**
     * @Route("/timeline", name="timeline")
     */
    public function timelineAction(Request $request)
    {
        return $this->render('default/timeline.html.twig');
    }

    /**
     * @Route("/forum", name="forum")
     */
    public function forumAction(Request $request)
    {
        return $this->redirect('https://forum.elysium-project.org');
    }
}
