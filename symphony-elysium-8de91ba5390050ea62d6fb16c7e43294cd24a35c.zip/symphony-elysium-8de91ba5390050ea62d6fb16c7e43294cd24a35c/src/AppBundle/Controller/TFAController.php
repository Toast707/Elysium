<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class TFAController extends Controller
{
    /**
     * @Route("/control/user/2fa", name="control_user_2fa")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function tfaAction(Request $request)
    {
        $account = $this->getUser();
        // IP lock with authenticator
        switch($account->getLocked())
        {
            case 5:
                $ip     = 'Remove';
                $auth   = 'Enable';
                break;
            case 12:
                $ip     = 'Enable';
                $auth   = 'Remove';
                break;
            default:
                $auth   = 'Enable';
                $ip     = 'Enable';
        }

        $IPLock = $this->createFormBuilder()
            ->add('tfa_ip_lock', SubmitType::class, array('label' =>  "{$ip} IP lock with authenticator"))
            ->getForm();

        $IPLock->handleRequest($request);

        if($IPLock->isSubmitted() && $IPLock->isValid())
        {
            if($account->getLocked() == 0)
                $account->setGoogleAuthenticatorSecret($this->get("scheb_two_factor.security.google_authenticator")->generateSecret());

            $code = $this->get('app.service.mail')->getCode();
            $account->setTFAVerif(sha1($code));
            $em = $this->getDoctrine()->getManager('auth');
            $em->merge($account);
            $em->flush();

            $data = [
                'title'     => "{$ip} IP lock with authenticator",
                'username'  => $account->getUsername(),
                'cta_link'  => $this->generateUrl(strtolower("control_user_2fa_{$ip}"), array('method' => 'iplock', 'code' => $code)),
                'cta_text'  => "{$ip} IP lock with authenticator",
            ];
            if($account->getLocked() == 0)
            {
                $data['qrcode'] = $this->get("scheb_two_factor.security.google_authenticator")->getUrl($account);
                $data['code']   = $account->getGoogleAuthenticatorSecret();
            }
            $this->get('app.service.mail')->sendMail("{$ip} IP lock with authenticator", array($account->getEmail() => $account->getUsername()), 'tfa', $data);

            $this->addFlash('success',"An email was sent to your address to confirm the action. Elysium is sending an industrial amount of emails and we may have reached your provider rate's limit. If you do not receive the email after an hour, please retry.");
        }

        $Authenticator = $this->createFormBuilder()
            ->add('tfa_authenticator', SubmitType::class, array('label' => "{$auth} always use authenticator"))
            ->getForm();

        $Authenticator->handleRequest($request);

        if($Authenticator->isSubmitted() && $Authenticator->isValid())
        {
            if($account->getLocked() == 0)
                $account->setGoogleAuthenticatorSecret($this->get("scheb_two_factor.security.google_authenticator")->generateSecret());

            $code = $this->get('app.service.mail')->getCode();
            $account->setTFAVerif(sha1($code));
            $em = $this->getDoctrine()->getManager('auth');
            $em->merge($account);
            $em->flush();

            $data = [
                'title'     => "{$auth} always use authenticator",
                'username'  => $account->getUsername(),
                'cta_link'  => $this->generateUrl(strtolower("control_user_2fa_{$auth}"), array('method' => 'authenticator', 'code' => $code)),
                'cta_text'  => "{$auth} always use authenticator",
            ];
            if($account->getLocked() == 0)
            {
                $data['qrcode'] = $this->get("scheb_two_factor.security.google_authenticator")->getUrl($account);
                $data['code']   = $account->getGoogleAuthenticatorSecret();
            }
            $this->get('app.service.mail')->sendMail("{$auth} always use authenticator", array($account->getEmail() => $account->getUsername()), 'tfa', $data);

            $this->addFlash('success',"An email was sent to your address to confirm the action. Elysium is sending an industrial amount of emails and we may have reached your provider rate's limit. If you do not receive the email after an hour, please retry.");
        }
        return $this->render('2fa/index.html.twig', array(
            'IPLock'        => $IPLock->createView(),
            'Authenticator' => $Authenticator->createView(),
        ));
    }

    /**
     * @Route("/control/user/2fa/{method}/remove/{code}", name="control_user_2fa_remove", requirements={"method": "iplock|authenticator"})
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function removeAction(Request $request, $method, $code)
    {
        if($method == 'iplock')
            $message = 'IP lock with authenticator';
        else
            $message = 'always use authenticator';

        $user = $this->getUser();
        if($user->getTFAVerif() != sha1($code))
            throw $this->createAccessDeniedException();

        $form = $this->createFormBuilder()
            ->add('tfa', NumberType::class)
            ->add('send', SubmitType::class, array('label' => "Remove {$message}"))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();

            if ($this->get('scheb_two_factor.security.google_authenticator')->checkCode($user, $data['tfa']))
            {
                $user->setTFAVerif(NULL);
                $user->setGoogleAuthenticatorSecret(NULL);
                $user->setLocked(0);
                $em = $this->getDoctrine()->getManager('auth');
                $em->merge($user);
                $em->flush();
                $this->addFlash('success',"You successfully removed {$message} two-factor authentication!");
                return $this->redirectToRoute('user_panel');
            }
            else
                $this->addFlash('danger','The six-digit code you provided did not work. Please provide the latest one from the application.');
        }
        return $this->render('2fa/confirm.html.twig', array(
            'form'  => $form->createView(),
            'mod'   => $message,
            'state' => 'Remove',
        ));
    }

    /**
     * @Route("/control/user/2fa/{method}/{code}", name="control_user_2fa_enable", requirements={"method": "iplock|authenticator"})
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function applyAction(Request $request, $method, $code)
    {
        if($method == 'iplock')
            $message = 'IP lock with authenticator';
        else
            $message = 'always use authenticator';

        $user = $this->getUser();
        if($user->getTFAVerif() != sha1($code))
            throw $this->createAccessDeniedException();

        $form = $this->createFormBuilder()
            ->add('tfa', NumberType::class)
            ->add('send', SubmitType::class, array('label' => "Enable {$message}"))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();

            if ($this->get('scheb_two_factor.security.google_authenticator')->checkCode($user, $data['tfa']))
            {
                if($method == 'iplock')
                    $user->setLocked(5);
                else
                    $user->setLocked(12);

                $user->setTFAVerif(NULL);
                $em = $this->getDoctrine()->getManager('auth');
                $em->merge($user);
                $em->flush();
                $this->addFlash('success',"You successfully enabled the two-factor authentication solution: {$message}!");
                return $this->redirectToRoute('user_panel');
            }
            else
                $this->addFlash('danger','The six-digit code you provided did not work. Please provide the latest one from the application.');
        }
        return $this->render('2fa/confirm.html.twig', array(
            'form'  => $form->createView(),
            'mod'   => $message,
            'state' => 'Confirm',
        ));
    }
}
