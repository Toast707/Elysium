<?php

namespace AppBundle\Controller;

use AppBundle\Entity\NostalriusToken;
use AuthBundle\Entity\AccountBanned;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use AuthBundle\Entity\Account;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use EWZ\Bundle\RecaptchaBundle\Form\Type\EWZRecaptchaType;
use EWZ\Bundle\RecaptchaBundle\Validator\Constraints\IsTrue as RecaptchaTrue;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Swift_Message;
use Swift_Signers_DKIMSigner;

class ControlController extends Controller
{
    /**
     * @Route("/control", name="control_panel")
     */
    public function loginAction(Request $request)
    {
        $authenticationUtils = $this->get('security.authentication_utils');

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();

        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();

        return $this->render('default/control.html.twig', array(
            'last_username' => $lastUsername,
            'error'         => $error,
        ));
    }

    /**
     * @Route("/control/user", name="user_panel")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function userAction(Request $request)
    {
        $em = $this->getDoctrine();
        $user = $this->getUser();

        $characters = [];
        $redis = $this->get('snc_redis.default');
        $characters = $redis->get("web:account_{$user->getUsername()}");
        if(!$characters)
        {
            $realms = $this->getParameter('realms');
            foreach($realms as $realmId => $realm)
            {
                $chars = $em->getRepository('CharacterBundle:Characters', "realm{$realmId}")->findByAccount($user->getId());
                if($chars)
                    $characters[$realm['name']] = $chars;
            }
            $redis->set("web:account_{$user->getUsername()}", serialize($characters));
            $redis->expire("web:account_{$user->getUsername()}", 300);
            $redis->ttl("web:account_{$user->getUsername()}");
        }
        else
            $characters = unserialize($characters);

        $form = $this->createFormBuilder()
            ->add('send', SubmitType::class, array('label' => 'Send me the reset password email'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $account = $this->getUser();
            if($account->isNostalriusRecover() && $account->isBanned())
            {
                $this->addFlash('danger', 'This account is under the process of Nostalrius account recover.');
                return $this->render('default/user.html.twig', array(
                    'form'          => $form->createView(),
                    'characters'    => $characters,
                ));
            }

            $activationCode = $this->get('app.service.mail')->getCode();

            $account->setPassVerif(sha1($activationCode));
            $em = $this->getDoctrine()->getManager('auth');
            $em->merge($account);
            $em->flush();

            $this->get('app.service.mail')->sendMail(
                '[Elysium Project] Password reset',
                array($account->getEmail() => $account->getUsername()),
                'password_reset',
                array(
                    'title'     => "Password reset",
                    'username'  => $account->getUsername(),
                    'cta_link'  => $this->generateUrl('password_reset_token', array('token' => $activationCode)),
                    'cta_text'  => 'Reset your password',
                ));

            $this->addFlash('success', "An email was sent to {$account->getEmail()}. Elysium is sending an industrial amount of emails and we may have reached your provider rate's limit. If you do not receive the email after an hour, please retry in an hour.");
        }

        return $this->render('default/user.html.twig', array(
            'form'          => $form->createView(),
            'characters'    => $characters,
        ));
    }

    /**
     * @Route("/play", name="register")
     */
    public function playAction(Request $request)
    {
        if($this->getParameter('stress_test'))
            $accounts = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->countAccounts();
        else
            $accounts = null;

        if($this->getParameter('registration'))
        {
            $account = new Account();
            $form = $this->createFormBuilder($account)
                ->add('username', TextType::class)
                ->add('password', RepeatedType::class, array(
                    'type'              => PasswordType::class,
                    'invalid_message'   => 'The password fields must match.',
                    'options'           => array('attr' => array('class' => 'password-field')),
                    'required'          => true,
                    'first_options'     => array('label' => 'Password'),
                    'second_options'    => array('label' => 'Repeat Password'),
                ))
                ->add('email', EmailType::class)
                ->add('termsOfUse', CheckboxType::class)
                ->add('recaptcha', EWZRecaptchaType::class, array(
                    'constraints' => array(
                        new RecaptchaTrue()
                    ),
                    'attr' => array(
                        'options' => array(
                            'theme' => 'dark',
                            'type'  => 'image',
                            'size'  => 'normal',
                            'defer' => true,
                            'async' => true
                        )
                    )))
                ->add('save', SubmitType::class, array('label' => 'Register'))
                ->getForm();

            $form->handleRequest($request);

            if ($form->isSubmitted() && $form->isValid())
            {
                if($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_FULLY'))
                    return $this->redirectToRoute('user_panel');

                $validator = $this->get('validator');
                $errors = $validator->validate($account);

                if(count($errors) > 0)
                    return $this->render('default/play.twig', array(
                        'form'  => $form->createView(),
                        'error' => $errors,
                    ));

                if($this->getParameter('ip_lock') > 0)
                {
                    $ip = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->findBy(array('lastIp' => $request->getClientIp()));
                    if(key($ip) > $this->getParameter('ip_lock'))
                        return $this->render('default/play.html.twig', array(
                            'form'      => $form->createView(),
                            'accounts'  => $accounts,
                            'error'     => "This IP address is already linked to a maximum of {$this->getParameter('ip_lock')} account".($this->getParameter('ip_lock') > 1) ? 's' : ''.".",
                        ));
                }

                $account = $form->getData();
                $username = $account->getUsername();
                $account->setUsername(strtoupper($account->getUsername()));
                $account->setSalt($account->getUsername());
                $account->setLastIp($request->getClientIp());
                $account->setShaPassHash(strtoupper(sha1(strtoupper($account->getUsername()).':'.strtoupper($account->getRealPassword()))));

                if($this->getParameter('email_validation'))
                {
                    $activationCode = $this->get('app.service.mail')->getCode();

                    $this->get('app.service.mail')->sendMail(
                        "Welcome to Elysium, {$username}!",
                        array($account->getEmail() => $account->getUsername()),
                        'email_validation',
                        array(
                            'title'     => "Welcome to Elysium, {$username}!",
                            'username'  => $username,
                            'cta_link'  => $this->generateUrl('email_activation', array('code' => $activationCode)),
                            'cta_text'  => 'Verify your e-mail address',
                        ));

                    $account->setBanned(true);
                    $account->setEmailCheck(sha1($activationCode));
                }

                $em = $this->getDoctrine()->getManager('auth');
                $em->persist($account);
                $em->flush();

                if($this->getParameter('email_validation'))
                {
                    $ban = new AccountBanned();
                    $ban->setId($account->getId());
                    $ban->setBandate(time());
                    $ban->setUnbandate(time());
                    $ban->setBannedby('Web');
                    $ban->setBanreason('Email not verified');
                    $ban->setActive(true);
                    $em->persist($ban);
                    $em->flush();
                }

                return $this->render('default/play.html.twig', array(
                    'success_registration'  => true,
                    'accounts'              => $accounts,
                ));
            }
            return $this->render('default/play.html.twig', array(
                'form'      => $form->createView(),
                'accounts'  => $accounts,
            ));
        }
        else
            return $this->render('default/play.html.twig');
    }

    /**
     * @Route("/email/resend", name="email_activate_resend")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function emailResendAction(Request $request)
    {
        $activationCode = $this->get('app.service.mail')->getCode();

        $user = $this->getUser();
        $this->get('app.service.mail')->sendMail(
            "Welcome to Elysium, {$user->getUsername()}!",
            array($user->getEmail() => $user->getUsername()),
            'email_validation',
            array(
                'title'     => "Welcome to Elysium, {$user->getUsername()}!",
                'username'  => $user->getUsername(),
                'cta_link'  => $this->generateUrl('email_activation', array('code' => $activationCode)),
                'cta_text'  => 'Verify your e-mail address',
            ));

        $user->setEmailCheck(sha1($activationCode));
        $em = $this->getDoctrine()->getManager('auth');
        $em->merge($user);
        $em->flush();
        $this->addFlash('success', 'A new activation email was sent with a new activation code. Please check your spam folder.');
        return $this->redirectToRoute('user_panel');
    }

    /**
     * @Route("/email/{code}", name="email_activation")
     */
    public function emailActivateAction(Request $request, $code)
    {
        // Check if token exists and its length
        if(!$code || strlen($code) != 15)
            return $this->render('default/activate.html.twig', array(
                'error' => 'Your activation code is invalid.',
            ));

        $account = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->findOneBy(array('emailCheck' => sha1($code)));

        if($account == NULL)
            return $this->render('default/activate.html.twig', array(
                'error'=> 'Your activation code is invalid.',
            ));

        $account->setEmailCheck(NULL);
        $account->setEmailVerif(true);
        $account->setBanned(false);

        $em = $this->getDoctrine()->getManager('auth');
        $em->getRepository('AuthBundle:AccountBanned')->removeWebBan($account->getId());
        $em->merge($account);
        $em->flush();

        $this->authenticateUser($account);

        return $this->render('default/activate.html.twig');
    }

    /**
     * @param Account $user
     */
    private function authenticateUser(Account $user)
    {
        $providerKey = 'main'; // your firewall name
        $token = new UsernamePasswordToken($user, null, $providerKey, $user->getRoles());

        $this->get('security.token_storage')->setToken($token);
    }

    /**
     * Change the locale for the current user
     *
     * @param String $language
     * @return array
     *
     * @Route("/locale/{language}", name="set_locale")
     */
    public function localeAction(Request $request, $language = null)
    {
        if($language != null)
            $this->get('session')->set('_locale', $language);

        $url = $request->headers->get('referer');
        if(empty($url))
            return $this->redirectToRoute('homepage');

        return new RedirectResponse($url);
    }

    /**
     * @Route("/login", name="login")
     */
    public function loginRedirectAction(Request $request)
    {
        return $this->redirectToRoute('control_panel');
    }
}