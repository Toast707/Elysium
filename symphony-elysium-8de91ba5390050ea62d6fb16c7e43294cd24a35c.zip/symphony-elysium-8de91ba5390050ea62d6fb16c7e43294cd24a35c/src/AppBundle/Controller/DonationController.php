<?php

namespace AppBundle\Controller;

use Payum\Core\Request\GetHumanStatus;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class DonationController extends Controller
{
    /**
     * @Route("/control/user/donate", name="control_user_donate")
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     */
    public function prepareAction(Request $request)
    {
        return $this->render('default/donate.html.twig');
    }
}