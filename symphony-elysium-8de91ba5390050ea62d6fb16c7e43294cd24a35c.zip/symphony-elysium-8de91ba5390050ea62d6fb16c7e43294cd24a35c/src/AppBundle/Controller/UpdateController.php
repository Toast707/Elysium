<?php

namespace AppBundle\Controller;

use LogBundle\Entity\Character;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class UpdateController extends Controller
{
    /**
     * @Route("/admin/update/realm", name="update_realms")
     * @Security("is_granted('ROLE_GM6')")
     */
    public function armoryRealmAction(Request $request)
    {
        $redis = $this->get('snc_redis.default');
        $realms = $this->getDoctrine()->getRepository('AuthBundle:Realmlist', 'auth')->findAll();
        $redis->set('web:realms', serialize($realms));
        $redis->ttl('web:realms');
        return $this->render('update/index.html.twig', array('info' => 'realms'));
    }
}