<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use EWZ\Bundle\RecaptchaBundle\Form\Type\EWZRecaptchaType;
use EWZ\Bundle\RecaptchaBundle\Validator\Constraints\IsTrue as RecaptchaTrue;
use AuthBundle\Entity\AccountBanned;
use Swift_Signers_DKIMSigner;

class RecoverCompromisedNostalriusController extends Controller
{
    /**
     * @Route("/recover/nostalrius", name="recover_nostalrius")
     */
    public function prepareAction(Request $request)
    {
        if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_FULLY'))
            return $this->redirectToRoute('user_panel');

        $form = $this->createFormBuilder()
            ->add('character', TextType::class)
            ->add('realm', ChoiceType::class, array(
                'choices' => array(
                    'Nostalrius PvP' => 1,
                    'Nostalrius PvE' => 2
                )
            ))
            ->add('email', EmailType::class)
            ->add('recaptcha', EWZRecaptchaType::class, array(
                'constraints' => array(
                    new RecaptchaTrue()
                ),
                'attr' => array(
                    'options' => array(
                        'theme' => 'dark',
                        'type'  => 'image',
                        'size'  => 'normal',
                        'defer' => true,
                        'async' => true
                    )
                )))
            ->add('send', SubmitType::class, array('label' => 'Recover your Nostalrius account'))
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            if ($this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_FULLY'))
                return $this->redirectToRoute('user_panel');

            $em = $this->getDoctrine();
            $data = $form->getData();

            if($data['realm'] < 1 || $data['realm'] > 2)
            {
                $this->addFlash('danger', 'You must select a valid realm.');
                return $this->render('default/recover_nostalrius.html.twig', array(
                    'form' 	=> $form->createView()
                ));
            }

            // Get accounts by email
            $accounts = $em->getRepository('AuthBundle:Account', 'auth')->findBy(array('nostalriusEmail' => $data['email']));
            if($accounts == NULL)
            {
                $this->addFlash('danger', 'There is no transferred account with this email.');
                return $this->render('default/recover_nostalrius.html.twig', array(
                    'form' 	=> $form->createView()
                ));
            }

            foreach($accounts as $account)
            {
                // Get first character by account
                $character = $em->getRepository('CharacterBundle:Characters', "realm{$data['realm']}")->findOneByAccount(array('account' => $account->getId()));
                if($character == NULL || $character->getName() != ucfirst($data['character']))
                    continue;

                // Generate token for password recover
                $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $charactersLength = strlen($characters);
                $activationCode = '';
                for ($i = 0; $i < 15; $i++)
                    $activationCode .= $characters[rand(0, $charactersLength - 1)];


                // Update the account data
                $account->setNostalriusRecover(true);
                $account->setBanned(true);
                $account->setPassVerif(sha1($activationCode));
                $account->setV(NULL);
                $account->setS(NULL);

                // Remove TFA
                $account->setLocked(0);
                $account->setTFAVerif(NULL);
                $account->setGoogleAuthenticatorSecret(NULL);

                $ban = new AccountBanned();
                $ban->setId($account->getId());
                $ban->setBandate(time());
                $ban->setUnbandate(time());
                $ban->setBannedby('Web');
                $ban->setBanreason('Nostalrius recover');
                $ban->setActive(true);

                $this->get('app.service.mail')->sendMail(
                    '[Elysium Project] Nostalrius recover',
                    array($account->getNostalriusEmail() => $account->getUsername()),
                    'password_reset',
                    array(
                        'title'     => "Password reset",
                        'username'  => $account->getUsername(),
                        'cta_link'  => $this->generateUrl('password_reset_token', array('token' => $activationCode)),
                        'cta_text'  => 'Reset your password',
                    ));

                $em = $em->getManager('auth');
                $em->merge($account);
                $em->persist($ban);
                $em->flush();

                $this->addFlash('success', "An email was sent to {$account->getNostalriusEmail()}. Elysium is sending an industrial amount of emails and we may have reached your provider rate's limit. If you do not receive the email after an hour, retry this form.");

                return $this->render('default/recover_nostalrius.html.twig', array(
                    'form' => $form->createView(),
                ));
            }
            $this->addFlash('danger', "No '{$data['character']}' was found as a top most character in the character list of any account registered with '{$data['email']}'.");
        }
        return $this->render('default/recover_nostalrius.html.twig', array(
            'form' => $form->createView(),
        ));
    }
}