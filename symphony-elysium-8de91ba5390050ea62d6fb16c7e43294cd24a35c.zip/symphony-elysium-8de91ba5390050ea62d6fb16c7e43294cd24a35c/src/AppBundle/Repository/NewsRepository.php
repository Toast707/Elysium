<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use AppBundle\Entity\News;

/**
 * Class NewsRepository
 * @package AppBundle\Repository\Log
 */
class NewsRepository extends EntityRepository
{
    public function findByDate(\Datetime $date)
    {
        $from = new \DateTime($date->format("Y-m-d") . " 00:00:00");
        $to = new \DateTime($date->format("Y-m-d") . " 23:59:59");

        $result = $this->createQueryBuilder("n")
            ->andWhere('n.createdAt BETWEEN :from AND :to')
            ->setParameter('from', $from)
            ->setParameter('to', $to)
            ->andWhere('n.type = :patch')
            ->setParameter('patch', News::TYPE_PATCHNOTES)
            ->andWhere('n.enabled = :active')
            ->setParameter('active', true)
            ->getQuery()
            ->getOneOrNullResult();
        return $result;
    }
}