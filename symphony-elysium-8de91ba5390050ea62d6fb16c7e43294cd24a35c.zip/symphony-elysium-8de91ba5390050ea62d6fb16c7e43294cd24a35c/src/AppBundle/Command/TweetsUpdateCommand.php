<?php

namespace AppBundle\Command;

use Exception;
use Abraham\TwitterOAuth\TwitterOAuth;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class TweetsUpdateCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName("tweets:update")
            ->setDescription("Update the tweets.");
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $redis = $this->getContainer()->get('snc_redis.default');

        $connection = new TwitterOAuth(
            $this->getContainer()->getParameter('twitter_consumer_key'),
            $this->getContainer()->getParameter('twitter_consumer_secret'),
            $this->getContainer()->getParameter('twitter_access_token'),
            $this->getContainer()->getParameter('twitter_token_secret')
        );

        $tweets = $connection->get("statuses/user_timeline", ["count" => 50, "screen_name" => "NostalBegins", "exclude_replies" => true, "include_rts" => false]);

        $keys = $redis->keys('*');
        foreach ($keys as $key) {
            $redis->del($key);
        }

        // Stock in redis
        foreach($tweets as $tweet)
        {
            $data = [
                'text'          => $tweet->text,
                'created_at'    => $tweet->created_at,
                'media'         => NULL,
            ];
            if(isset($tweet->entities->media))
                $data['media'] = $tweet->entities->media[0]->media_url;

            $redis->set('tweet_'.$tweet->id, serialize($data));
        }
        $output->writeln('<info>Tweets are updated.</info>');
    }
}