<?php

namespace AppBundle\Entity;

class NostalriusToken
{
    protected $keyFolder            = __DIR__.'/../Resources/keys/';
    protected $nostalriusPublicKey  = 'nostalrius_public';
    protected $elysiumPublicKey     = 'elysium_public';
    protected $elysiumPrivateKey    = 'elysium_private';
    protected $keyLength            = 8192;
    protected $version              = 1;
    protected $tokenPrefix          = '<NOST_TOKEN';
    protected $tokenSuffix          = 'NOST_TOKEN>';
    protected $tokenSeparator       = ':';
    protected $token;
    protected $data;


    /**
     * @param $data_str_encrypted
     * @param $data_str
     * @param $priv_key
     * @return bool
     */
    function decrypt($data_str_encrypted, &$data_str, $priv_key)
    {
        $a_key = openssl_pkey_get_details($priv_key);
        $chunkSize = ceil($a_key['bits'] / 8);

        $data_str = '';
        while ($data_str_encrypted)
        {
            $chunk = substr($data_str_encrypted, 0, $chunkSize);
            $data_str_encrypted = substr($data_str_encrypted, $chunkSize);
            $decrypted = '';
            if (!openssl_private_decrypt($chunk, $decrypted, $priv_key))
                return false;
            $data_str .= $decrypted;
        }
        $data_str = gzuncompress($data_str);
        return true;
    }

    /**
     * @return string
     */
    public function extractToken()
    {
        // 0. Check and extract suffix / prefix
        $this->setToken(trim($this->getToken()));
        $token_parts = explode($this->tokenSeparator, $this->getToken());
        if (count($token_parts) != 3)
            return "Your Nostalrius token should start with '{$this->tokenPrefix}' and end with '{$this->tokenSuffix}'.";
        if ($token_parts[0] != $this->tokenPrefix)
            return "Your Nostalrius token should start with '{$this->tokenPrefix}'.'";
        if ($token_parts[2] != $this->tokenSuffix)
            return "Your Nostalrius token should end with '{$this->tokenSuffix}'.'";
        $this->setToken($token_parts[1]);

        // 1. Retrieve signature / data
        $splitted = explode('-', $this->getToken());
        if (count($splitted) != 2)
            return 'Your Nostalrius token has a bad format.';
        $data_encrypted = base64_decode($splitted[0]);
        $data_signature = base64_decode($splitted[1]);
        if (!$data_encrypted || !$data_signature)
            return 'Your Nostalrius token does not have a correct format.';

        // 2. Check signature
        $nost_pub_key = openssl_pkey_get_public(file_get_contents($this->getKeyFolder().$this->getNostalriusPublicKey()));
        if (!$nost_pub_key)
            return 'Unable to open Nostalrius\' public key to continue the transfer.';
        $sign_verify = openssl_verify($data_encrypted, $data_signature, $nost_pub_key);
        if ($sign_verify == 0)
            return 'Your Nostalrius token is invalid.';
        else if ($sign_verify != 1)
            return 'Your Nostalrius token did not pass the signature verification check.';

        // 3. Decrypt data
        $ely_priv_key = openssl_pkey_get_private(file_get_contents($this->getKeyFolder().$this->getElysiumPrivateKey()));
        if (!$ely_priv_key)
            return 'Unable to open Elysium\'s private key to continue the transfer.';
        $data_decrypted = null;
        if (!$this->decrypt($data_encrypted, $data_decrypted, $ely_priv_key))
            return 'Something went wrong with the data decryption.';

        // 4. So we can unserialize it now :)
        $data_unserialized = unserialize($data_decrypted);
        $this->setData($data_unserialized['data']);
        return true;
    }

    /**
     * @return string
     */
    protected function getKeyFolder()
    {
        return $this->keyFolder;
    }

    /**
     * @return string
     */
    public function getNostalriusPublicKey()
    {
        return $this->nostalriusPublicKey;
    }

    /**
     * @param string $nostalriusPublicKey
     */
    public function setNostalriusPublicKey($nostalriusPublicKey)
    {
        $this->nostalriusPublicKey = $nostalriusPublicKey;
    }

    /**
     * @return string
     */
    public function getElysiumPublicKey()
    {
        return $this->elysiumPublicKey;
    }

    /**
     * @param string $elysiumPublicKey
     */
    public function setElysiumPublicKey($elysiumPublicKey)
    {
        $this->elysiumPublicKey = $elysiumPublicKey;
    }

    /**
     * @return string
     */
    public function getElysiumPrivateKey()
    {
        return $this->elysiumPrivateKey;
    }

    /**
     * @param string $elysiumPrivateKey
     */
    public function setElysiumPrivateKey($elysiumPrivateKey)
    {
        $this->elysiumPrivateKey = $elysiumPrivateKey;
    }

    /**
     * @return int
     */
    public function getKeyLength()
    {
        return $this->keyLength;
    }

    /**
     * @param int $keyLength
     */
    public function setKeyLength($keyLength)
    {
        $this->keyLength = $keyLength;
    }

    /**
     * @return int
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * @param int $version
     */
    public function setVersion($version)
    {
        $this->version = $version;
    }

    /**
     * @return string
     */
    public function getTokenPrefix()
    {
        return $this->tokenPrefix;
    }

    /**
     * @param string $tokenPrefix
     */
    public function setTokenPrefix($tokenPrefix)
    {
        $this->tokenPrefix = $tokenPrefix;
    }

    /**
     * @return string
     */
    public function getTokenSuffix()
    {
        return $this->tokenSuffix;
    }

    /**
     * @param string $tokenSuffix
     */
    public function setTokenSuffix($tokenSuffix)
    {
        $this->tokenSuffix = $tokenSuffix;
    }

    /**
     * @return string
     */
    public function getTokenSeparator()
    {
        return $this->tokenSeparator;
    }

    /**
     * @param string $tokenSeparator
     */
    public function setTokenSeparator($tokenSeparator)
    {
        $this->tokenSeparator = $tokenSeparator;
    }

    /**
     * @return mixed
     */
    public function getToken()
    {
        return $this->token;
    }

    /**
     * @param mixed $token
     */
    public function setToken($token)
    {
        $this->token = $token;
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param mixed $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }
}
