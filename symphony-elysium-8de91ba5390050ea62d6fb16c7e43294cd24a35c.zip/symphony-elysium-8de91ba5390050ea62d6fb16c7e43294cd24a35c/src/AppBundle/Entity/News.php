<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * News
 *
 * @ORM\Table(name="news")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\NewsRepository")
 */
class News
{
    const TYPE_NEWS         = 0;
    const TYPE_PATCHNOTES   = 1;

    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\Column(name="id", type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var \DateTime $createdAt
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(name="created_at", type="datetime")
     */
    protected $createdAt;

    /**
     * @var string
     *
     * @ORM\Column(name="title_en", type="string", length=100, nullable=false)
     */
    protected $titleEn;

    /**
     * @var string
     *
     * @ORM\Column(name="title_ru", type="string", length=100, nullable=false)
     */
    protected $titleRu;

    /**
     * @var text
     *
     * @ORM\Column(name="text_en", type="text", nullable=false)
     */
    protected $textEn;

    /**
     * @var text
     *
     * @ORM\Column(name="text_ru", type="text", nullable=false)
     */
    protected $textRu;

    /**
     * @var string
     *
     * @ORM\Column(name="forum_en", type="string")
     */
    protected $forumEn;

    /**
     * @var string
     *
     * @ORM\Column(name="forum_ru", type="string")
     */
    protected $forumRu;

    /**
     * @var string
     *
     * @ORM\Column(name="image", type="string", length=255, nullable=false)
     */
    protected $image;

    /**
     * @var string
     *
     * @ORM\Column(name="link", type="string", length=32, nullable=false)
     */
    protected $link;

    /**
     * @var boolean
     *
     * @ORM\Column(name="enabled", type="boolean", nullable=false)
     */
    protected $enabled = false;

    /**
     * @var boolean
     *
     * @ORM\Column(name="type", type="boolean", nullable=false)
     */
    protected $type;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param \DateTime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return string
     */
    public function getTitleEn()
    {
        return $this->titleEn;
    }

    /**
     * @param string $titleEn
     */
    public function setTitleEn($titleEn)
    {
        $this->titleEn = $titleEn;
    }

    /**
     * @return string
     */
    public function getTitleRu()
    {
        return $this->titleRu;
    }

    /**
     * @param string $titleRu
     */
    public function setTitleRu($titleRu)
    {
        $this->titleRu = $titleRu;
    }

    /**
     * @return text
     */
    public function getTextEn()
    {
        return $this->textEn;
    }

    /**
     * @param text $textEn
     */
    public function setTextEn($textEn)
    {
        $this->textEn = $textEn;
    }

    /**
     * @return text
     */
    public function getTextRu()
    {
        return $this->textRu;
    }

    /**
     * @param text $textRu
     */
    public function setTextRu($textRu)
    {
        $this->textRu = $textRu;
    }

    /**
     * @return int
     */
    public function getForumEn()
    {
        return $this->forumEn;
    }

    /**
     * @param int $forumEn
     */
    public function setForumEn($forumEn)
    {
        $this->forumEn = $forumEn;
    }

    /**
     * @return int
     */
    public function getForumRu()
    {
        return $this->forumRu;
    }

    /**
     * @param int $forumRu
     */
    public function setForumRu($forumRu)
    {
        $this->forumRu = $forumRu;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param string $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return string
     */
    public function getLink()
    {
        return $this->link;
    }

    /**
     * @param string $link
     */
    public function setLink($link)
    {
        $this->link = $link;
    }

    /**
     * @return boolean
     */
    public function isEnabled()
    {
        return $this->enabled;
    }

    /**
     * @param boolean $enabled
     */
    public function setEnabled($enabled)
    {
        $this->enabled = $enabled;
    }

    /**
     * @return boolean
     */
    public function isType()
    {
        return $this->type;
    }

    /**
     * @param boolean $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }
}