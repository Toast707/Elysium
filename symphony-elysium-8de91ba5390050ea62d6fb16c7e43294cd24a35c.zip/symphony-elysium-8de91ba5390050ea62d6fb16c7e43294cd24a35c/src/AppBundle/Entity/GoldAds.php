<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="gold_ads")
 * @ORM\Entity
 */
class GoldAds
{
    /**
	 * @var integer
	 *
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
	 * @ORM\Column(name="id", type="integer")
	 */
	protected $id;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="account_id", type="integer")
	 */
	protected $accountId;

    /**
	 * @var string
	 *
	 * @ORM\Column(name="username", type="string", length=16)
	 */
	protected $username;

    /**
	 * @var string
	 *
	 * @ORM\Column(name="email", type="string", length=255)
	 */
	protected $email;

    /**
	 * @var string
	 *
	 * @ORM\Column(name="ip", type="string", length=20)
	 */
	protected $ip;

    /**
	 * @var \DateTime
	 *
	 * @ORM\Column(name="created_at", type="datetime")
	 */
	protected $createdAt;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="tfa", type="integer", length=2)
	 */
	protected $tfa;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="chars_count", type="integer", length=1)
	 */
	protected $charsCount;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="chars_level_avg", type="integer", length=2)
	 */
	protected $charsLevelAvg;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="chars_level_max", type="integer", length=2)
	 */
	protected $charsLevelMax;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="realm", type="integer", length=1)
	 */
	protected $realm;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="guid", type="integer")
	 */
	protected $guid;

    /**
	 * @var string
	 *
	 * @ORM\Column(name="name", type="string", length=12)
	 */
	protected $name;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="level", type="integer", length=2)
	 */
	protected $level;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="race", type="integer", length=2)
	 */
	protected $race;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="class", type="integer", length=2)
	 */
	protected $class;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="money", type="integer")
	 */
	protected $money;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="played", type="integer")
	 */
	protected $played;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="zone", type="integer")
	 */
	protected $zone;

    /**
	 * @var integer
	 *
	 * @ORM\Column(name="area", type="integer")
	 */
	protected $area;

    /**
	 * @var string
	 *
	 * @ORM\Column(name="message", type="string")
	 */
	protected $message;


    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getAccountId()
    {
        return $this->accountId;
    }

    /**
     * @param int $accountId
     */
    public function setAccountId($accountId)
    {
        $this->accountId = $accountId;
    }

    /**
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param string $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getIp()
    {
        return $this->ip;
    }

    /**
     * @param string $ip
     */
    public function setIp($ip)
    {
        $this->ip = $ip;
    }

    /**
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param \DateTime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return int
     */
    public function getTfa()
    {
        return $this->tfa;
    }

    /**
     * @param int $tfa
     */
    public function setTfa($tfa)
    {
        $this->tfa = $tfa;
    }

    /**
     * @return int
     */
    public function getCharsCount()
    {
        return $this->charsCount;
    }

    /**
     * @param int $charsCount
     */
    public function setCharsCount($charsCount)
    {
        $this->charsCount = $charsCount;
    }

    /**
     * @return int
     */
    public function getCharsLevelAvg()
    {
        return $this->charsLevelAvg;
    }

    /**
     * @param int $charsLevelAvg
     */
    public function setCharsLevelAvg($charsLevelAvg)
    {
        $this->charsLevelAvg = $charsLevelAvg;
    }

    /**
     * @return int
     */
    public function getCharsLevelMax()
    {
        return $this->charsLevelMax;
    }

    /**
     * @param int $charsLevelMax
     */
    public function setCharsLevelMax($charsLevelMax)
    {
        $this->charsLevelMax = $charsLevelMax;
    }

    /**
     * @return int
     */
    public function getRealm()
    {
        return $this->realm;
    }

    /**
     * @param int $realm
     */
    public function setRealm($realm)
    {
        $this->realm = $realm;
    }

    /**
     * @return int
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * @param int $guid
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return int
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * @param int $level
     */
    public function setLevel($level)
    {
        $this->level = $level;
    }

    /**
     * @return int
     */
    public function getRace()
    {
        return $this->race;
    }

    /**
     * @param int $race
     */
    public function setRace($race)
    {
        $this->race = $race;
    }

    /**
     * @return int
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * @param int $class
     */
    public function setClass($class)
    {
        $this->class = $class;
    }

    /**
     * @return int
     */
    public function getMoney()
    {
        return $this->money;
    }

    /**
     * @param int $money
     */
    public function setMoney($money)
    {
        $this->money = $money;
    }

    /**
     * @return int
     */
    public function getPlayed()
    {
        return $this->played;
    }

    /**
     * @param int $played
     */
    public function setPlayed($played)
    {
        $this->played = $played;
    }

    /**
     * @return int
     */
    public function getZone()
    {
        return $this->zone;
    }

    /**
     * @param int $zone
     */
    public function setZone($zone)
    {
        $this->zone = $zone;
    }

    /**
     * @return int
     */
    public function getArea()
    {
        return $this->area;
    }

    /**
     * @param int $area
     */
    public function setArea($area)
    {
        $this->area = $area;
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param string $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }
}