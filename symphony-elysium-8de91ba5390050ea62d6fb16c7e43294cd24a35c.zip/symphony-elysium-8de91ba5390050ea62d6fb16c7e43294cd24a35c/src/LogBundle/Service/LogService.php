<?php

namespace LogBundle\Service;

use Symfony\Component\DependencyInjection\ContainerInterface;

class LogService
{
    private $redis;
    private $em;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->redis     = $container->get('snc_redis.default');
        $this->em        = $container->get('doctrine');
    }

    /**
     * Get chat logs between two dates
     *
     * @param $realm
     * @param $guid
     * @param $start
     * @param $end
     * @return mixed
     */
    public function getChatBetween($realm, $guid, $start, $end)
    {
        $sql = 'SELECT
                    chat.time, chat.type, chat.guid, chat.target, chat.channelId, chat.channelName, chat.message,
                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.guid ORDER BY time DESC LIMIT 1) as guidName,
                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.target ORDER BY time DESC LIMIT 1) as targetName
                FROM logs_chat as chat
                WHERE (time BETWEEN :start AND :end) AND (chat.guid = :guid OR chat.target = :guid)
                ORDER BY chat.time DESC';
        $query = $this->em->getManager("log{$realm}")->getConnection()->prepare($sql);
        $query->execute(array(
            'guid' => $guid,
            'start' => $start->format('Y-m-d H:i:s'),
            'end'   => $end->format('Y-m-d H:i:s')));
        return $query->fetchAll();
    }

    /**
     * Get chat logs between two dates
     *
     * @param $realm
     * @param $guid
     * @param $start
     * @param $end
     * @return mixed
     */
    public function getHistoryBetween($realm, $guid, $start, $end)
    {
        $sql = 'SELECT time, type, ip
                FROM logs_characters
                WHERE (time BETWEEN :start AND :end) AND guid = :guid
                ORDER BY time DESC';
        $query = $this->em->getManager("log{$realm}")->getConnection()->prepare($sql);
        $query->execute(array(
            'guid' => $guid,
            'start' => $start->format('Y-m-d H:i:s'),
            'end'   => $end->format('Y-m-d H:i:s')));
        return $query->fetchAll();
    }
}