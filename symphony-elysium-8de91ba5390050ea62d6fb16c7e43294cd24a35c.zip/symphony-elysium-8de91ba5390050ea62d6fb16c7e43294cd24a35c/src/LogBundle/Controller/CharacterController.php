<?php

namespace LogBundle\Controller;

use AuthBundle\Entity\AccountBanned;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class CharacterController extends Controller
{
    /**
     * Verify that the realm name given corresponds to a realm.
     *
     * @param $realms
     * @param $name
     * @return mixed
     */
    private function verifyRealm($realms, $name)
    {
        $ok = false;
        foreach($realms as $rlm)
        {
            if($rlm->getName() == $name && $rlm->getId() < 10)
            {
                $realm = $rlm;
                $ok = true;
                break;
            }
        }
        if($ok === false)
            throw $this->createNotFoundException('Realm not found');
        return $realm;
    }

    /**
     * @Route("/character", name="gm_characters")
     * @Security("is_granted('ROLE_GM_CHARACTER')")
     */
    public function charactersAction(Request $request)
    {
        return $this->render('gm/character/index.html.twig');
    }

    /**
     * @Route("/character/{realm}/{character}", name="gm_character")
     * @Security("is_granted('ROLE_GM_CHARACTER')")
     */
    public function armoryRealmAction(Request $request, $realm, $character)
    {
        $redis = $this->get('snc_redis.default');
        $realm = $this->verifyRealm(unserialize($redis->get('web:realms')), $realm);

        if(!preg_match('$([a-zA-Z0-9]+)$', $character) || strlen($character) > 12)
            throw $this->createNotFoundException('Character name must be less than 12 alpha(a-z) characters.');

        $character = $this->getDoctrine()->getRepository('CharacterBundle:Characters',"realm{$realm->getId()}")->findOneByName($character);
        if(!$character)
            throw $this->createNotFoundException('This character does not exist.');

        // History
        $yesterday = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
        $now = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
        $form = $this->createFormBuilder()
            ->setMethod('GET')
            ->add('start', DateTimeType::class, array(
                'data' => $yesterday->modify('-2 days')))
            ->add('end', DateTimeType::class, array(
                'data' => $now))
            ->add('search', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            if($data['start'] != $yesterday && $data['end'] != $now)
                $history = $this->get('log.service')->getHistoryBetween($realm->getId(), $character->getGuid(), $data['start'], $data['end']);
            else
                $history = $this->get('log.service')->getHistoryBetween($realm->getId(), $character->getGuid(), $yesterday, $now);
        }
        else
            $history = $this->get('log.service')->getHistoryBetween($realm->getId(), $character->getGuid(), $yesterday, $now);

        $account = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->find($character->getAccount());

        $skills = $redis->get("web:{$realm->getId()}_{$character->getGuid()}_skills");
        if(!$skills)
        {
            $skills = $this->getDoctrine()->getRepository('CharacterBundle:CharacterSkills', "realm{$realm->getId()}")->findByGuid($character->getGuid());
            $skillsDBC = unserialize($redis->get('web:skill'));
            foreach($skills as $key => $skill)
                $skills[$key]->setSkill($skillsDBC[$skill->getSkill()]);

            $redis->set("web:{$realm->getId()}_{$character->getGuid()}_skills", serialize($skills));
            $redis->expire("web:{$realm->getId()}_{$character->getGuid()}_skills", 300);
            $redis->ttl("web:{$realm->getId()}_{$character->getGuid()}_skills");
        }
        else
            $skills = unserialize($skills);

        return $this->render('gm/character/character.html.twig', array(
            'account'   => $account,
            'form'      => $form->createView(),
            'history'   => $history,
            'character' => $character,
            'skills'    => $skills,
            'realm'     => $realm,
        ));
    }

    /**
     * @Route("/character/{realm}/{character}/inventory", name="gm_character_inventory")
     * @Security("is_granted('ROLE_GM_CHARACTER_INVENTORY')")
     */
    public function inventoryAction(Request $request, $realm, $character)
    {
        $redis = $this->get('snc_redis.default');
        $realm = $this->verifyRealm(unserialize($redis->get('web:realms')), $realm);

        if(!preg_match('$([a-zA-Z0-9]+)$', $character) || strlen($character) > 12)
            throw $this->createNotFoundException('Character name must be less than 12 alpha(a-z) characters.');

        $character = $this->getDoctrine()->getRepository('CharacterBundle:Characters',"realm{$realm->getId()}")->findOneByName($character);
        if(!$character)
            throw $this->createNotFoundException('This character does not exist.');

        $inventory = $this->getDoctrine()->getRepository('CharacterBundle:ItemInstance', "realm{$realm->getId()}")->findByOwnerGuid($character->getGuid());

        $encoder = new JsonEncoder();
        $normalizer = new ObjectNormalizer();
        $serializer = new Serializer(array($normalizer), array($encoder));
        return new JsonResponse($serializer->serialize($inventory,'json'));
    }

    /**
     * @Route("/character/{realm}/{character}/reputation", name="gm_character_reputation")
     * @Security("is_granted('ROLE_GM_CHARACTER_REPUTATION')")
     */
    public function reputationAction(Request $request, $realm, $character)
    {
        $redis = $this->get('snc_redis.default');
        $realm = $this->verifyRealm(unserialize($redis->get('web:realms')), $realm);

        if(!preg_match('$([a-zA-Z0-9]+)$', $character) || strlen($character) > 12)
            throw $this->createNotFoundException('Character name must be less than 12 alpha(a-z) characters.');

        $character = $this->getDoctrine()->getRepository('CharacterBundle:Characters',"realm{$realm->getId()}")->findOneByName($character);
        if(!$character)
            throw $this->createNotFoundException('This character does not exist.');


        $reputation = $this->getDoctrine()->getRepository('CharacterBundle:CharacterReputation', "realm{$realm->getId()}")->getActiveReputation($character->getGuid());
        $factions = unserialize($redis->get('web:reputation'));

        $reputations = [];
        foreach($reputation as $key => $rep)
        {
            if($factions[$rep->getFaction()]->getParentFactionId() > 0)
            {
                $parent = $factions[$rep->getFaction()]->getParentFactionId();
                $reputations[$parent]['name'] = $factions[$factions[$rep->getFaction()]->getParentFactionId()]->getNameEnUs();
                $reputations[$parent]['sub'][$rep->getFaction()]['name'] = $factions[$rep->getFaction()]->getNameEnUs();
                for($i = 0; $i < 3; $i++)
                {
                    if($character->getRace() & $factions[$rep->getFaction()]->getRaceMask($i))
                        $reputations[$parent]['sub'][$rep->getFaction()]['points'] = $rep->getStanding() + $factions[$rep->getFaction()]->getBase($i);
                    if($character->getClass() & $factions[$rep->getFaction()]->getClassMask($i))
                        $reputations[$parent]['sub'][$rep->getFaction()]['points'] = $rep->getStanding() + $factions[$rep->getFaction()]->getBase($i);
                }
            }
            else
            {
                $reputations[$rep->getFaction()]['name'] = $factions[$rep->getFaction()]->getNameEnUs();
                for($i = 0; $i < 3; $i++)
                {
                    if($character->getRace() & $factions[$rep->getFaction()]->getRaceMask($i))
                        $reputations[$rep->getFaction()]['points'] = $rep->getStanding() + $factions[$rep->getFaction()]->getBase($i);
                    if($character->getClass() & $factions[$rep->getFaction()]->getClassMask($i))
                        $reputations[$rep->getFaction()]['points'] = $rep->getStanding() + $factions[$rep->getFaction()]->getBase($i);
                }
            }
        }
        return new JsonResponse(json_encode($reputations));
    }

    /**
     * @Route("/character/{realm}/{character}/ban", name="gm_character_ban")
     * @Security("is_granted('ROLE_GM_BAN')")
     */
    public function banAction(Request $request, $realm, $character)
    {
        $redis = $this->get('snc_redis.default');
        $realm = $this->verifyRealm(unserialize($redis->get('web:realms')), $realm);

        if(!preg_match('$([a-zA-Z0-9]+)$', $character) || strlen($character) > 12)
            throw $this->createNotFoundException('Character name must be less than 12 alpha(a-z) characters.');

        $user = $this->getUser();
        $gmAccounts = $this->get('app.service.cache')->getGmAccounts();
        $char = NULL;
        foreach($gmAccounts as $account)
        {
            if($account->getId() != $user->getId())
                continue;

            $char = $account->getCharacters()[0];
        }
        if(!$char)
            throw $this->createNotFoundException('You do not have a character on any realm.');

        $sql = 'SELECT account as id FROM characters WHERE name = :name';
        $query = $this->getDoctrine()->getManager("realm{$realm->getId()}")->getConnection()->prepare($sql);
        $query->execute(array('name' => $character));
        $account = $query->fetch();

        $ban = new AccountBanned();
        $ban->setId($account['id']);
        $ban->setBandate(time());
        $ban->setUnbandate(time());
        $ban->setBannedby($char->getName());
        $ban->setBanreason($request->request->get('banReason'));
        $ban->setActive(true);
        $ban->setRealm($realm->getId());

        $em = $this->getDoctrine()->getManager('auth');
        $em->persist($ban);
        $em->flush();

        return new Response('', Response::HTTP_OK);
    }
}