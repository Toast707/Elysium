<?php

namespace LogBundle\Controller;

use LogBundle\Entity\Character;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use DateTime;
use DateTimeZone;

class TransactionController extends Controller
{
    /**
     * @Route("/transactions/character", name="gm_transactions_character")
     * @Security("is_granted('ROLE_GM_MONITOR_TRANSACTIONS_CHARACTER')")
     */
    public function transactionsCharacterAction(Request $request)
    {
        $formRealms = [];
        foreach($this->getParameter('realms') as $realmId => $realm)
            $formRealms[$realm['name']] = $realmId;
        $yesterday = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $form = $this->createFormBuilder()
            ->add('realms', ChoiceType::class, array(
                'choices' => $formRealms))
            ->add('characters', TextType::class)
            ->add('start', DateTimeType::class, array(
                'data' => $yesterday->modify('-1 day')))
            ->add('end', DateTimeType::class, array(
                'html5' => true,
                'data' => new \DateTime("now", new DateTimeZone('Europe/Paris'))))
            ->add('type', ChoiceType::class, array(
                'choices' => array(
                    'Bid'       => 'Bid',
                    'Buyout'    => 'Buyout',
                    'Trade'     => 'Trade',
                    'Mail'      => 'Mail',
                    'MailCOD'   => 'MailCOD',
                ),
                'multiple' => true,
                'required' => false,
            ))
            ->add('search', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        $realm = NULL;
        $objectCharacters = [];
        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $realm = $data['realms'];
            $characters = explode(',', $data['characters']);

            $guids = NULL;
            foreach($characters as $character)
            {
                $sql = 'SELECT guid, name FROM logs_characters WHERE name = :name ORDER BY time DESC LIMIT 1';
                $query = $this->getDoctrine()->getManager("log{$data['realms']}")->getConnection()->prepare($sql);
                $query->execute(array('name' => $character));
                $result = $query->fetch();
                if(!$result)
                {
                    $this->addFlash('danger',"Could not find the character {$character}.");
                    return $this->render('gm/transactions/character.html.twig', array(
                        'form'          => $form->createView(),
                        'characters'    => $objectCharacters,
                    ));
                }
                $objectCharacters[$result['guid']] = new Character($result);
                $guids .= $result['guid'].',';
            }
            $guids = rtrim($guids, ',');

            if(!$data['type'])
                $types = 'Bid","Buyout","Trade","Mail","MailCOD';
            else
                $types = implode('","', $data['type']);

            $sql = 'SELECT
                         *,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = lt.guid1 ORDER BY time DESC LIMIT 1) as senderName,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = lt.guid2 ORDER BY time DESC LIMIT 1) as receiverName
                    FROM logs_transactions lt WHERE (time BETWEEN :start AND :end) AND type IN ("'.$types.'") AND (guid1 IN ('.$guids.') OR guid2 IN ('.$guids.')) ORDER BY time DESC';
            $query = $this->getDoctrine()->getManager("log{$data['realms']}")->getConnection()->prepare($sql);
            $query->execute(array(
                'start' => $data['start']->format('Y-m-d H:i:s'),
                'end'   => $data['end']->format('Y-m-d H:i:s')));
            $trades = $query->fetchAll();

            foreach($trades as $trade)
            {
                if(isset($objectCharacters[$trade['guid1']]))
                    $objectCharacters[$trade['guid1']]->setSender($trade);

                if(isset($objectCharacters[$trade['guid2']]))
                    $objectCharacters[$trade['guid2']]->setReceiver($trade);
            }
        }

        return $this->render('gm/transactions/character.html.twig', array(
            'form'          => $form->createView(),
            'characters'    => $objectCharacters,
            'realm'         => $realm
        ));
    }

    /**
     * @Route("/transactions/items", name="gm_transactions_items")
     * @Security("is_granted('ROLE_GM_MONITOR_TRANSACTIONS_ITEM')")
     */
    public function transactionsItemsAction(Request $request)
    {
        $formRealms = [];
        foreach($this->getParameter('realms') as $realmId => $realm)
            $formRealms[$realm['name']] = $realmId;
        $yesterday = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $form = $this->createFormBuilder()
            ->add('realms', ChoiceType::class, array(
                'choices' => $formRealms))
            ->add('items', TextType::class)
            ->add('start', DateTimeType::class, array(
                'data' => $yesterday->modify('-1 day')))
            ->add('end', DateTimeType::class, array(
                'html5' => true,
                'data' => new \DateTime("now", new DateTimeZone('Europe/Paris'))))
            ->add('type', ChoiceType::class, array(
                'choices' => array(
                    'Bid'       => 'Bid',
                    'Buyout'    => 'Buyout',
                    'Trade'     => 'Trade',
                    'Mail'      => 'Mail',
                    'MailCOD'   => 'MailCOD',
                ),
                'multiple' => true,
                'required' => false,
            ))
            ->add('search', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        $realm = NULL;
        $trades = [];
        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $realm = $data['realms'];

            if(!$data['type'])
                $types = 'Bid","Buyout","Trade","Mail","MailCOD';
            else
                $types = implode('","', $data['type']);

            $items = explode(',', $data['items']);

            foreach($items as $item)
            {
                $sql = 'SELECT
                         *,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = lt.guid1 ORDER BY time DESC LIMIT 1) as senderName,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = lt.guid2 ORDER BY time DESC LIMIT 1) as receiverName
                    FROM logs_transactions lt WHERE (time BETWEEN :start AND :end) AND type IN ("'.$types.'") AND (items1 LIKE "%'.$item.'%" OR items2 LIKE "%'.$item.'%") ORDER BY time DESC';
                $query = $this->getDoctrine()->getManager("log{$data['realms']}")->getConnection()->prepare($sql);
                $query->execute(array(
                    'start' => $data['start']->format('Y-m-d H:i:s'),
                    'end'   => $data['end']->format('Y-m-d H:i:s')));
                $trades[$item] = $query->fetchAll();
            }

        }

        return $this->render('gm/transactions/items.html.twig', array(
            'form'      => $form->createView(),
            'trades'    => $trades,
            'realm'     => $realm,
        ));
    }

    /**
     * @Route("/transactions/gold", name="gm_transactions_gold")
     * @Security("is_granted('ROLE_GM_MONITOR_TRANSACTIONS_GOLD')")
     */
    public function transactionsGoldAction(Request $request)
    {
        $formRealms = [];
        foreach($this->getParameter('realms') as $realmId => $realm)
            $formRealms[$realm['name']] = $realmId;
        $yesterday = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $form = $this->createFormBuilder()
            ->add('realms', ChoiceType::class, array(
                'choices' => $formRealms))
            ->add('gold', NumberType::class)
            ->add('start', DateTimeType::class, array(
                'data' => $yesterday->modify('-1 day')))
            ->add('end', DateTimeType::class, array(
                'html5' => true,
                'data' => new \DateTime("now", new DateTimeZone('Europe/Paris'))))
            ->add('type', ChoiceType::class, array(
                'choices' => array(
                    'Bid'       => 'Bid',
                    'Buyout'    => 'Buyout',
                    'Trade'     => 'Trade',
                    'Mail'      => 'Mail',
                    'MailCOD'   => 'MailCOD',
                ),
                'multiple' => true,
                'required' => false,
            ))
            ->add('search', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        $realm = NULL;
        $trades = [];
        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $realm = $data['realms'];

            if(!$data['type'])
                $types = 'Bid","Buyout","Trade","Mail","MailCOD';
            else
                $types = implode('","', $data['type']);

            $sql = 'SELECT
                         *,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = lt.guid1 ORDER BY time DESC LIMIT 1) as senderName,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = lt.guid2 ORDER BY time DESC LIMIT 1) as receiverName
                    FROM logs_transactions lt WHERE (time BETWEEN :start AND :end) AND type IN ("'.$types.'") AND (money1 > :money OR money2 > :money) ORDER BY time DESC';
            $query = $this->getDoctrine()->getManager("log{$data['realms']}")->getConnection()->prepare($sql);
            $query->execute(array(
                'start' => $data['start']->format('Y-m-d H:i:s'),
                'end'   => $data['end']->format('Y-m-d H:i:s'),
                'money' => $data['gold']*10000));
            $trades = $query->fetchAll();
        }

        return $this->render('gm/transactions/gold.html.twig', array(
            'form'      => $form->createView(),
            'trades'    => $trades,
            'realm'     => $realm,
        ));
    }
}