<?php

namespace LogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use DateTime;
use DateInterval;
use DateTimeZone;

class TicketController extends Controller
{
    /**
     * @Route("/tickets", name="gm_tickets")
     * @Security("is_granted('ROLE_GM_TICKET')")
     */
    public function ticketAction(Request $request)
    {
        $tickets = $this->get('character.service')->getOpenTickets();

        return $this->render('gm/ticket/index.html.twig', array(
            'tickets' => $tickets,
        ));
    }
    /**
     * @Route("/tickets/stats", name="gm_tickets_stats")
     * @Security("is_granted('ROLE_GM_TICKET_STATS')")
     */
    public function statsAction(Request $request)
    {
        $now = new \DateTime("sunday this week", new DateTimeZone('Europe/Paris'));
        $yesterday = new \DateTime("monday this week", new DateTimeZone('Europe/Paris'));

        $form = NULL;
        if($this->get('security.authorization_checker')->isGranted('ROLE_GM6'))
        {
            $form = $this->createFormBuilder()
                ->setMethod('GET')
                ->add('start', DateTimeType::class, array(
                    'data' => $yesterday))
                ->add('end', DateTimeType::class, array(
                    'data' => $now))
                ->add('search', SubmitType::class)
                ->getForm();

            $form->handleRequest($request);

            if ($form->isSubmitted() && $form->isValid())
            {
                $data = $form->getData();
                if($data['start'] != $yesterday || $data['end'] != $now)
                    $tickets = $this->get('character.service')->getTicketStats($data['start'], $data['end'], true);
                else
                    $tickets = $this->get('character.service')->getTicketStats($yesterday, $now);
            }
            else
                $tickets = $this->get('character.service')->getTicketStats($yesterday, $now);

            $form = $form->createView();
        }
        else
            $tickets = $this->get('character.service')->getTicketStats($yesterday, $now);

        $gmAccounts = $this->get('app.service.cache')->getGmAccounts();
        $characters = [];
        foreach($gmAccounts as $account)
        {
            foreach($account->getCharacters() as $key => $character)
            {
                if($character->getRealm() > 9)
                    continue;
                $characters[$character->getRealm()][] = $character->getName();
            }
        }
        $result = [];
        $total = [];
        foreach($tickets as $realmId => $chars)
        {
            foreach($chars as $character)
            {
                if(!isset($total[$realmId]))
                    $total[$realmId] = 0;
                $total[$realmId] = $total[$realmId] + $character['TicketCount'];
                $result[$character['name']][$realmId] = $character['TicketCount'];
            }
        }

        return $this->render('gm/ticket/stats.html.twig', array(
            'form'      => $form,
            'characters'=> $result,
            'total'     => $total,
        ));
    }
}