<?php

namespace LogBundle\Controller;

use LogBundle\Entity\Character;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use DateTime;
use DateInterval;
use DateTimeZone;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class ChatController extends Controller
{
    /**
     * @Route("/monitoring", name="gm_monitoring")
     * @Security("is_granted('ROLE_GM_MONITOR_CHAT_LOGS')")
     */
    public function commandsAction(Request $request)
    {
        $gmAccounts = $this->get('app.service.cache')->getGmAccounts();
        $realms = $this->getParameter('realms');
        $choices = [];
        foreach($gmAccounts as $account)
        {
            foreach($account->getCharacters() as $key => $character)
            {
                if($character->getRealm() > 9)
                    continue;
                if($key == 0)
                    $choices[$account->getUsername()]['Account'] = '0'.$account->getId();
                $choices[$account->getUsername()][$character->getName().' - '.$realms[$character->getRealm()]['name']] = $character->getRealm().$character->getGuid();
            }
        }
        $formRealms = [];
        foreach($realms as $realmId => $realm)
            $formRealms[$realm['name']] = $realmId;
        $yesterday = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $form = $this->createFormBuilder()
            ->setMethod('GET')
            ->add('gm', ChoiceType::class, array(
                'choices'   => $choices,
                'required'  => false,
            ))
            ->add('realms', ChoiceType::class, array(
                'required'  => false,
                'choices' => $formRealms))
            ->add('characters', TextType::class, array(
                'required'  => false,
            ))
            ->add('start', DateTimeType::class, array(
                'data' => $yesterday->modify('-1 hour')))
            ->add('end', DateTimeType::class, array(
                'data' => new \DateTime("now", new DateTimeZone('Europe/Paris'))))
            ->add('search', SubmitType::class)
            ->getForm();


        $form->handleRequest($request);

        $realm = NULL;
        $logs = [];
        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $realm = $data['realms'];
            $con    = NULL;
            $guid   = NULL;
            $name   = NULL;

            if($data['gm'] != '' && $data['realms'] == '' && $data['characters'] == '')
            {
                $con = substr($data['gm'], 0, 1);
                $guid = substr($data['gm'], 1);
            }
            elseif($data['gm'] == '' && $data['realms'] == '' && $data['characters'] != '')
            {
                $con = 1; // Default Nostalrius PvP
            }
            elseif($data['gm'] == '' && $data['realms'] != '' && $data['characters'] != '')
            {
                $con = $data['realms'];
                $name = $data['characters'];
            }

            $logs = [];
            // Account wide
            if($con == 0)
            {
                $realms = $this->getParameter('realms');
                foreach($gmAccounts as $account)
                {
                    if($account->getId() != $guid)
                        continue;

                    $guids = [];
                    foreach($account->getCharacters() as $character)
                        $guids[$character->getRealm()][] = $character->getGuid();

                    foreach($guids as $realm => $guid)
                    {
                        if($realm > 9)
                            continue;
                        $sql = 'SELECT
                                    chat.time, chat.type, chat.guid, chat.target, chat.channelId, chat.channelName, chat.message,
                                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.guid ORDER BY time DESC LIMIT 1) as guidName,
                                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.target ORDER BY time DESC LIMIT 1) as targetName
                                FROM logs_chat as chat
                                WHERE (time BETWEEN :start AND :end) AND (chat.guid IN (:guid) OR chat.target IN (:guid))
                                ORDER BY chat.time DESC';
                        $query = $this->getDoctrine()->getManager("log{$realm}")->getConnection()->prepare($sql);
                        $query->execute(array('guid' => implode(',',$guid),
                                              'start' => $data['start']->format('Y-m-d H:i:s'),
                                              'end'   => $data['end']->format('Y-m-d H:i:s')));
                        $logs[$realms[$realm]['name']] = $query->fetchAll();
                    }
                }
            }
            else
            {
                if($name != NULL)
                {
                    $sql = 'SELECT guid FROM logs_characters WHERE name = :name ORDER BY time DESC LIMIT 1';
                    $query = $this->getDoctrine()->getManager("log{$con}")->getConnection()->prepare($sql);
                    $query->execute(array('name' => $name));
                    $character = $query->fetch();
                    if($character == NULL)
                    {
                        $this->addFlash('danger','The character was not found');
                        return $this->render('gm/monitor/chat_logs.html.twig', array(
                            'form'      => $form->createView(),
                            'accounts'  => $gmAccounts,
                            'logs'      => $logs,
                        ));
                    }
                }
                if($guid != NULL)
                {
                    $sql = 'SELECT guid FROM logs_characters WHERE guid = :guid ORDER BY time DESC LIMIT 1';
                    $query = $this->getDoctrine()->getManager("log{$con}")->getConnection()->prepare($sql);
                    $query->execute(array('guid' => $guid));
                    $character = $query->fetch();
                    if($character == NULL)
                    {
                        $this->addFlash('danger','The character was not found');
                        return $this->render('gm/monitor/chat_logs.html.twig', array(
                            'form'      => $form->createView(),
                            'accounts'  => $gmAccounts,
                            'logs'      => $logs,
                        ));
                    }
                }

                $sql = 'SELECT
                        chat.time, chat.type, chat.guid, chat.target, chat.channelId, chat.channelName, chat.message,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.guid ORDER BY time DESC LIMIT 1) as guidName,
                        (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.target ORDER BY time DESC LIMIT 1) as targetName
                    FROM logs_chat as chat
                    WHERE (time BETWEEN :start AND :end) AND (chat.guid = :guid OR chat.target = :guid)
                    ORDER BY chat.time DESC';
                $query = $this->getDoctrine()->getManager("log{$con}")->getConnection()->prepare($sql);
                $query->execute(array(
                    'guid' => $character['guid'],
                    'start' => $data['start']->format('Y-m-d H:i:s'),
                    'end'   => $data['end']->format('Y-m-d H:i:s')));
                $logs = $query->fetchAll();
            }
        }

        return $this->render('gm/monitor/chat_logs.html.twig', array(
            'form'      => $form->createView(),
            'accounts'  => $gmAccounts,
            'logs'      => $logs,
            'realm'     => $realm,
        ));
    }

    /**
     * @Route("/monitoring/live", name="gm_monitoring_live")
     * @Security("is_granted('ROLE_GM_MONITOR_CHAT_LIVE')")
     */
    public function commandsLiveAction(Request $request)
    {
        $formRealms = [];
        foreach($this->getParameter('realms') as $realmId => $realm)
            $formRealms[$realm['name']] = $realmId;
        $form = $this->createFormBuilder()
            ->add('realms', ChoiceType::class, array(
                'choices' => $formRealms))
            ->add('characters', TextType::class)
            ->add('monitor', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $data = $form->getData();
            $sql = 'SELECT guid FROM logs_characters WHERE name = :name ORDER BY time DESC LIMIT 1';
            $query = $this->getDoctrine()->getManager("log{$data['realms']}")->getConnection()->prepare($sql);
            $query->execute(array('name'  => $data['characters']));
            $character = $query->fetch();
            if(!$character)
            {
                $this->addFlash('danger',"The character named '{$data['characters']}' was not found.");
                return $this->render('gm/monitor/live.html.twig', array('form' => $form->createView(),));
            }
            else
                return $this->redirectToRoute('gm_monitoring_character_live', array('realm' => $data['realms'], 'guid' => $character['guid']));
        }
        return $this->render('gm/monitor/live.html.twig', array('form' => $form->createView(),));
    }

    /**
     * @Route("/monitoring/{realm}/{guid}/live", name="gm_monitoring_character_live")
     * @Security("is_granted('ROLE_GM_MONITOR_CHAT_LIVE')")
     */
    public function commandsCharacterLiveAction(Request $request, $realm, $guid)
    {
        $now = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $earlier = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $earlier = $earlier->modify('-15 minutes');

        $sql = 'SELECT guid, name FROM logs_characters WHERE guid = :guid ORDER BY time DESC LIMIT 1';
        $query = $this->getDoctrine()->getManager("log{$realm}")->getConnection()->prepare($sql);
        $query->execute(array('guid'  => $guid));
        $character = $query->fetch();
        if(!$character)
        {
            $this->addFlash('danger',"Character #{$guid} does not exist.");
            return $this->render('gm/monitor/live_stream.html.twig');
        }

        $sql = 'SELECT
                    chat.time, chat.type, chat.guid, chat.target, chat.channelId, chat.channelName, chat.message,
                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.guid ORDER BY time DESC LIMIT 1) as guidName,
                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.target ORDER BY time DESC LIMIT 1) as targetName
                FROM logs_chat as chat
                WHERE (time BETWEEN :start AND :end) AND (chat.guid = :guid OR chat.target = :guid)';
        $query = $this->getDoctrine()->getManager("log{$realm}")->getConnection()->prepare($sql);
        $query->execute(array(
            'guid'  => $guid,
            'start' => $earlier->format('Y-m-d H:i:s'),
            'end'   => $now->format('Y-m-d H:i:s')));
        $messages = $query->fetchAll();

        return $this->render('gm/monitor/live_stream.html.twig', array(
            'character' => $character,
            'messages'  => $messages,
        ));
    }

    /**
     * @Route("/monitoring/{realm}/{guid}/live/{date}", name="gm_monitoring_live_stream")
     * @Security("is_granted('ROLE_GM_MONITOR_CHAT_LIVE')")
     */
    public function commandsLiveStreamAction(Request $request, $realm, $guid, $date)
    {
        $now = new \DateTime("now", new DateTimeZone('Europe/Paris'));
        $earlier = new \DateTime($date);
        $earlier = $earlier->modify('+1 second');

        $sql = 'SELECT
                    chat.time, chat.type, chat.guid, chat.target, chat.channelId, chat.channelName, chat.message,
                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.guid ORDER BY time DESC LIMIT 1) as guidName,
                    (SELECT name FROM logs_characters as ch WHERE ch.guid = chat.target ORDER BY time DESC LIMIT 1) as targetName
                FROM logs_chat as chat
                WHERE (time BETWEEN :start AND :end) AND (chat.guid = :guid OR chat.target = :guid)';
        $query = $this->getDoctrine()->getManager("log{$realm}")->getConnection()->prepare($sql);
        $query->execute(array(
            'guid'  => $guid,
            'start' => $earlier->format('Y-m-d H:i:s'),
            'end'   => $now->format('Y-m-d H:i:s')));
        $messages = $query->fetchAll();

        $json = new JsonResponse();
        return $json->setData($messages);
    }
}