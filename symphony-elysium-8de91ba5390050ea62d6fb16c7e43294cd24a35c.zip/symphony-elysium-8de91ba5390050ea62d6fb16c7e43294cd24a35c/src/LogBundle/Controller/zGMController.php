<?php

namespace LogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use DateTime;
use DateTimeZone;

class zGMController extends Controller
{
    /**
     * Verify that the realm name given corresponds to a realm.
     *
     * @param $realms
     * @param $name
     * @return mixed
     */
    private function verifyRealm($realms, $name)
    {
        $ok = false;
        foreach($realms as $rlm)
        {
            if($rlm->getName() == $name && $rlm->getId() < 10)
            {
                $realm = $rlm;
                $ok = true;
                break;
            }
        }
        if($ok === false)
            throw $this->createNotFoundException('Realm not found');
        return $realm;
    }

    /**
     * @Route("/armory/{realm}", name="gm_armory")
     * @Security("is_granted('ROLE_GM_ARMORY')")
     */
    public function armoryRealmAction(Request $request, $realm)
    {
        $redis = $this->get('snc_redis.default');
        $realm = $this->verifyRealm(unserialize($redis->get('web:realms')), $realm);

        $gmAccounts = $this->get('app.service.cache')->getGmAccounts();

        return $this->render('gm/armory/realm.html.twig', array(
            'realm'     => $realm,
            'accounts'  => $gmAccounts,
        ));
    }

    /**
     * @Route("/armory/{realm}/{character}", name="gm_armory_character")
     * @Security("is_granted('ROLE_GM_ARMORY')")
     */
    public function armoryCharacterAction(Request $request, $realm, $character)
    {
        $redis = $this->get('snc_redis.default');
        $realm = $this->verifyRealm(unserialize($redis->get('web:realms')), $realm);

        if(!preg_match('$([a-zA-Z]+)$', $character) || strlen($character) > 12)
            throw $this->createNotFoundException('Character name must be less than 12 alpha(A-z) characters.');

        $character = $this->getDoctrine()->getRepository('CharacterBundle:Characters',"realm{$realm->getId()}")->findOneByName($character);
        if(!$character)
            throw $this->createNotFoundException('This character does not exist.');

        $now = new \DateTime("now", new DateTimeZone('Europe/Paris'));

        // Sanctions
        $before = new \DateTime("now", new DateTimeZone('Europe/Paris'));

        $formSanctions = $this->createFormBuilder()
            ->add('sanction_start', DateTimeType::class, array(
                'data' => $before->modify('-1 day')))
            ->add('sanction_end', DateTimeType::class, array(
                'data' => $now))
            ->add('sanction_search', SubmitType::class)
            ->getForm();

        $formSanctions->handleRequest($request);

        if ($formSanctions->isSubmitted() && $formSanctions->isValid())
        {
            $data = $formSanctions->getData();
            $sanctions = $this->get('auth.service')->getSanctionsByGmBetween($realm->getId(), $character->getName(), $data['sanction_start'], $data['sanction_end']);
        }
        else
            $sanctions = $this->get('auth.service')->getSanctionsByGm($realm->getId(), $character->getName());

        // Chat
        $before = new \DateTime("now", new DateTimeZone('Europe/Paris'));

        $formChat = $this->createFormBuilder()
            ->add('chat_start', DateTimeType::class, array(
                'data' => $before->modify('-1 hour')))
            ->add('chat_end', DateTimeType::class, array(
                'data' => $now))
            ->add('chat_search', SubmitType::class)
            ->getForm();

        $formChat->handleRequest($request);

        if ($formChat->isSubmitted() && $formChat->isValid())
        {
            $data = $formChat->getData();
            $chat = $this->get('log.service')->getChatBetween($realm->getId(), $character->getGuid(), $data['chat_start'], $data['chat_end']);
        }
        else
           $chat = $this->get('log.service')->getChatBetween($realm->getId(), $character->getGuid(), $before, $now);

        return $this->render('gm/armory/character.html.twig', array(
            'realm'     => $realm,
            'character' => $character,
            'sanctions' => $sanctions,
            'chat'      => $chat,
            'formSanctions' => $formSanctions->createView(),
            'formChat'      => $formChat->createView(),
        ));
    }
}