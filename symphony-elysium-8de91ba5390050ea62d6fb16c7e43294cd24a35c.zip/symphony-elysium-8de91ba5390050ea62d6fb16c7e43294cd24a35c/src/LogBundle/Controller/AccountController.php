<?php

namespace LogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class AccountController extends Controller
{
    /**
     * @Route("/account", name="gm_accounts")
     * @Security("is_granted('ROLE_GM_ACCOUNT')")
     */
    public function accountAction(Request $request)
    {
        return $this->render('gm/account/index.html.twig');
    }

    /**
     * @Route("/account/{username}", name="gm_account")
     * @Security("is_granted('ROLE_GM_ACCOUNT')")
     */
    public function accountInfoAction(Request $request, $username)
    {
        if(!preg_match('$([a-zA-Z0-9]+)$', $username) || strlen($username) > 16)
            throw $this->createNotFoundException('Account username must be less than 16 alphanumeric characters.');

        $account = $this->getDoctrine()->getRepository('AuthBundle:Account', 'auth')->getAccountInfo($username);
        if(!$account)
        {
            $this->addFlash('danger','No account found.');
            return $this->redirectToRoute('gm_accounts');
        }

        $characters = $this->get('character.service')->getAccountCharacters($account[0]['Account']->getId(), false, null, true);

        return $this->render('gm/account/account.html.twig', array(
            'account'       => $account,
            'characters'    => $characters,
        ));
    }
}