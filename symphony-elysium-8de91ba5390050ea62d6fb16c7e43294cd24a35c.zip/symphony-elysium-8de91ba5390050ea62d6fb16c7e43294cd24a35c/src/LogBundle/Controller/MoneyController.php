<?php

namespace LogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class MoneyController extends Controller
{
    /**
     * @Route("/top-gold", name="gm_top_gold")
     * @Security("is_granted('ROLE_GM_TOP_GOLD')")
     */
    public function accountAction(Request $request)
    {
        return $this->render('gm/money/index.html.twig', array(
            'characters' => $this->get('character.service')->getTop100Rich()
        ));
    }
}