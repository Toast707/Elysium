<?php

namespace LogBundle\Controller;

use LogBundle\Entity\Character;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Serializer\Serializer;
use DateTimeZone;
use DateTime;

class DashboardController extends Controller
{
    /**
     * @Route("/", name="gm_dashboard")
     * @Security("is_granted('ROLE_GM_DASHBOARD')")
     */
    public function dashboardAction(Request $request)
    {
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, array(new JsonEncoder()));
        $redis = $this->get('snc_redis.default');
        $realms = $this->getParameter('realms');
        $gmAccounts = $this->get('app.service.cache')->getGmAccounts();
        $onlineGmCharacters = [];
        $guids = [];
        foreach($gmAccounts as $account)
        {
            foreach($account->getCharacters() as $character)
            {
                if($character->getRealm() > 9)
                    continue;
                $guids[] = $character->getGuid();
                if($character->isOnline())
                {
                    $character->setRank($account->getRank());
                    $onlineGmCharacters[$character->getRealm()][] = $character;
                }
            }
        }

        $bans = [];
        foreach($realms as $realmId => $realm)
        {
            $bans[$realmId] = $redis->get("web:gm_bans_{$realmId}");
            if(!isset($bans[$realmId]))
            {
                $end    = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
                $start  = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
                $start  = $start->modify('-1 day');
                $bans[$realmId] = $this->getDoctrine()->getRepository('AuthBundle:AccountBanned', 'auth')->findByTimeBetween($start, $end, $realmId);
                $redis->set("web:gm_bans_{$realmId}", serialize($bans[$realmId]));
                $redis->expire("web:gm_bans_{$realmId}", 300);
                $redis->ttl("web:gm_bans_{$realmId}");
            }
            else
                $bans[$realmId] = unserialize($bans[$realmId]);
        }

        $tickets = $this->get('character.service')->getOpenTicketsCount();

        return $this->render('gm/index.html.twig', array(
            'bans'      => $bans,
            'tickets'   => $tickets,
            'onlineGms' => $onlineGmCharacters,
        ));
    }

    /**
     * @Route("/ban/{realm}/{gm}", name="gm_ban")
     * @Security("is_granted('ROLE_GM_DASHBOARD')")
     */
    public function dashboardBanAction(Request $request, $gm, $realm)
    {
        $redis = $this->get('snc_redis.default');
        $bans = $redis->get("web:gm_ban_{$realm}_{$gm}");
        if(!$bans)
        {
            $end    = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
            $start  = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
            $start  = $start->modify('-1 day');
            $bans   = $this->getDoctrine()->getRepository('AuthBundle:AccountBanned', 'auth')->findByGmBetween($gm, $start, $end, $realm, 7);
            foreach($bans as $key => $ban)
            {
                $bans[$key]['bandate'] = gmdate("Y-m-d H:i:s", $ban['bandate']);
                $bans[$key]['unbandate'] = gmdate("Y-m-d H:i:s", $ban['unbandate']);
            }
            $redis->set("web:gm_ban_{$realm}_{$gm}", serialize($bans));
            $redis->expire("web:gm_ban_{$realm}_{$gm}", 300);
            $redis->ttl("web:gm_ban_{$realm}_{$gm}");
        }
        else
            $bans = unserialize($bans);
        return new JsonResponse(json_encode($bans));
    }
}