<?php

namespace LogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LogBundle extends Bundle
{
}
