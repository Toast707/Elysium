<?php

namespace AuthBundle\Security\Authentication\Encoder;

use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Encoder\BasePasswordEncoder;

/**
 * Class AuthBundlePasswordEncoder
 * @package AuthBundle\Security\Authentication\Encoder
 */
class AuthBundlePasswordEncoder extends BasePasswordEncoder
{
    const MAX_PASSWORD_LENGTH = 16;

    private $algorithm;
    private $encodeHashAsBase64;
    private $iterations;

    /**
     * Constructor.
     *
     * @param string $algorithm          The digest algorithm to use
     * @param bool   $encodeHashAsBase64 Whether to base64 encode the password hash
     * @param int    $iterations         The number of iterations to use to stretch the password hash
     */
    public function __construct($algorithm = 'sha1', $encodeHashAsBase64 = false, $iterations = 1)
    {
        $this->algorithm = 'sha1';
        $this->encodeHashAsBase64 = false;
        $this->iterations = 1;
    }
    /**
     * {@inheritdoc}
     */
    public function encodePassword($raw, $salt)
    {
        if ($this->isPasswordTooLong($raw))
            throw new BadCredentialsException('Invalid password.');

        if (!in_array($this->algorithm, hash_algos(), true))
            throw new \LogicException(sprintf('The algorithm "%s" is not supported.', $this->algorithm));

        $salted = $this->mergePasswordAndSalt($raw, $salt);
        $digest = hash($this->algorithm, $salted, true);

        return strtoupper(bin2hex($digest));
    }

    /**
     * {@inheritdoc}
     */
    protected function mergePasswordAndSalt($password, $salt)
    {
        if (empty($salt))
            throw new BadCredentialsException('Bad credentials.');

        return strtoupper("{$salt}:{$password}");
    }

    /**
     * {@inheritdoc}
     */
    public function isPasswordValid($encoded, $raw, $salt)
    {
        return !$this->isPasswordTooLong($raw) && $this->comparePasswords($encoded, $this->encodePassword($raw, $salt));
    }

    /**
     * Checks if the password is too long.
     *
     * @param string $password The password to check
     *
     * @return bool true if the password is too long, false otherwise
     */
    protected function isPasswordTooLong($password)
    {
        return strlen($password) > static::MAX_PASSWORD_LENGTH;
    }
}