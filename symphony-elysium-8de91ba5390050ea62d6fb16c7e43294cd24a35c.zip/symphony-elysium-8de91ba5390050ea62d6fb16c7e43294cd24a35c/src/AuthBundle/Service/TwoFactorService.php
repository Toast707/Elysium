<?php

namespace AuthBundle\Service;

use Scheb\TwoFactorBundle\Model\Google\TwoFactorInterface;
use Scheb\TwoFactorBundle\Security\TwoFactor\AuthenticationContextInterface;
use Scheb\TwoFactorBundle\Security\TwoFactor\Provider\Google\Validation\CodeValidatorInterface;
use Scheb\TwoFactorBundle\Security\TwoFactor\Provider\TwoFactorProviderInterface;
use Scheb\TwoFactorBundle\Security\TwoFactor\Renderer;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

class TwoFactorService implements TwoFactorProviderInterface
{
    /**
     * @var CodeValidatorInterface
     */
    private $authenticator;

    /**
     * @var Renderer
     */
    private $renderer;

    /**
     * @var string
     */
    private $authCodeParameter;

    public function __construct(CodeValidatorInterface $authenticator, Renderer $renderer, $authCodeParameter)
    {
        $this->authenticator = $authenticator;
        $this->renderer = $renderer;
        $this->authCodeParameter = $authCodeParameter;
    }

    /**
     * @param \Scheb\TwoFactorBundle\Security\TwoFactor\AuthenticationContextInterface $context
     * @return boolean
     */
    public function beginAuthentication(AuthenticationContextInterface $context)
    {
        $user = $context->getUser();

        if($user->getLocked() == 5 && $user->getLastIp() != $context->getRequest()->getClientIp())
            return true;
        elseif($user->getLocked() == 12)
            return true;
        else
            return false;
    }

    /**
     * @param \Scheb\TwoFactorBundle\Security\TwoFactor\AuthenticationContextInterface $context
     * @return \Symfony\Component\HttpFoundation\Response|null
     */
    public function requestAuthenticationCode(AuthenticationContextInterface $context)
    {
        $user = $context->getUser();
        $request = $context->getRequest();
        $session = $context->getSession();
        // Display and process form
        $authCode = $request->get($this->authCodeParameter);
        if ($authCode !== null) {
            if ($this->authenticator->checkCode($user, $authCode)) {
                $context->setAuthenticated(true);
                return new RedirectResponse($request->getUri());
            }
            $session->getFlashBag()->set('two_factor', 'scheb_two_factor.code_invalid');
        }
        // Force authentication code dialog
        return $this->renderer->render($context);
    }
}