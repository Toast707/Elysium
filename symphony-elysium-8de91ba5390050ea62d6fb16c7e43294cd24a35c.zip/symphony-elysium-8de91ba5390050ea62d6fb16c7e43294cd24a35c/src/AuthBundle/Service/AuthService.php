<?php

namespace AuthBundle\Service;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Serializer;

class AuthService
{
    private $redis;
    private $em;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->redis     = $container->get('snc_redis.default');
        $this->em        = $container->get('doctrine');
    }

    /**
     * Get the sanctions by game master
     *
     * @param      $realm
     * @param      $character
     * @param null $limit
     * @return mixed
     */
    public function getSanctionsByGm($realm, $character, $limit = null)
    {
        $sanctions = $this->redis->get("web:gm_ban_{$realm}_{$character}");
        if(!$sanctions)
        {
            $start  = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
            $start  = $start->modify('-1 day');
            $end    = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
            $sanctions = $this->em->getRepository('AuthBundle:AccountBanned', 'auth')->findByGmBetween($character, $start, $end, $realm, $limit);
            foreach($sanctions as $key => $sanction)
            {
                $sanctions[$key]['bandate'] = gmdate("Y-m-d H:i:s", $sanction['bandate']);
                $sanctions[$key]['unbandate'] = gmdate("Y-m-d H:i:s", $sanction['unbandate']);
            }
            $this->redis->set("web:gm_ban_{$realm}_{$character}", serialize($sanctions));
            $this->redis->expire("web:gm_ban_{$realm}_{$character}", 0);
            $this->redis->ttl("web:gm_ban_{$realm}_{$character}");
        }
        else
            $sanctions = unserialize($sanctions);
        return $sanctions;
    }

    /**
     * Get the sanctions by game master between two dates
     *
     * @param      $realm
     * @param      $character
     * @param null $start
     * @param null $end
     * @return mixed
     */
    public function getSanctionsByGmBetween($realm, $character, $start = null, $end = null)
    {
        if(!$start && !$end)
            return $this->getSanctionsByGm($realm, $character);

        if(!$start)
        {
            $start = new \DateTime("now", new \DateTimeZone('Europe/Paris'));
            $start = $start->modify('-1 day');
        }
        if(!$end)
            $end = new \DateTime("now", new \DateTimeZone('Europe/Paris'));

        $sanctions = $this->em->getRepository('AuthBundle:AccountBanned', 'auth')->findByGmBetween($character, $start, $end, $realm);
        foreach($sanctions as $sanction)
        {
            $sanction->setBandate(gmdate("Y-m-d H:i:s", $sanction->getBanDate()));
            $sanction->setUnbandate(gmdate("Y-m-d H:i:s", $sanction->getUnbanDate()));
        }
        return $sanctions;
    }

}