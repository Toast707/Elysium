<?php

namespace AuthBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RbacAccountPermissions
 *
 * @ORM\Table(name="rbac_account_permissions", indexes={@ORM\Index(name="fk__rbac_account_roles__rbac_permissions", columns={"permissionId"}), @ORM\Index(name="IDX_F5EF068362DEB3E8", columns={"accountId"})})
 * @ORM\Entity
 */
class RbacAccountPermissions
{
    /**
     * @var integer
     *
     * @ORM\Column(name="realmId", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $realmid = '-1';

    /**
     * @var boolean
     *
     * @ORM\Column(name="granted", type="boolean", nullable=false)
     */
    protected $granted = '1';

    /**
     * @var \AuthBundle\Entity\Account
     *
     * @ORM\OneToOne(targetEntity="AuthBundle\Entity\Account")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="accountId", referencedColumnName="id", unique=true)
     * })
     */
    protected $accountid;

    /**
     * @var \AuthBundle\Entity\RbacPermissions
     *
     * @ORM\OneToOne(targetEntity="AuthBundle\Entity\RbacPermissions")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="permissionId", referencedColumnName="id", unique=true)
     * })
     */
    protected $permissionid;



    /**
     * Set realmid
     *
     * @param integer $realmid
     *
     * @return RbacAccountPermissions
     */
    public function setRealmid($realmid)
    {
        $this->realmid = $realmid;

        return $this;
    }

    /**
     * Get realmid
     *
     * @return integer
     */
    public function getRealmid()
    {
        return $this->realmid;
    }

    /**
     * Set granted
     *
     * @param boolean $granted
     *
     * @return RbacAccountPermissions
     */
    public function setGranted($granted)
    {
        $this->granted = $granted;

        return $this;
    }

    /**
     * Get granted
     *
     * @return boolean
     */
    public function getGranted()
    {
        return $this->granted;
    }

    /**
     * Set accountid
     *
     * @param \AuthBundle\Entity\Account $accountid
     *
     * @return RbacAccountPermissions
     */
    public function setAccountid(\AuthBundle\Entity\Account $accountid = null)
    {
        $this->accountid = $accountid;

        return $this;
    }

    /**
     * Get accountid
     *
     * @return \AuthBundle\Entity\Account
     */
    public function getAccountid()
    {
        return $this->accountid;
    }

    /**
     * Set permissionid
     *
     * @param \AuthBundle\Entity\RbacPermissions $permissionid
     *
     * @return RbacAccountPermissions
     */
    public function setPermissionid(\AuthBundle\Entity\RbacPermissions $permissionid = null)
    {
        $this->permissionid = $permissionid;

        return $this;
    }

    /**
     * Get permissionid
     *
     * @return \AuthBundle\Entity\RbacPermissions
     */
    public function getPermissionid()
    {
        return $this->permissionid;
    }
}
