<?php

namespace AuthBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AccountCredits
 *
 * @ORM\Table(name="account_credits")
 * @ORM\Entity
 */
class AccountCredits
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="amount", type="integer", nullable=false)
     */
    protected $amount = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="last_update", type="bigint", nullable=false)
     */
    protected $lastUpdate = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="from", type="string", length=16, nullable=false)
     */
    protected $from = 'Shop';



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set amount
     *
     * @param integer $amount
     *
     * @return AccountCredits
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return integer
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set lastUpdate
     *
     * @param integer $lastUpdate
     *
     * @return AccountCredits
     */
    public function setLastUpdate($lastUpdate)
    {
        $this->lastUpdate = $lastUpdate;

        return $this;
    }

    /**
     * Get lastUpdate
     *
     * @return integer
     */
    public function getLastUpdate()
    {
        return $this->lastUpdate;
    }

    /**
     * Set from
     *
     * @param string $from
     *
     * @return AccountCredits
     */
    public function setFrom($from)
    {
        $this->from = $from;

        return $this;
    }

    /**
     * Get from
     *
     * @return string
     */
    public function getFrom()
    {
        return $this->from;
    }
}
