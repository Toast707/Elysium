<?php

namespace AuthBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AccountBanned
 *
 * @ORM\Table(name="account_banned")
 * @ORM\Entity(repositoryClass="AuthBundle\Repository\AccountBannedRepository")
 */
class AccountBanned implements \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $id = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="bandate", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $bandate = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="unbandate", type="integer", nullable=false)
     */
    protected $unbandate = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="bannedby", type="string", length=50, nullable=false)
     */
    protected $bannedby;

    /**
     * @var string
     *
     * @ORM\Column(name="banreason", type="string", length=255, nullable=false)
     */
    protected $banreason;

    /**
     * @var boolean
     *
     * @ORM\Column(name="active", type="boolean", nullable=false)
     */
    protected $active = 1;

    /**
     * @var integer
     *
     * @ORM\Column(name="realm", type="integer", nullable=false)
     */
    protected $realm = 1;

    /**
     * @var integer
     *
     * @ORM\Column(name="gmlevel", type="integer", nullable=false)
     */
    protected $gmlevel = 0;



    /**
     * Set id
     *
     * @param integer $id
     *
     * @return AccountBanned
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set bandate
     *
     * @param integer $bandate
     *
     * @return AccountBanned
     */
    public function setBandate($bandate)
    {
        $this->bandate = $bandate;

        return $this;
    }

    /**
     * Get bandate
     *
     * @return integer
     */
    public function getBandate()
    {
        return $this->bandate;
    }

    /**
     * Set unbandate
     *
     * @param integer $unbandate
     *
     * @return AccountBanned
     */
    public function setUnbandate($unbandate)
    {
        $this->unbandate = $unbandate;

        return $this;
    }

    /**
     * Get unbandate
     *
     * @return integer
     */
    public function getUnbandate()
    {
        return $this->unbandate;
    }

    /**
     * Set bannedby
     *
     * @param string $bannedby
     *
     * @return AccountBanned
     */
    public function setBannedby($bannedby)
    {
        $this->bannedby = $bannedby;

        return $this;
    }

    /**
     * Get bannedby
     *
     * @return string
     */
    public function getBannedby()
    {
        return $this->bannedby;
    }

    /**
     * Set banreason
     *
     * @param string $banreason
     *
     * @return AccountBanned
     */
    public function setBanreason($banreason)
    {
        $this->banreason = $banreason;

        return $this;
    }

    /**
     * Get banreason
     *
     * @return string
     */
    public function getBanreason()
    {
        return $this->banreason;
    }

    /**
     * Set active
     *
     * @param boolean $active
     *
     * @return AccountBanned
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return boolean
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * @return int
     */
    public function getRealm()
    {
        return $this->realm;
    }

    /**
     * @param int $realm
     */
    public function setRealm($realm)
    {
        $this->realm = $realm;
    }

    /**
     * @return int
     */
    public function getGmlevel()
    {
        return $this->gmlevel;
    }

    /**
     * @param int $gmlevel
     */
    public function setGmlevel($gmlevel)
    {
        $this->gmlevel = $gmlevel;
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->bandate,
            $this->unbandate,
            $this->bandate,
            $this->banreason,
            $this->realm,
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->bandate,
            $this->unbandate,
            $this->bandate,
            $this->banreason,
            $this->realm,
            ) = unserialize($serialized);
    }
}
