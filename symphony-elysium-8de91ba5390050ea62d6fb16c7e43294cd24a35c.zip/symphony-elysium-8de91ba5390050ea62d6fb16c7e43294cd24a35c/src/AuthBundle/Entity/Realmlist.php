<?php

namespace AuthBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Realmlist
 *
 * @ORM\Table(name="realmlist", uniqueConstraints={@ORM\UniqueConstraint(name="idx_name", columns={"name"})})
 * @ORM\Entity
 */
class Realmlist implements \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=32, nullable=false)
     */
    protected $name = '';

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255, nullable=false)
     */
    protected $address = '127.0.0.1';

    /**
     * @var integer
     *
     * @ORM\Column(name="port", type="smallint", nullable=false)
     */
    protected $port = 8085;

    /**
     * @var boolean
     *
     * @ORM\Column(name="icon", type="boolean", nullable=false)
     */
    protected $icon = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="realmflags", type="integer", nullable=false)
     */
    protected $realmFlags = 0;

    /**
     * @var boolean
     *
     * @ORM\Column(name="timezone", type="boolean", nullable=false)
     */
    protected $timezone = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="allowedSecurityLevel", type="integer", nullable=false)
     */
    protected $allowedSecurityLevel = 0;

    /**
     * @var float
     *
     * @ORM\Column(name="population", type="float", precision=10, scale=0, nullable=false)
     */
    protected $population = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="realmbuilds", type="string", length=64, nullable=false)
     */
    protected $realmBuilds = '8606';


    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param string $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     * @return int
     */
    public function getPort()
    {
        return $this->port;
    }

    /**
     * @param int $port
     */
    public function setPort($port)
    {
        $this->port = $port;
    }

    /**
     * @return boolean
     */
    public function isIcon()
    {
        return $this->icon;
    }

    /**
     * @param boolean $icon
     */
    public function setIcon($icon)
    {
        $this->icon = $icon;
    }

    /**
     * @return int
     */
    public function getRealmFlags()
    {
        return $this->realmFlags;
    }

    /**
     * @param int $realmFlags
     */
    public function setRealmFlags($realmFlags)
    {
        $this->realmFlags = $realmFlags;
    }

    /**
     * @return boolean
     */
    public function isTimezone()
    {
        return $this->timezone;
    }

    /**
     * @param boolean $timezone
     */
    public function setTimezone($timezone)
    {
        $this->timezone = $timezone;
    }

    /**
     * @return int
     */
    public function getAllowedSecurityLevel()
    {
        return $this->allowedSecurityLevel;
    }

    /**
     * @param int $allowedSecurityLevel
     */
    public function setAllowedSecurityLevel($allowedSecurityLevel)
    {
        $this->allowedSecurityLevel = $allowedSecurityLevel;
    }

    /**
     * @return float
     */
    public function getPopulation()
    {
        return $this->population;
    }

    /**
     * @param float $population
     */
    public function setPopulation($population)
    {
        $this->population = $population;
    }

    /**
     * @return string
     */
    public function getRealmBuilds()
    {
        return $this->realmBuilds;
    }

    /**
     * @param string $realmBuilds
     */
    public function setRealmBuilds($realmBuilds)
    {
        $this->realmBuilds = $realmBuilds;
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->name,
            $this->name,
            $this->address,
            $this->port,
            $this->icon,
            $this->realmFlags,
            $this->allowedSecurityLevel,
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->name,
            $this->name,
            $this->address,
            $this->port,
            $this->icon,
            $this->realmFlags,
            $this->allowedSecurityLevel,
            ) = unserialize($serialized);
    }
}
