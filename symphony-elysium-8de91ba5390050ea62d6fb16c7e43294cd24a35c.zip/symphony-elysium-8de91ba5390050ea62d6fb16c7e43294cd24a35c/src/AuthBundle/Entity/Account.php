<?php

namespace AuthBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\EquatableInterface;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Serializer\Annotation\Groups;
use Scheb\TwoFactorBundle\Model\Google\TwoFactorInterface;

/**
 * Account
 *
 * @ORM\Table(name="account", uniqueConstraints={@ORM\UniqueConstraint(name="idx_username", columns={"username"})})
 * @ORM\Entity(repositoryClass="AuthBundle\Repository\AccountRepository")
 * @UniqueEntity("username")
 * @UniqueEntity("email")
 */
class Account implements UserInterface, EquatableInterface, TwoFactorInterface, \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @Assert\NotNull(
     *      message = "You need to specify an username.",
     * )
     * @Assert\Regex(
     *     pattern = "/^[a-zA-Z0-9]+$/",
     *     message = "Your name can only contain alphanumeric characters."
     * )
     * @Assert\Length(
     *      min = 4,
     *      max = 16,
     *      minMessage = "Your username must be at least {{ limit }} characters long.",
     *      maxMessage = "Your username cannot be longer than {{ limit }} characters."
     * )
     * @ORM\Column(name="username", type="string", length=32, nullable=false, unique=true)
     */
    protected $username;

    /**
     * @var string
     *
     * @ORM\Column(name="sha_pass_hash", type="string", length=40, nullable=false)
     */
    protected $shaPassHash;

    /**
     * @var string
     *
     * @Assert\NotNull(
     *      message = "You need to specify a password.",
     * )
     * @Assert\Length(
     *      min = 6,
     *      max = 16,
     *      minMessage = "Your password must be at least {{ limit }} characters long.",
     *      maxMessage = "Your password cannot be longer than {{ limit }} characters."
     * )
     */
    protected $password;

    /**
     * @var text
     *
     * @Assert\NotNull(
     *      message = "You need to specify an email.",
     * )
     * @Assert\Email(
     *     message = "The email '{{ value }}' is not a valid email.",
     *     strict = true,
     *     checkMX = true
     * )
     * @ORM\Column(name="email", type="text", unique=true)
     */
    protected $email;

    /**
     * @var string
     */
    protected $salt;

    /**
     * @var string
     */
    protected $roles;

    /**
     * @var string
     *
     * @ORM\Column(name="sessionkey", type="string", length=80, nullable=false)
     */
    protected $sessionkey = '';

    /**
     * @var string
     *
     * @ORM\Column(name="v", type="string", length=64, nullable=false)
     */
    protected $v = '';

    /**
     * @var string
     *
     * @ORM\Column(name="s", type="string", length=64, nullable=false)
     */
    protected $s = '';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="joindate", type="datetime", nullable=false)
     */
    protected $joinDate;

    /**
     * @ORM\Column(name="security", type="string", nullable=true)
     */
    private $googleAuthenticatorSecret;

    /**
     * @ORM\Column(name="tfa_verif", type="string", nullable=true)
     */
    private $TFAVerif;

    /**
     * @var string
     *
     * @ORM\Column(name="last_ip", type="string", length=15, nullable=false)
     */
    protected $lastIp;

    /**
     * @var integer
     *
     * @ORM\Column(name="failed_logins", type="integer", nullable=false)
     */
    protected $failedLogins = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="locked", type="integer", length=3, nullable=false)
     */
    protected $locked = 0;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="last_login", type="datetime", nullable=false)
     */
    protected $lastLogin;

    /**
     * @var boolean
     *
     * @ORM\Column(name="online", type="boolean", nullable=false)
     */
    protected $online = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="expansion", type="integer", nullable=false)
     */
    protected $expansion = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="mutetime", type="bigint", nullable=false)
     */
    protected $mutetime = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="mutereason", type="string", length=255, nullable=false)
     */
    protected $mutereason = '';

    /**
     * @var string
     *
     * @ORM\Column(name="muteby", type="string", length=50, nullable=false)
     */
    protected $muteby = '';

    /**
     * @var integer
     *
     * @ORM\Column(name="locale", type="integer", nullable=false)
     */
    protected $locale = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="os", type="string", length=4, nullable=false)
     */
    protected $os = '';

    /**
     * @var integer
     *
     * @ORM\Column(name="current_realm", length=3, type="integer", nullable=false)
     */
    protected $currentRealm = 0;

    /**
     * @var boolean
     *
     * @ORM\Column(name="banned", type="boolean")
     */
    protected $banned = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="flags", length=10, type="integer", nullable=false)
     */
    protected $flags = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="pass_verif", length=255, type="string")
     */
    protected $passVerif;

    /**
     * @var string
     *
     * @ORM\Column(name="email_check", length=255, type="string")
     */
    protected $emailCheck;

    /**
     * @var boolean
     *
     * @ORM\Column(name="email_verif", length=1, type="boolean", nullable=false)
     */
    protected $emailVerif = 0;

    /**
     * @var text
     *
     * @ORM\Column(name="elysium_email", type="text")
     */
    protected $elysiumEmail;

    /**
     * @var text
     *
     * @ORM\Column(name="elysium_token", type="text")
     */
    protected $elysiumToken;

    /**
     * @var boolean
     *
     * @ORM\Column(name="elysium_token_enabled", length=1, type="boolean")
     */
    protected $elysiumTokenEnabled = 0;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nostalrius_token_enabled", length=1, type="boolean")
     */
    protected $nostalriusTokenEnabled = 0;

    /**
     * @var boolean
     *
     * @ORM\Column(name="nostalrius_recover", length=1, type="boolean")
     */
    protected $nostalriusRecover = 0;

    /**
     * @var text
     *
     * @ORM\Column(name="nostalrius_token", type="text")
     */
    protected $nostalriusToken;

    /**
     * @var text
     *
     * @ORM\Column(name="nostalrius_email", type="text")
     */
    protected $nostalriusEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="nostalrius_last_ip", type="string")
     */
    protected $nostalriusLastIp;

    /**
     * @var text
     *
     * @ORM\Column(name="nostalrius_reason", type="text")
     */
    protected $nostalriusReason;

    /**
     * @var bool
     *
     * @Assert\IsTrue(message = "You must validate the captcha.")
     */
    protected $recaptcha;

    /**
     * @var bool
     *
     * @Assert\IsTrue(message = "You must agree with the Terms of Use.")
     */
    protected $termsOfUse;

    /**
     * @var array
     */
    protected $characters;

    /**
     * @var integer
     */
    protected $rank = 0;


    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param string $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @return string
     */
    public function getShaPassHash()
    {
        return $this->shaPassHash;
    }

    /**
     * @param string $shaPassHash
     */
    public function setShaPassHash($shaPassHash)
    {
        $this->shaPassHash = $shaPassHash;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->shaPassHash;
    }

    /**
     * @return string
     */
    public function getRealPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @param string $salt
     */
    public function setSalt($salt)
    {
        $this->salt = $salt;
    }

    /**
     * @return string
     */
    public function getSalt()
    {
        return $this->salt;
    }

    /**
     * @param string $roles
     */
    public function setRoles($roles)
    {
        $this->roles[] = $roles;
    }

    /**
     * @return string
     */
    public function getRoles()
    {
        if(is_array($this->roles))
            return array_unique($this->roles);
        else
            return array('ROLE_USER');
    }

    /**
     * @return text
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param text $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getSessionkey()
    {
        return $this->sessionkey;
    }

    /**
     * @param string $sessionkey
     */
    public function setSessionkey($sessionkey)
    {
        $this->sessionkey = $sessionkey;
    }

    /**
     * @return string
     */
    public function getV()
    {
        return $this->v;
    }

    /**
     * @param string $v
     */
    public function setV($v)
    {
        $this->v = $v;
    }

    /**
     * @return string
     */
    public function getS()
    {
        return $this->s;
    }

    /**
     * @param string $s
     */
    public function setS($s)
    {
        $this->s = $s;
    }

    /**
     * @return mixed
     */
    public function getGoogleAuthenticatorSecret()
    {
        return $this->googleAuthenticatorSecret;
    }

    /**
     * @param int $googleAuthenticatorSecret
     */
    public function setGoogleAuthenticatorSecret($googleAuthenticatorSecret)
    {
        $this->googleAuthenticatorSecret = $googleAuthenticatorSecret;
    }

    /**
     * @return mixed
     */
    public function getTFAVerif()
    {
        return $this->TFAVerif;
    }

    /**
     * @param mixed $TFAVerif
     */
    public function setTFAVerif($TFAVerif)
    {
        $this->TFAVerif = $TFAVerif;
    }

    /**
     * @return \DateTime
     */
    public function getJoinDate()
    {
        return $this->joinDate;
    }

    /**
     * @param \DateTime $joinDate
     */
    public function setJoinDate($joinDate)
    {
        $this->joinDate = $joinDate;
    }

    /**
     * @return string
     */
    public function getLastIp()
    {
        return $this->lastIp;
    }

    /**
     * @param string $lastIp
     */
    public function setLastIp($lastIp)
    {
        $this->lastIp = $lastIp;
    }

    /**
     * @return int
     */
    public function getFailedLogins()
    {
        return $this->failedLogins;
    }

    /**
     * @param int $failedLogins
     */
    public function setFailedLogins($failedLogins)
    {
        $this->failedLogins = $failedLogins;
    }

    /**
     * @return integer
     */
    public function getLocked()
    {
        return $this->locked;
    }

    /**
     * @param integer $locked
     */
    public function setLocked($locked)
    {
        $this->locked = $locked;
    }

    /**
     * @return \DateTime
     */
    public function getLastLogin()
    {
        return $this->lastLogin;
    }

    /**
     * @param \DateTime $lastLogin
     */
    public function setLastLogin($lastLogin)
    {
        $this->lastLogin = $lastLogin;
    }

    /**
     * @return boolean
     */
    public function isOnline()
    {
        return $this->online;
    }

    /**
     * @param boolean $online
     */
    public function setOnline($online)
    {
        $this->online = $online;
    }

    /**
     * @return int
     */
    public function getExpansion()
    {
        return $this->expansion;
    }

    /**
     * @param int $expansion
     */
    public function setExpansion($expansion)
    {
        $this->expansion = $expansion;
    }

    /**
     * @return int
     */
    public function getMutetime()
    {
        return $this->mutetime;
    }

    /**
     * @param int $mutetime
     */
    public function setMutetime($mutetime)
    {
        $this->mutetime = $mutetime;
    }

    /**
     * @return string
     */
    public function getMutereason()
    {
        return $this->mutereason;
    }

    /**
     * @param string $mutereason
     */
    public function setMutereason($mutereason)
    {
        $this->mutereason = $mutereason;
    }

    /**
     * @return string
     */
    public function getMuteby()
    {
        return $this->muteby;
    }

    /**
     * @param string $muteby
     */
    public function setMuteby($muteby)
    {
        $this->muteby = $muteby;
    }

    /**
     * @return int
     */
    public function getLocale()
    {
        return $this->locale;
    }

    /**
     * @param int $locale
     */
    public function setLocale($locale)
    {
        $this->locale = $locale;
    }

    /**
     * @return string
     */
    public function getOs()
    {
        return $this->os;
    }

    /**
     * @param string $os
     */
    public function setOs($os)
    {
        $this->os = $os;
    }

    /**
     * @return int
     */
    public function getCurrentRealm()
    {
        return $this->currentRealm;
    }

    /**
     * @param int $currentRealm
     */
    public function setCurrentRealm($currentRealm)
    {
        $this->currentRealm = $currentRealm;
    }

    /**
     * @return boolean
     */
    public function isBanned()
    {
        return $this->banned;
    }

    /**
     * @param boolean $banned
     */
    public function setBanned($banned)
    {
        $this->banned = $banned;
    }

    /**
     * @return int
     */
    public function getFlags()
    {
        return $this->flags;
    }

    /**
     * @param int $flags
     */
    public function setFlags($flags)
    {
        $this->flags = $flags;
    }

    /**
     * @return string
     */
    public function getPassVerif()
    {
        return $this->passVerif;
    }

    /**
     * @param string $passVerif
     */
    public function setPassVerif($passVerif)
    {
        $this->passVerif = $passVerif;
    }

    /**
     * @return string
     */
    public function getEmailCheck()
    {
        return $this->emailCheck;
    }

    /**
     * @param string $emailCheck
     */
    public function setEmailCheck($emailCheck)
    {
        $this->emailCheck = $emailCheck;
    }

    /**
     * @return boolean
     */
    public function isEmailVerif()
    {
        return $this->emailVerif;
    }

    /**
     * @param boolean $emailVerif
     */
    public function setEmailVerif($emailVerif)
    {
        $this->emailVerif = $emailVerif;
    }

    /**
     * @return text
     */
    public function getElysiumEmail()
    {
        return $this->elysiumEmail;
    }

    /**
     * @param text $elysiumEmail
     */
    public function setElysiumEmail($elysiumEmail)
    {
        $this->elysiumEmail = $elysiumEmail;
    }

    /**
     * @return text
     */
    public function getElysiumToken()
    {
        return $this->elysiumToken;
    }

    /**
     * @param text $elysiumToken
     */
    public function setElysiumToken($elysiumToken)
    {
        $this->elysiumToken = $elysiumToken;
    }

    /**
     * @return boolean
     */
    public function isElysiumTokenEnabled()
    {
        return $this->elysiumTokenEnabled;
    }

    /**
     * @param boolean $elysiumTokenEnabled
     */
    public function setElysiumTokenEnabled($elysiumTokenEnabled)
    {
        $this->elysiumTokenEnabled = $elysiumTokenEnabled;
    }

    /**
     * @return boolean
     */
    public function isNostalriusTokenEnabled()
    {
        return $this->nostalriusTokenEnabled;
    }

    /**
     * @param boolean $nostalriusTokenEnabled
     */
    public function setNostalriusTokenEnabled($nostalriusTokenEnabled)
    {
        $this->nostalriusTokenEnabled = $nostalriusTokenEnabled;
    }

    /**
     * @return boolean
     */
    public function isNostalriusRecover()
    {
        return $this->nostalriusRecover;
    }

    /**
     * @param boolean $nostalriusRecover
     */
    public function setNostalriusRecover($nostalriusRecover)
    {
        $this->nostalriusRecover = $nostalriusRecover;
    }

    /**
     * @return text
     */
    public function getNostalriusToken()
    {
        return $this->nostalriusToken;
    }

    /**
     * @param text $nostalriusToken
     */
    public function setNostalriusToken($nostalriusToken)
    {
        $this->nostalriusToken = $nostalriusToken;
    }

    /**
     * @return text
     */
    public function getNostalriusEmail()
    {
        return $this->nostalriusEmail;
    }

    /**
     * @param text $nostalriusEmail
     */
    public function setNostalriusEmail($nostalriusEmail)
    {
        $this->nostalriusEmail = $nostalriusEmail;
    }

    /**
     * @return string
     */
    public function getNostalriusLastIp()
    {
        return $this->nostalriusLastIp;
    }

    /**
     * @param string $nostalriusLastIp
     */
    public function setNostalriusLastIp($nostalriusLastIp)
    {
        $this->nostalriusLastIp = $nostalriusLastIp;
    }

    /**
     * @return text
     */
    public function getNostalriusReason()
    {
        return $this->nostalriusReason;
    }

    /**
     * @param text $nostalriusReason
     */
    public function setNostalriusReason($nostalriusReason)
    {
        $this->nostalriusReason = $nostalriusReason;
    }

    /**
     * @return boolean
     */
    public function isRecaptcha()
    {
        return $this->recaptcha;
    }

    /**
     * @param boolean $recaptcha
     */
    public function setRecaptcha($recaptcha)
    {
        $this->recaptcha = $recaptcha;
    }

    /**
     * @return boolean
     */
    public function isTermsOfUse()
    {
        return $this->termsOfUse;
    }

    /**
     * @param boolean $termsOfUse
     */
    public function setTermsOfUse($termsOfUse)
    {
        $this->termsOfUse = $termsOfUse;
    }

    /**
     * @inheritdoc
     */
    public function eraseCredentials()
    {
        $this->password = NULL;
    }

    /**
     * @return array
     */
    public function getCharacters()
    {
        return $this->characters;
    }

    /**
     * @param array $characters
     */
    public function setCharacters($characters)
    {
        $this->characters = $characters;
    }

    /**
     * @return int
     */
    public function getRank()
    {
        return $this->rank;
    }

    /**
     * @param int $rank
     */
    public function setRank($rank)
    {
        $this->rank = $rank;
    }

    /**
     * @inheritdoc
     */
    public function isEqualTo(UserInterface $user)
    {
        return $this->id === $user->getId();
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->id,
            $this->username,
            $this->roles,
            $this->characters,
            $this->rank,
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->id,
            $this->username,
            $this->roles,
            $this->characters,
            $this->rank,
            ) = unserialize($serialized);
    }
}
