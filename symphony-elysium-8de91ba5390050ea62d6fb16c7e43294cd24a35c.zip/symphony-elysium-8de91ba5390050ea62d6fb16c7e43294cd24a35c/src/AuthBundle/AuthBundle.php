<?php

namespace AuthBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AuthBundle extends Bundle
{
}
