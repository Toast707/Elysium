<?php

namespace AuthBundle\Event\Subscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Security\Core\AuthenticationEvents;
use Symfony\Component\Security\Core\Event\AuthenticationFailureEvent;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\Matcher\RequestMatcherInterface;

class PreFail2Ban implements EventSubscriberInterface
{
    const MAX_LOGIN_FAILURE_ATTEMPTS = 3;

    private $request;
    private $router;
    private $redis;

    /**
     * @param RequestStack            $requestStack
     * @param RequestMatcherInterface $router
     * @param                         $redis
     */
    public function __construct(RequestStack $requestStack, RequestMatcherInterface $router, $redis)
    {
        $this->request = $requestStack->getCurrentRequest();
        $this->router = $router;
        $this->redis = $redis;
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return [
            AuthenticationEvents::AUTHENTICATION_FAILURE => 'onAuthenticationFailure',
            KernelEvents::REQUEST => ['beforeFirewall', 10]
        ];
    }

    /**
     * @param AuthenticationFailureEvent $event
     */
    public function onAuthenticationFailure(AuthenticationFailureEvent $event)
    {
        $ip = $this->request->getClientIp();
        $fail2ban = $this->redis->get("web:fail_{$this->request->getClientIp()}");
        if(!$fail2ban)
        {
            $fail2ban = 1;
            $this->redis->set("web:fail_{$ip}", $fail2ban);
            $this->redis->expire("web:fail_{$ip}", 3600);
            $this->redis->ttl("web:fail_{$ip}");
        }
        else
            $this->redis->incr("web:fail_{$this->request->getClientIp()}");
    }

    /**
     * @param GetResponseEvent $event
     */
    public function beforeFirewall(GetResponseEvent $event)
    {
        $request = $event->getRequest();
        if ($request->isMethod(Request::METHOD_POST))
        {
            $routeInfos = $this->router->matchRequest($request);
            if (isset($routeInfos['_route']) && $routeInfos['_route'] === 'control_panel')
            {
                $fail2ban = $this->redis->get("web:fail_{$request->getClientIp()}");

                if ($fail2ban && self::MAX_LOGIN_FAILURE_ATTEMPTS <= $fail2ban)
                {
                    throw new HttpException(
                        429,
                        'Too many failed authentication, please come back in an hour from now.'
                    );
                }
            }
        }
    }
}