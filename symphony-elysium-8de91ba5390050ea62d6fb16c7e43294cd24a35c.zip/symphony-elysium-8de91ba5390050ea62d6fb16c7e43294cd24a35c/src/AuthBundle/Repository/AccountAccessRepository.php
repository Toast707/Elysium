<?php

namespace AuthBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class AccountAccessRepository
 * @package AuthBundle\Repository
 */
class AccountAccessRepository extends EntityRepository
{
    /**
     * @param $gmLevel
     * @param $realmId
     * @return array
     */
    public function findBySuperiorGmLevel($gmLevel, $realmId)
    {
        return $qb = $this->createQueryBuilder('ac')
            ->where('ac.gmlevel > :gmLevel')
            ->setParameter('gmLevel', $gmLevel)
            ->andWhere('ac.realmid IN (:realmId)')
            ->setParameter('realmId', $realmId)
            ->getQuery()
            ->getResult();
    }

    /**
     * @return mixed
     */
    public function findGmAccounts()
    {
        return $this->createQueryBuilder('ac')
            ->select('ac')
            ->where('ac.gmlevel > 1')
            ->andWhere('ac.gmlevel < 6')
            ->getQuery()
            ->getResult();
    }
}