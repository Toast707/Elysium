<?php

namespace AuthBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class AccountBannedRepository
 * @package AuthBundle\Repository
 */
class AccountBannedRepository extends EntityRepository
{
    /**
     * @param $id
     * @return array
     */
    public function removeWebBan($id)
    {
        return $this->createQueryBuilder('ab')
            ->delete()
            ->where('ab.id = :id')
            ->setParameter('id', $id)
            ->andWhere('ab.bannedby = :web')
            ->setParameter('web', 'Web')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param $start
     * @param $end
     * @param $realm
     * @return array
     */
    public function findByTimeBetween($start, $end, $realm)
    {
        return $this->createQueryBuilder('ab')
            ->select('COUNT(ab) as BanCount, ab.bannedby, a.username')
            ->join('AuthBundle:Account', 'a', 'WITH', 'a.id = ab.id')
            ->where('ab.bannedby != :web')
            ->setParameter('web', 'Web')
            ->andWhere('ab.bandate BETWEEN :start AND :end')
            ->setParameter('start', $start->getTimestamp())
            ->setParameter('end', $end->getTimestamp())
            ->andWhere('ab.realm = :realm')
            ->setParameter('realm', $realm)
            ->groupBy('ab.bannedby')
            ->orderBy('BanCount', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param $gm
     * @param $start
     * @param $end
     * @param $realm
     * @param $limit
     * @return array
     */
    public function findByGmBetween($gm, $start, $end, $realm, $limit = null)
    {
        $query = $this->createQueryBuilder('ab')
            ->select('ab.id, a.username, ab.bandate, ab.unbandate, ab.banreason, ab.realm, ab.bannedby')
            ->join('AuthBundle:Account', 'a', 'WITH', 'a.id = ab.id')
            ->where('ab.bannedby = :gm')
            ->setParameter('gm', $gm)
            ->andWhere('ab.bandate BETWEEN :start AND :end')
            ->setParameter('start', $start->getTimestamp())
            ->setParameter('end', $end->getTimestamp())
            ->andWhere('ab.realm = :realm')
            ->setParameter('realm', $realm);

        if($limit)
            $query->setMaxResults($limit);

        return $query
            ->orderBy('ab.bandate', 'DESC')
            ->getQuery()
            ->getResult();
    }
}