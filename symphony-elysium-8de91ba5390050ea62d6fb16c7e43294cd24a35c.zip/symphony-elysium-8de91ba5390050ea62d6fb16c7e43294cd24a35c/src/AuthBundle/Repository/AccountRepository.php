<?php

namespace AuthBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Symfony\Bridge\Doctrine\Security\User\UserLoaderInterface;
use AuthBundle\Entity\AccountAccess;

/**
 * Class AccountRepository
 * @package AuthBundle\Repository
 */
class AccountRepository extends EntityRepository implements UserLoaderInterface
{
    /**
     * @return mixed
     */
    public function findGmAccounts()
    {
        $realms = array(-1,1);
        $result = $this->createQueryBuilder('a')
            ->select('a', 'aa.gmlevel')
            ->leftJoin('AuthBundle:AccountAccess', 'aa', 'WITH', 'aa.id = a.id')
            ->where('aa.gmlevel > 0')
            ->andWhere('aa.realmid IN(:realms)')
            ->setParameter('realms', $realms)
            ->getQuery()
            ->getResult();
        $accounts = [];
        foreach($result as $account)
        {
            $account[0]->setRank($account['gmlevel']);
            $accounts[] = $account[0];
        }
        return $accounts;
    }

    /**
     * @return mixed
     */
    public function countAccounts()
    {
        return $this->createQueryBuilder('a')
            ->select('COUNT(a)')
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @param $old
     * @param $new
     * @return mixed
     */
    public function updateId($old, $new)
    {
        return $this->createQueryBuilder('a')
            ->update('AuthBundle:Account', 'a')
            ->set('a.id', '?1')
            ->where('a.id = ?2')
            ->setParameter(1, $new)
            ->setParameter(2, $old)
            ->getQuery()
            ->execute();
    }

    /**
     * {@inheritDoc}
     */
    public function loadUserByUsername($username)
    {
        $account = $this->findOneByUsername(strtoupper($username));
        if($account)
        {
            $account->setSalt($account->getUsername());
            $accesses = $this->getEntityManager()->getRepository('AuthBundle:AccountAccess')->findById($account->getId());
            foreach($accesses as $access)
            {
                if($access instanceof AccountAccess)
                {
                    switch($access->getRealmid())
                    {
                        case -1:    $account->setRoles("ROLE_ADMIN"); break;
                        case 10:    $account->setRoles("ROLE_QA{$access->getGmlevel()}"); break;
                        case 11:    $account->setRoles("ROLE_QA{$access->getGmlevel()}"); break;
                        default:    $account->setRoles("ROLE_GM{$access->getGmlevel()}");
                    }
                }
                else
                    $account->setRoles('ROLE_USER');
            }
        }
        return $account;
    }


    public function getAccountInfo($username)
    {
        return $this->createQueryBuilder('a')
            ->select('a AS Account', 'ab AS Sanctions', 'aa AS Access')
            ->leftJoin('AuthBundle:AccountBanned', 'ab', 'WITH', 'a.id = ab.id')
            ->leftJoin('AuthBundle:AccountAccess', 'aa', 'WITH', 'a.id = aa.id')
            ->where('a.username = :username')
            ->setParameter('username', $username)
            ->getQuery()
            ->getResult();
    }
}