<?php

namespace CharacterBundle\Service;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

class CharacterService
{
    private $container;
    private $realms;
    private $redis;
    private $em;

    /**
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $this->realms   = $container->getParameter('realms');
        $this->redis    = $container->get('snc_redis.default');
        $this->em       = $container->get('doctrine');
    }

    /**
     * @param            $accountId
     * @param bool|false $qa
     * @param null       $options
     * @param bool|false $reorder
     * @return array
     */
    public function getAccountCharacters($accountId, $qa = false, $options = null, $reorder = false)
    {
        $managers = array_keys($this->em->getManagers());

        $result = [];
        foreach($managers as $key => $manager)
        {
            if(!preg_match('/^realm([0-9]+)$/', $manager, $match))
                continue;

            if($match[1] > 9 && $qa == false)
                continue;

            if($reorder)
                $result[$match[1]] = $this->em->getRepository('CharacterBundle:Characters', $manager)->findByAccount($accountId, null, $options);
            else
            {
                $characters = $this->em->getRepository('CharacterBundle:Characters', $manager)->findByAccount($accountId, null, $options);
                foreach($characters as $character)
                    $character->setRealm((int) $match[1]);
                $result = array_merge($result, $characters);
            }
        }
        return $result;
    }

    /**
     * @return array|mixed
     */
    public function getOpenTicketsCount()
    {
        $tickets = $this->redis->get('web:gm_tickets_count');
        if(!$tickets)
        {
            $tickets = [];
            foreach($this->realms as $realmId => $name)
            {
                $result = $this->em->getRepository('CharacterBundle:GmTickets', "realm{$realmId}")->getOpenTicketsCount();
                if(isset($result[1][1]))
                    $tickets[$realmId]['online'] = $result[1][1];
                if(isset($result[0][1]))
                    $tickets[$realmId]['offline'] = $result[0][1];
            }
            $this->redis->set("web:gm_tickets_count", serialize($tickets));
            $this->redis->expire("web:gm_tickets_count", 300);
            $this->redis->ttl("web:gm_tickets_count");
        }
        else
            $tickets = unserialize($tickets);
        return $tickets;
    }

    /**
     * @return array|mixed
     */
    public function getOpenTickets()
    {
        $tickets = $this->redis->get('web:gm_tickets');
        if(!$tickets)
        {
            $tickets = [];
            foreach($this->realms as $realmId => $name)
            {
                $result = $this->em->getRepository('CharacterBundle:GmTickets', "realm{$realmId}")->getOpenTickets();
                foreach($result as $ticket)
                {
                    $ticket['message']  = htmlspecialchars($ticket['message']);
                    $ticket['response'] = htmlspecialchars($ticket['response']);
                    $ticket['comment']  = htmlspecialchars($ticket['comment']);
                    $tickets[$realmId][$ticket['ticketId']] = $ticket;
                }
            }
            $this->redis->set("web:gm_tickets", serialize($tickets));
            $this->redis->expire("web:gm_tickets", 120);
            $this->redis->ttl("web:gm_tickets");
        }
        else
            $tickets = unserialize($tickets);
        return $tickets;
    }

    /**
     * @param            $start
     * @param            $end
     * @param bool|false $new
     * @return array|mixed
     */
    public function getTicketStats($start, $end, $new = false)
    {
        $tickets = $this->redis->get('web:gm_tickets_stats');
        if($new === true || !$tickets)
        {
            $tickets = [];

            $gmAccounts = $this->container->get('app.service.cache')->getGmAccounts();
            $realms = $this->container->getParameter('realms');
            $characters = [];
            foreach($gmAccounts as $account)
            {
                foreach($account->getCharacters() as $key => $character)
                {
                    if($character->getRealm() > 9)
                        continue;
                    $characters[$character->getRealm()][] = $character->getGuid();
                }
            }
            foreach($realms as $realmId => $realm)
            {
                $tickets[$realmId] = $this->em->getRepository('CharacterBundle:GmTickets', "realm{$realmId}")->findByTimeBetween($start, $end, $characters[$realmId]);
            }
            $this->redis->set("web:gm_tickets_stats", serialize($tickets));
            $this->redis->expire("web:gm_tickets_stats", 300);
            $this->redis->ttl("web:gm_tickets_stats");
        }
        else
            $tickets = unserialize($tickets);
        return $tickets;
    }

    /**
     * @return array|mixed
     */
    public function getTop100Rich()
    {
        $chars = $this->redis->get('web:gm_top100_gold');
        if(!$chars)
        {
            $chars = [];
            foreach($this->realms as $realmId => $name)
                $chars[$realmId] = $this->em->getRepository('CharacterBundle:Characters', "realm{$realmId}")->findBy(array(), array('money' => 'DESC'), 100);
            $this->redis->set("web:gm_top100_gold", serialize($chars));
            $this->redis->expire("web:gm_top100_gold", 300);
            $this->redis->ttl("web:gm_top100_gold");
        }
        else
            $chars = unserialize($chars);
        return $chars;
    }
}