<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GuildBankItem
 *
 * @ORM\Table(name="guild_bank_item", indexes={@ORM\Index(name="guildid_key", columns={"guildid"})})
 * @ORM\Entity
 */
class GuildBankItem
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guildid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $guildid = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="TabId", type="boolean")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $tabid = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="SlotId", type="boolean")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $slotid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="item_guid", type="integer", nullable=false)
     */
    protected $itemGuid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="item_entry", type="integer", nullable=false)
     */
    protected $itemEntry = '0';



    /**
     * Set guildid
     *
     * @param integer $guildid
     *
     * @return GuildBankItem
     */
    public function setGuildid($guildid)
    {
        $this->guildid = $guildid;

        return $this;
    }

    /**
     * Get guildid
     *
     * @return integer
     */
    public function getGuildid()
    {
        return $this->guildid;
    }

    /**
     * Set tabid
     *
     * @param boolean $tabid
     *
     * @return GuildBankItem
     */
    public function setTabid($tabid)
    {
        $this->tabid = $tabid;

        return $this;
    }

    /**
     * Get tabid
     *
     * @return boolean
     */
    public function getTabid()
    {
        return $this->tabid;
    }

    /**
     * Set slotid
     *
     * @param boolean $slotid
     *
     * @return GuildBankItem
     */
    public function setSlotid($slotid)
    {
        $this->slotid = $slotid;

        return $this;
    }

    /**
     * Get slotid
     *
     * @return boolean
     */
    public function getSlotid()
    {
        return $this->slotid;
    }

    /**
     * Set itemGuid
     *
     * @param integer $itemGuid
     *
     * @return GuildBankItem
     */
    public function setItemGuid($itemGuid)
    {
        $this->itemGuid = $itemGuid;

        return $this;
    }

    /**
     * Get itemGuid
     *
     * @return integer
     */
    public function getItemGuid()
    {
        return $this->itemGuid;
    }

    /**
     * Set itemEntry
     *
     * @param integer $itemEntry
     *
     * @return GuildBankItem
     */
    public function setItemEntry($itemEntry)
    {
        $this->itemEntry = $itemEntry;

        return $this;
    }

    /**
     * Get itemEntry
     *
     * @return integer
     */
    public function getItemEntry()
    {
        return $this->itemEntry;
    }
}
