<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GuildBankEventlog
 *
 * @ORM\Table(name="guild_bank_eventlog", indexes={@ORM\Index(name="guildid_key", columns={"guildid"})})
 * @ORM\Entity
 */
class GuildBankEventlog
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guildid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $guildid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="LogGuid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $logguid = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="LogEntry", type="boolean", nullable=false)
     */
    protected $logentry = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="TabId", type="boolean", nullable=false)
     */
    protected $tabid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="PlayerGuid", type="integer", nullable=false)
     */
    protected $playerguid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="ItemOrMoney", type="integer", nullable=false)
     */
    protected $itemormoney = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="ItemStackCount", type="boolean", nullable=false)
     */
    protected $itemstackcount = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="DestTabId", type="boolean", nullable=false)
     */
    protected $desttabid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="TimeStamp", type="bigint", nullable=false)
     */
    protected $timestamp = '0';



    /**
     * Set guildid
     *
     * @param integer $guildid
     *
     * @return GuildBankEventlog
     */
    public function setGuildid($guildid)
    {
        $this->guildid = $guildid;

        return $this;
    }

    /**
     * Get guildid
     *
     * @return integer
     */
    public function getGuildid()
    {
        return $this->guildid;
    }

    /**
     * Set logguid
     *
     * @param integer $logguid
     *
     * @return GuildBankEventlog
     */
    public function setLogguid($logguid)
    {
        $this->logguid = $logguid;

        return $this;
    }

    /**
     * Get logguid
     *
     * @return integer
     */
    public function getLogguid()
    {
        return $this->logguid;
    }

    /**
     * Set logentry
     *
     * @param boolean $logentry
     *
     * @return GuildBankEventlog
     */
    public function setLogentry($logentry)
    {
        $this->logentry = $logentry;

        return $this;
    }

    /**
     * Get logentry
     *
     * @return boolean
     */
    public function getLogentry()
    {
        return $this->logentry;
    }

    /**
     * Set tabid
     *
     * @param boolean $tabid
     *
     * @return GuildBankEventlog
     */
    public function setTabid($tabid)
    {
        $this->tabid = $tabid;

        return $this;
    }

    /**
     * Get tabid
     *
     * @return boolean
     */
    public function getTabid()
    {
        return $this->tabid;
    }

    /**
     * Set playerguid
     *
     * @param integer $playerguid
     *
     * @return GuildBankEventlog
     */
    public function setPlayerguid($playerguid)
    {
        $this->playerguid = $playerguid;

        return $this;
    }

    /**
     * Get playerguid
     *
     * @return integer
     */
    public function getPlayerguid()
    {
        return $this->playerguid;
    }

    /**
     * Set itemormoney
     *
     * @param integer $itemormoney
     *
     * @return GuildBankEventlog
     */
    public function setItemormoney($itemormoney)
    {
        $this->itemormoney = $itemormoney;

        return $this;
    }

    /**
     * Get itemormoney
     *
     * @return integer
     */
    public function getItemormoney()
    {
        return $this->itemormoney;
    }

    /**
     * Set itemstackcount
     *
     * @param boolean $itemstackcount
     *
     * @return GuildBankEventlog
     */
    public function setItemstackcount($itemstackcount)
    {
        $this->itemstackcount = $itemstackcount;

        return $this;
    }

    /**
     * Get itemstackcount
     *
     * @return boolean
     */
    public function getItemstackcount()
    {
        return $this->itemstackcount;
    }

    /**
     * Set desttabid
     *
     * @param boolean $desttabid
     *
     * @return GuildBankEventlog
     */
    public function setDesttabid($desttabid)
    {
        $this->desttabid = $desttabid;

        return $this;
    }

    /**
     * Get desttabid
     *
     * @return boolean
     */
    public function getDesttabid()
    {
        return $this->desttabid;
    }

    /**
     * Set timestamp
     *
     * @param integer $timestamp
     *
     * @return GuildBankEventlog
     */
    public function setTimestamp($timestamp)
    {
        $this->timestamp = $timestamp;

        return $this;
    }

    /**
     * Get timestamp
     *
     * @return integer
     */
    public function getTimestamp()
    {
        return $this->timestamp;
    }
}
