<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AiPlayerbotNames
 *
 * @ORM\Table(name="ai_playerbot_names", uniqueConstraints={@ORM\UniqueConstraint(name="name_id", columns={"name_id"}), @ORM\UniqueConstraint(name="name", columns={"name"})})
 * @ORM\Entity
 */
class AiPlayerbotNames
{
    /**
     * @var integer
     *
     * @ORM\Column(name="name_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $nameId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=13, nullable=false)
     */
    protected $name;

    /**
     * @var boolean
     *
     * @ORM\Column(name="gender", type="boolean", nullable=false)
     */
    protected $gender;

    /**
     * @var integer
     *
     * @ORM\Column(name="race", type="smallint", nullable=false)
     */
    protected $race;

    /**
     * @var integer
     *
     * @ORM\Column(name="class", type="smallint", nullable=false)
     */
    protected $class;

    /**
     * @var integer
     *
     * @ORM\Column(name="purpose", type="integer", nullable=false)
     */
    protected $purpose;

    /**
     * @var boolean
     *
     * @ORM\Column(name="priority", type="boolean", nullable=false)
     */
    protected $priority;

    /**
     * @var boolean
     *
     * @ORM\Column(name="in_use", type="boolean", nullable=false)
     */
    protected $inUse;



    /**
     * Get nameId
     *
     * @return integer
     */
    public function getNameId()
    {
        return $this->nameId;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return AiPlayerbotNames
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set gender
     *
     * @param boolean $gender
     *
     * @return AiPlayerbotNames
     */
    public function setGender($gender)
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get gender
     *
     * @return boolean
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set race
     *
     * @param integer $race
     *
     * @return AiPlayerbotNames
     */
    public function setRace($race)
    {
        $this->race = $race;

        return $this;
    }

    /**
     * Get race
     *
     * @return integer
     */
    public function getRace()
    {
        return $this->race;
    }

    /**
     * Set class
     *
     * @param integer $class
     *
     * @return AiPlayerbotNames
     */
    public function setClass($class)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return integer
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Set purpose
     *
     * @param integer $purpose
     *
     * @return AiPlayerbotNames
     */
    public function setPurpose($purpose)
    {
        $this->purpose = $purpose;

        return $this;
    }

    /**
     * Get purpose
     *
     * @return integer
     */
    public function getPurpose()
    {
        return $this->purpose;
    }

    /**
     * Set priority
     *
     * @param boolean $priority
     *
     * @return AiPlayerbotNames
     */
    public function setPriority($priority)
    {
        $this->priority = $priority;

        return $this;
    }

    /**
     * Get priority
     *
     * @return boolean
     */
    public function getPriority()
    {
        return $this->priority;
    }

    /**
     * Set inUse
     *
     * @param boolean $inUse
     *
     * @return AiPlayerbotNames
     */
    public function setInUse($inUse)
    {
        $this->inUse = $inUse;

        return $this;
    }

    /**
     * Get inUse
     *
     * @return boolean
     */
    public function getInUse()
    {
        return $this->inUse;
    }
}
