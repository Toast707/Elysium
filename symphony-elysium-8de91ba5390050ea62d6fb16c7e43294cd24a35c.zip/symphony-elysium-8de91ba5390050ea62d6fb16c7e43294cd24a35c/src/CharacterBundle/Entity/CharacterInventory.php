<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterInventory
 *
 * @ORM\Table(name="character_inventory", indexes={@ORM\Index(name="idx_guid", columns={"guid"})})
 * @ORM\Entity
 */
class CharacterInventory
{
    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\ItemInstance", fetch="EXTRA_LAZY")
     * @ORM\JoinColumn(name="item", referencedColumnName="guid")
     */
    protected $item = '0';

    /**
     * @ORM\ManyToOne(targetEntity="CharacterBundle\Entity\Characters", inversedBy="items", fetch="EXTRA_LAZY")
     * @ORM\JoinColumn(name="guid", referencedColumnName="guid")
     */
    protected $guid;

    /**
     * @var integer
     *
     * @ORM\Column(name="bag", type="integer", nullable=false)
     */
    protected $bag = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="slot", type="integer", nullable=false)
     */
    protected $slot = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="item_template", type="integer")
     */
    protected $itemTemplate = '0';



    /**
     * Get item
     *
     * @return integer
     */
    public function getItem()
    {
        return $this->item;
    }

    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return CharacterInventory
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set bag
     *
     * @param integer $bag
     *
     * @return CharacterInventory
     */
    public function setBag($bag)
    {
        $this->bag = $bag;

        return $this;
    }

    /**
     * Get bag
     *
     * @return integer
     */
    public function getBag()
    {
        return $this->bag;
    }

    /**
     * Set slot
     *
     * @param integer $slot
     *
     * @return CharacterInventory
     */
    public function setSlot($slot)
    {
        $this->slot = $slot;

        return $this;
    }

    /**
     * Get slot
     *
     * @return integer
     */
    public function getSlot()
    {
        return $this->slot;
    }

    /**
     * Set itemTemplate
     *
     * @param integer $itemTemplate
     *
     * @return CharacterInventory
     */
    public function setItemTemplate($itemTemplate)
    {
        $this->itemTemplate = $itemTemplate;

        return $this;
    }

    /**
     * Get itemTemplate
     *
     * @return integer
     */
    public function getItemTemplate()
    {
        return $this->itemTemplate;
    }
}
