<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GroupMember
 *
 * @ORM\Table(name="group_member")
 * @ORM\Entity
 */
class GroupMember
{
    /**
     * @var integer
     *
     * @ORM\Column(name="leaderGuid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $leaderguid;

    /**
     * @var integer
     *
     * @ORM\Column(name="memberGuid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $memberguid;

    /**
     * @var boolean
     *
     * @ORM\Column(name="assistant", type="boolean", nullable=false)
     */
    protected $assistant;

    /**
     * @var integer
     *
     * @ORM\Column(name="subgroup", type="smallint", nullable=false)
     */
    protected $subgroup;



    /**
     * Set leaderguid
     *
     * @param integer $leaderguid
     *
     * @return GroupMember
     */
    public function setLeaderguid($leaderguid)
    {
        $this->leaderguid = $leaderguid;

        return $this;
    }

    /**
     * Get leaderguid
     *
     * @return integer
     */
    public function getLeaderguid()
    {
        return $this->leaderguid;
    }

    /**
     * Set memberguid
     *
     * @param integer $memberguid
     *
     * @return GroupMember
     */
    public function setMemberguid($memberguid)
    {
        $this->memberguid = $memberguid;

        return $this;
    }

    /**
     * Get memberguid
     *
     * @return integer
     */
    public function getMemberguid()
    {
        return $this->memberguid;
    }

    /**
     * Set assistant
     *
     * @param boolean $assistant
     *
     * @return GroupMember
     */
    public function setAssistant($assistant)
    {
        $this->assistant = $assistant;

        return $this;
    }

    /**
     * Get assistant
     *
     * @return boolean
     */
    public function getAssistant()
    {
        return $this->assistant;
    }

    /**
     * Set subgroup
     *
     * @param integer $subgroup
     *
     * @return GroupMember
     */
    public function setSubgroup($subgroup)
    {
        $this->subgroup = $subgroup;

        return $this;
    }

    /**
     * Get subgroup
     *
     * @return integer
     */
    public function getSubgroup()
    {
        return $this->subgroup;
    }
}
