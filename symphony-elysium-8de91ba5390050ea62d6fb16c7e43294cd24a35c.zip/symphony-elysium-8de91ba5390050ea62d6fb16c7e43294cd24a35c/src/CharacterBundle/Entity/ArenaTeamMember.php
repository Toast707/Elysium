<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ArenaTeamMember
 *
 * @ORM\Table(name="arena_team_member")
 * @ORM\Entity
 */
class ArenaTeamMember
{
    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\ManyToOne(targetEntity="CharacterBundle\Entity\ArenaTeam", inversedBy="members")
     * @ORM\JoinColumn(name="arenateamid", referencedColumnName="arenateamid")
     */
    protected $arenateamid = '0';

    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\Characters")
     * @ORM\JoinColumn(name="guid", referencedColumnName="guid")
     */
    protected $guid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="played_week", type="integer", nullable=false)
     */
    protected $playedWeek = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="wons_week", type="integer", nullable=false)
     */
    protected $wonsWeek = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="played_season", type="integer", nullable=false)
     */
    protected $playedSeason = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="wons_season", type="integer", nullable=false)
     */
    protected $wonsSeason = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="personal_rating", type="integer", nullable=false)
     */
    protected $personalRating = '0';



    /**
     * Set arenateamid
     *
     * @param integer $arenateamid
     *
     * @return ArenaTeamMember
     */
    public function setArenateamid($arenateamid)
    {
        $this->arenateamid = $arenateamid;

        return $this;
    }

    /**
     * Get arenateamid
     *
     * @return integer
     */
    public function getArenateamid()
    {
        return $this->arenateamid;
    }

    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return ArenaTeamMember
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set playedWeek
     *
     * @param integer $playedWeek
     *
     * @return ArenaTeamMember
     */
    public function setPlayedWeek($playedWeek)
    {
        $this->playedWeek = $playedWeek;

        return $this;
    }

    /**
     * Get playedWeek
     *
     * @return integer
     */
    public function getPlayedWeek()
    {
        return $this->playedWeek;
    }

    /**
     * Set wonsWeek
     *
     * @param integer $wonsWeek
     *
     * @return ArenaTeamMember
     */
    public function setWonsWeek($wonsWeek)
    {
        $this->wonsWeek = $wonsWeek;

        return $this;
    }

    /**
     * Get wonsWeek
     *
     * @return integer
     */
    public function getWonsWeek()
    {
        return $this->wonsWeek;
    }

    /**
     * Set playedSeason
     *
     * @param integer $playedSeason
     *
     * @return ArenaTeamMember
     */
    public function setPlayedSeason($playedSeason)
    {
        $this->playedSeason = $playedSeason;

        return $this;
    }

    /**
     * Get playedSeason
     *
     * @return integer
     */
    public function getPlayedSeason()
    {
        return $this->playedSeason;
    }

    /**
     * Set wonsSeason
     *
     * @param integer $wonsSeason
     *
     * @return ArenaTeamMember
     */
    public function setWonsSeason($wonsSeason)
    {
        $this->wonsSeason = $wonsSeason;

        return $this;
    }

    /**
     * Get wonsSeason
     *
     * @return integer
     */
    public function getWonsSeason()
    {
        return $this->wonsSeason;
    }

    /**
     * Set personalRating
     *
     * @param integer $personalRating
     *
     * @return ArenaTeamMember
     */
    public function setPersonalRating($personalRating)
    {
        $this->personalRating = $personalRating;

        return $this;
    }

    /**
     * Get personalRating
     *
     * @return integer
     */
    public function getPersonalRating()
    {
        return $this->personalRating;
    }
}
