<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MailItems
 *
 * @ORM\Table(name="mail_items", indexes={@ORM\Index(name="idx_receiver", columns={"receiver"})})
 * @ORM\Entity
 */
class MailItems
{
    /**
     * @var integer
     *
     * @ORM\Column(name="mail_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $mailId = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="item_guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $itemGuid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="item_template", type="integer", nullable=false)
     */
    protected $itemTemplate = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="receiver", type="integer", nullable=false)
     */
    protected $receiver = '0';



    /**
     * Set mailId
     *
     * @param integer $mailId
     *
     * @return MailItems
     */
    public function setMailId($mailId)
    {
        $this->mailId = $mailId;

        return $this;
    }

    /**
     * Get mailId
     *
     * @return integer
     */
    public function getMailId()
    {
        return $this->mailId;
    }

    /**
     * Set itemGuid
     *
     * @param integer $itemGuid
     *
     * @return MailItems
     */
    public function setItemGuid($itemGuid)
    {
        $this->itemGuid = $itemGuid;

        return $this;
    }

    /**
     * Get itemGuid
     *
     * @return integer
     */
    public function getItemGuid()
    {
        return $this->itemGuid;
    }

    /**
     * Set itemTemplate
     *
     * @param integer $itemTemplate
     *
     * @return MailItems
     */
    public function setItemTemplate($itemTemplate)
    {
        $this->itemTemplate = $itemTemplate;

        return $this;
    }

    /**
     * Get itemTemplate
     *
     * @return integer
     */
    public function getItemTemplate()
    {
        return $this->itemTemplate;
    }

    /**
     * Set receiver
     *
     * @param integer $receiver
     *
     * @return MailItems
     */
    public function setReceiver($receiver)
    {
        $this->receiver = $receiver;

        return $this;
    }

    /**
     * Get receiver
     *
     * @return integer
     */
    public function getReceiver()
    {
        return $this->receiver;
    }
}
