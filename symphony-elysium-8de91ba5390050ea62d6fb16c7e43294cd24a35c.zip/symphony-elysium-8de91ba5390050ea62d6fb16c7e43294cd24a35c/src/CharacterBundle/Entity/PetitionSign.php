<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * PetitionSign
 *
 * @ORM\Table(name="petition_sign")
 * @ORM\Entity
 */
class PetitionSign
{
    /**
     * @var integer
     *
     * @ORM\Column(name="petitionguid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $petitionguid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="playerguid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $playerguid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="ownerguid", type="integer", nullable=false)
     */
    protected $ownerguid;

    /**
     * @var integer
     *
     * @ORM\Column(name="player_account", type="integer", nullable=false)
     */
    protected $playerAccount = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="type", type="integer", nullable=false)
     */
    protected $type = '0';



    /**
     * Set petitionguid
     *
     * @param integer $petitionguid
     *
     * @return PetitionSign
     */
    public function setPetitionguid($petitionguid)
    {
        $this->petitionguid = $petitionguid;

        return $this;
    }

    /**
     * Get petitionguid
     *
     * @return integer
     */
    public function getPetitionguid()
    {
        return $this->petitionguid;
    }

    /**
     * Set playerguid
     *
     * @param integer $playerguid
     *
     * @return PetitionSign
     */
    public function setPlayerguid($playerguid)
    {
        $this->playerguid = $playerguid;

        return $this;
    }

    /**
     * Get playerguid
     *
     * @return integer
     */
    public function getPlayerguid()
    {
        return $this->playerguid;
    }

    /**
     * Set ownerguid
     *
     * @param integer $ownerguid
     *
     * @return PetitionSign
     */
    public function setOwnerguid($ownerguid)
    {
        $this->ownerguid = $ownerguid;

        return $this;
    }

    /**
     * Get ownerguid
     *
     * @return integer
     */
    public function getOwnerguid()
    {
        return $this->ownerguid;
    }

    /**
     * Set playerAccount
     *
     * @param integer $playerAccount
     *
     * @return PetitionSign
     */
    public function setPlayerAccount($playerAccount)
    {
        $this->playerAccount = $playerAccount;

        return $this;
    }

    /**
     * Get playerAccount
     *
     * @return integer
     */
    public function getPlayerAccount()
    {
        return $this->playerAccount;
    }

    /**
     * Set type
     *
     * @param integer $type
     *
     * @return PetitionSign
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return integer
     */
    public function getType()
    {
        return $this->type;
    }
}
