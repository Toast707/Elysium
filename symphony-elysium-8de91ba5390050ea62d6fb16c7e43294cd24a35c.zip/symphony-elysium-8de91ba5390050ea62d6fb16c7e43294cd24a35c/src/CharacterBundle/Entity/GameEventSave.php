<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GameEventSave
 *
 * @ORM\Table(name="game_event_save")
 * @ORM\Entity
 */
class GameEventSave
{
    /**
     * @var integer
     *
     * @ORM\Column(name="event_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $eventId;

    /**
     * @var boolean
     *
     * @ORM\Column(name="state", type="boolean", nullable=false)
     */
    protected $state = '1';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="next_start", type="datetime", nullable=false)
     */
    protected $nextStart = '0000-00-00 00:00:00';



    /**
     * Get eventId
     *
     * @return integer
     */
    public function getEventId()
    {
        return $this->eventId;
    }

    /**
     * Set state
     *
     * @param boolean $state
     *
     * @return GameEventSave
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return boolean
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set nextStart
     *
     * @param \DateTime $nextStart
     *
     * @return GameEventSave
     */
    public function setNextStart($nextStart)
    {
        $this->nextStart = $nextStart;

        return $this;
    }

    /**
     * Get nextStart
     *
     * @return \DateTime
     */
    public function getNextStart()
    {
        return $this->nextStart;
    }
}
