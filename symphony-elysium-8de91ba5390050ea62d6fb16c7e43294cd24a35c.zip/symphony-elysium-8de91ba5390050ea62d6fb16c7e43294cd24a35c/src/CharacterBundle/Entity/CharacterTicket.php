<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterTicket
 *
 * @ORM\Table(name="character_ticket")
 * @ORM\Entity
 */
class CharacterTicket
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ticket_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $ticketId;

    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer", nullable=false)
     */
    protected $guid = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="ticket_text", type="text", length=65535, nullable=true)
     */
    protected $ticketText;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="ticket_lastchange", type="datetime", nullable=false)
     */
    protected $ticketLastchange = 'CURRENT_TIMESTAMP';



    /**
     * Get ticketId
     *
     * @return integer
     */
    public function getTicketId()
    {
        return $this->ticketId;
    }

    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return CharacterTicket
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set ticketText
     *
     * @param string $ticketText
     *
     * @return CharacterTicket
     */
    public function setTicketText($ticketText)
    {
        $this->ticketText = $ticketText;

        return $this;
    }

    /**
     * Get ticketText
     *
     * @return string
     */
    public function getTicketText()
    {
        return $this->ticketText;
    }

    /**
     * Set ticketLastchange
     *
     * @param \DateTime $ticketLastchange
     *
     * @return CharacterTicket
     */
    public function setTicketLastchange($ticketLastchange)
    {
        $this->ticketLastchange = $ticketLastchange;

        return $this;
    }

    /**
     * Get ticketLastchange
     *
     * @return \DateTime
     */
    public function getTicketLastchange()
    {
        return $this->ticketLastchange;
    }
}
