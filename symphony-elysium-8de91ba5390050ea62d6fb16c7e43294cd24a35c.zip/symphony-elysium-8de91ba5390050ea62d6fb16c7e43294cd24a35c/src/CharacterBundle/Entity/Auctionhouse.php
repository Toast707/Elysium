<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Auctionhouse
 *
 * @ORM\Table(name="auctionhouse", uniqueConstraints={@ORM\UniqueConstraint(name="item_guid", columns={"itemguid"})})
 * @ORM\Entity
 */
class Auctionhouse
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="auctioneerguid", type="integer", nullable=false)
     */
    protected $auctioneerguid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="itemguid", type="integer", nullable=false)
     */
    protected $itemguid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="item_template", type="integer", nullable=false)
     */
    protected $itemTemplate = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="itemowner", type="integer", nullable=false)
     */
    protected $itemowner = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyoutprice", type="integer", nullable=false)
     */
    protected $buyoutprice = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="time", type="bigint", nullable=false)
     */
    protected $time = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyguid", type="integer", nullable=false)
     */
    protected $buyguid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="lastbid", type="integer", nullable=false)
     */
    protected $lastbid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="startbid", type="integer", nullable=false)
     */
    protected $startbid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="deposit", type="integer", nullable=false)
     */
    protected $deposit = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="location", type="boolean", nullable=false)
     */
    protected $location = '3';



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set auctioneerguid
     *
     * @param integer $auctioneerguid
     *
     * @return Auctionhouse
     */
    public function setAuctioneerguid($auctioneerguid)
    {
        $this->auctioneerguid = $auctioneerguid;

        return $this;
    }

    /**
     * Get auctioneerguid
     *
     * @return integer
     */
    public function getAuctioneerguid()
    {
        return $this->auctioneerguid;
    }

    /**
     * Set itemguid
     *
     * @param integer $itemguid
     *
     * @return Auctionhouse
     */
    public function setItemguid($itemguid)
    {
        $this->itemguid = $itemguid;

        return $this;
    }

    /**
     * Get itemguid
     *
     * @return integer
     */
    public function getItemguid()
    {
        return $this->itemguid;
    }

    /**
     * Set itemTemplate
     *
     * @param integer $itemTemplate
     *
     * @return Auctionhouse
     */
    public function setItemTemplate($itemTemplate)
    {
        $this->itemTemplate = $itemTemplate;

        return $this;
    }

    /**
     * Get itemTemplate
     *
     * @return integer
     */
    public function getItemTemplate()
    {
        return $this->itemTemplate;
    }

    /**
     * Set itemowner
     *
     * @param integer $itemowner
     *
     * @return Auctionhouse
     */
    public function setItemowner($itemowner)
    {
        $this->itemowner = $itemowner;

        return $this;
    }

    /**
     * Get itemowner
     *
     * @return integer
     */
    public function getItemowner()
    {
        return $this->itemowner;
    }

    /**
     * Set buyoutprice
     *
     * @param integer $buyoutprice
     *
     * @return Auctionhouse
     */
    public function setBuyoutprice($buyoutprice)
    {
        $this->buyoutprice = $buyoutprice;

        return $this;
    }

    /**
     * Get buyoutprice
     *
     * @return integer
     */
    public function getBuyoutprice()
    {
        return $this->buyoutprice;
    }

    /**
     * Set time
     *
     * @param integer $time
     *
     * @return Auctionhouse
     */
    public function setTime($time)
    {
        $this->time = $time;

        return $this;
    }

    /**
     * Get time
     *
     * @return integer
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set buyguid
     *
     * @param integer $buyguid
     *
     * @return Auctionhouse
     */
    public function setBuyguid($buyguid)
    {
        $this->buyguid = $buyguid;

        return $this;
    }

    /**
     * Get buyguid
     *
     * @return integer
     */
    public function getBuyguid()
    {
        return $this->buyguid;
    }

    /**
     * Set lastbid
     *
     * @param integer $lastbid
     *
     * @return Auctionhouse
     */
    public function setLastbid($lastbid)
    {
        $this->lastbid = $lastbid;

        return $this;
    }

    /**
     * Get lastbid
     *
     * @return integer
     */
    public function getLastbid()
    {
        return $this->lastbid;
    }

    /**
     * Set startbid
     *
     * @param integer $startbid
     *
     * @return Auctionhouse
     */
    public function setStartbid($startbid)
    {
        $this->startbid = $startbid;

        return $this;
    }

    /**
     * Get startbid
     *
     * @return integer
     */
    public function getStartbid()
    {
        return $this->startbid;
    }

    /**
     * Set deposit
     *
     * @param integer $deposit
     *
     * @return Auctionhouse
     */
    public function setDeposit($deposit)
    {
        $this->deposit = $deposit;

        return $this;
    }

    /**
     * Get deposit
     *
     * @return integer
     */
    public function getDeposit()
    {
        return $this->deposit;
    }

    /**
     * Set location
     *
     * @param boolean $location
     *
     * @return Auctionhouse
     */
    public function setLocation($location)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return boolean
     */
    public function getLocation()
    {
        return $this->location;
    }
}
