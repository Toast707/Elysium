<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * ArenaTeam
 *
 * @ORM\Table(name="arena_team")
 * @ORM\Entity(repositoryClass="CharacterBundle\Repository\ArenaTeamRepository")
 */
class ArenaTeam
{
    /**
     * @var integer
     *
     * @ORM\Column(name="arenateamid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $arenateamid = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=false)
     */
    protected $name;

    /**
     * @var integer
     *
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\Characters")
     * @ORM\JoinColumn(name="captainguid", referencedColumnName="guid")
     */
    protected $captainguid = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="type", type="integer", nullable=false)
     */
    protected $type = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="BackgroundColor", type="integer", nullable=false)
     */
    protected $backgroundcolor = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="EmblemStyle", type="integer", nullable=false)
     */
    protected $emblemstyle = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="EmblemColor", type="integer", nullable=false)
     */
    protected $emblemcolor = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="BorderStyle", type="integer", nullable=false)
     */
    protected $borderstyle = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="BorderColor", type="integer", nullable=false)
     */
    protected $bordercolor = '0';

    /**
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\ArenaTeamStats", mappedBy="arenateamid")
     */
    protected $stats;

    /**
     * @ORM\OneToMany(targetEntity="CharacterBundle\Entity\ArenaTeamMember", mappedBy="arenateamid")
     */
    private $members;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->features = new ArrayCollection();
    }



    /**
     * Get arenateamid
     *
     * @return integer
     */
    public function getArenateamid()
    {
        return $this->arenateamid;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return ArenaTeam
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set captainguid
     *
     * @param integer $captainguid
     *
     * @return ArenaTeam
     */
    public function setCaptainguid($captainguid)
    {
        $this->captainguid = $captainguid;

        return $this;
    }

    /**
     * Get captainguid
     *
     * @return integer
     */
    public function getCaptainguid()
    {
        return $this->captainguid;
    }

    /**
     * Set type
     *
     * @param integer $type
     *
     * @return ArenaTeam
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return integer
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set backgroundcolor
     *
     * @param integer $backgroundcolor
     *
     * @return ArenaTeam
     */
    public function setBackgroundcolor($backgroundcolor)
    {
        $this->backgroundcolor = $backgroundcolor;

        return $this;
    }

    /**
     * Get backgroundcolor
     *
     * @return integer
     */
    public function getBackgroundcolor()
    {
        return $this->backgroundcolor;
    }

    /**
     * Set emblemstyle
     *
     * @param integer $emblemstyle
     *
     * @return ArenaTeam
     */
    public function setEmblemstyle($emblemstyle)
    {
        $this->emblemstyle = $emblemstyle;

        return $this;
    }

    /**
     * Get emblemstyle
     *
     * @return integer
     */
    public function getEmblemstyle()
    {
        return $this->emblemstyle;
    }

    /**
     * Set emblemcolor
     *
     * @param integer $emblemcolor
     *
     * @return ArenaTeam
     */
    public function setEmblemcolor($emblemcolor)
    {
        $this->emblemcolor = $emblemcolor;

        return $this;
    }

    /**
     * Get emblemcolor
     *
     * @return integer
     */
    public function getEmblemcolor()
    {
        return $this->emblemcolor;
    }

    /**
     * Set borderstyle
     *
     * @param integer $borderstyle
     *
     * @return ArenaTeam
     */
    public function setBorderstyle($borderstyle)
    {
        $this->borderstyle = $borderstyle;

        return $this;
    }

    /**
     * Get borderstyle
     *
     * @return integer
     */
    public function getBorderstyle()
    {
        return $this->borderstyle;
    }

    /**
     * Set bordercolor
     *
     * @param integer $bordercolor
     *
     * @return ArenaTeam
     */
    public function setBordercolor($bordercolor)
    {
        $this->bordercolor = $bordercolor;

        return $this;
    }

    /**
     * Get bordercolor
     *
     * @return integer
     */
    public function getBordercolor()
    {
        return $this->bordercolor;
    }

    /**
     * @return mixed
     */
    public function getStats()
    {
        return $this->stats;
    }

    /**
     * @param mixed $stats
     */
    public function setStats($stats)
    {
        $this->stats = $stats;
    }

    /**
     * Add member
     *
     * @param \CharacterBundle\Entity\ArenaTeamMember $member
     *
     * @return ArenaTeam
     */
    public function addBoost(ArenaTeamMember $member)
    {
        $this->members[] = $member;

        return $this;
    }

    /**
     * Remove member
     *
     * @param \CharacterBundle\Entity\ArenaTeamMember $member
     */
    public function removeBoost(ArenaTeamMember $member)
    {
        $this->members->removeElement($member);
    }

    /**
     * Get members
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getMembers()
    {
        return $this->members;
    }
}
