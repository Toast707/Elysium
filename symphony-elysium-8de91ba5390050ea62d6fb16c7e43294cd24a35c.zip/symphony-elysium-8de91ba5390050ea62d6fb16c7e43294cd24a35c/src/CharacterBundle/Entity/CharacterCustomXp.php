<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterCustomXp
 *
 * @ORM\Table(name="character_custom_xp")
 * @ORM\Entity
 */
class CharacterCustomXp
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $guid;

    /**
     * @var float
     *
     * @ORM\Column(name="custom_xp", type="float", precision=10, scale=0, nullable=false)
     */
    protected $customXp;



    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set customXp
     *
     * @param float $customXp
     *
     * @return CharacterCustomXp
     */
    public function setCustomXp($customXp)
    {
        $this->customXp = $customXp;

        return $this;
    }

    /**
     * Get customXp
     *
     * @return float
     */
    public function getCustomXp()
    {
        return $this->customXp;
    }
}
