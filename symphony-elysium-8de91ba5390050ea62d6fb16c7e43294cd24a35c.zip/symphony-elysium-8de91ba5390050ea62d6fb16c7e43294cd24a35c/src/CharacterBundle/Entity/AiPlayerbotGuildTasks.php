<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AiPlayerbotGuildTasks
 *
 * @ORM\Table(name="ai_playerbot_guild_tasks", indexes={@ORM\Index(name="owner", columns={"owner"}), @ORM\Index(name="guildid", columns={"guildid"}), @ORM\Index(name="type", columns={"type"})})
 * @ORM\Entity
 */
class AiPlayerbotGuildTasks
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="owner", type="bigint", nullable=false)
     */
    protected $owner;

    /**
     * @var integer
     *
     * @ORM\Column(name="guildid", type="bigint", nullable=false)
     */
    protected $guildid;

    /**
     * @var integer
     *
     * @ORM\Column(name="time", type="bigint", nullable=false)
     */
    protected $time;

    /**
     * @var integer
     *
     * @ORM\Column(name="validIn", type="bigint", nullable=true)
     */
    protected $validin;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=45, nullable=true)
     */
    protected $type;

    /**
     * @var integer
     *
     * @ORM\Column(name="value", type="bigint", nullable=true)
     */
    protected $value;

    /**
     * @var string
     *
     * @ORM\Column(name="data", type="string", length=255, nullable=true)
     */
    protected $data;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set owner
     *
     * @param integer $owner
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return integer
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * Set guildid
     *
     * @param integer $guildid
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setGuildid($guildid)
    {
        $this->guildid = $guildid;

        return $this;
    }

    /**
     * Get guildid
     *
     * @return integer
     */
    public function getGuildid()
    {
        return $this->guildid;
    }

    /**
     * Set time
     *
     * @param integer $time
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setTime($time)
    {
        $this->time = $time;

        return $this;
    }

    /**
     * Get time
     *
     * @return integer
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set validin
     *
     * @param integer $validin
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setValidin($validin)
    {
        $this->validin = $validin;

        return $this;
    }

    /**
     * Get validin
     *
     * @return integer
     */
    public function getValidin()
    {
        return $this->validin;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set value
     *
     * @param integer $value
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return integer
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set data
     *
     * @param string $data
     *
     * @return AiPlayerbotGuildTasks
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }

    /**
     * Get data
     *
     * @return string
     */
    public function getData()
    {
        return $this->data;
    }
}
