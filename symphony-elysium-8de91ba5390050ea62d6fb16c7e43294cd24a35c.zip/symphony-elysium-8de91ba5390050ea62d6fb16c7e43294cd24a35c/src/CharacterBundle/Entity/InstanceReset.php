<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * InstanceReset
 *
 * @ORM\Table(name="instance_reset", indexes={@ORM\Index(name="difficulty", columns={"difficulty"})})
 * @ORM\Entity
 */
class InstanceReset
{
    /**
     * @var integer
     *
     * @ORM\Column(name="mapid", type="smallint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $mapid = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="difficulty", type="boolean")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $difficulty = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="resettime", type="integer", nullable=false)
     */
    protected $resettime = '0';



    /**
     * Set mapid
     *
     * @param integer $mapid
     *
     * @return InstanceReset
     */
    public function setMapid($mapid)
    {
        $this->mapid = $mapid;

        return $this;
    }

    /**
     * Get mapid
     *
     * @return integer
     */
    public function getMapid()
    {
        return $this->mapid;
    }

    /**
     * Set difficulty
     *
     * @param boolean $difficulty
     *
     * @return InstanceReset
     */
    public function setDifficulty($difficulty)
    {
        $this->difficulty = $difficulty;

        return $this;
    }

    /**
     * Get difficulty
     *
     * @return boolean
     */
    public function getDifficulty()
    {
        return $this->difficulty;
    }

    /**
     * Set resettime
     *
     * @param integer $resettime
     *
     * @return InstanceReset
     */
    public function setResettime($resettime)
    {
        $this->resettime = $resettime;

        return $this;
    }

    /**
     * Get resettime
     *
     * @return integer
     */
    public function getResettime()
    {
        return $this->resettime;
    }
}
