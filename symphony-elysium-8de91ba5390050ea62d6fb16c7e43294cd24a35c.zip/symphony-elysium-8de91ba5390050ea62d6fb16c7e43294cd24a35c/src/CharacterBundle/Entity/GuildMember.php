<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GuildMember
 *
 * @ORM\Table(name="guild_member", uniqueConstraints={@ORM\UniqueConstraint(name="guid_key", columns={"guid"})}, indexes={@ORM\Index(name="guildid_key", columns={"guildid"}), @ORM\Index(name="guildid_rank_key", columns={"guildid", "rank"})})
 * @ORM\Entity
 */
class GuildMember
{
    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\Characters", inversedBy="guild")
     * @ORM\JoinColumn(name="guid", referencedColumnName="guid")
     */
    protected $guid;

    /**
     * @var integer
     *
     * @ORM\ManyToOne(targetEntity="CharacterBundle\Entity\Guild", inversedBy="members")
     * @ORM\JoinColumn(name="guildid", referencedColumnName="guildid")
     */
    protected $guildid;

    /**
     * @var integer
     *
     * @ORM\Column(name="rank", type="integer", nullable=false)
     */
    protected $rank;

    /**
     * @var string
     *
     * @ORM\Column(name="pnote", type="string", length=255, nullable=false)
     */
    protected $pnote;

    /**
     * @var string
     *
     * @ORM\Column(name="offnote", type="string", length=255, nullable=false)
     */
    protected $offnote;

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set guildid
     *
     * @param integer $guildid
     *
     * @return GuildMember
     */
    public function setGuildid($guildid)
    {
        $this->guildid = $guildid;

        return $this;
    }

    /**
     * Get guildid
     *
     * @return integer
     */
    public function getGuildid()
    {
        return $this->guildid;
    }

    /**
     * Set rank
     *
     * @param boolean $rank
     *
     * @return GuildMember
     */
    public function setRank($rank)
    {
        $this->rank = $rank;

        return $this;
    }

    /**
     * Get rank
     *
     * @return boolean
     */
    public function getRank()
    {
        return $this->rank;
    }

    /**
     * Set pnote
     *
     * @param string $pnote
     *
     * @return GuildMember
     */
    public function setPnote($pnote)
    {
        $this->pnote = $pnote;

        return $this;
    }

    /**
     * Get pnote
     *
     * @return string
     */
    public function getPnote()
    {
        return $this->pnote;
    }

    /**
     * Set offnote
     *
     * @param string $offnote
     *
     * @return GuildMember
     */
    public function setOffnote($offnote)
    {
        $this->offnote = $offnote;

        return $this;
    }

    /**
     * Get offnote
     *
     * @return string
     */
    public function getOffnote()
    {
        return $this->offnote;
    }
}
