<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AiPlayerbotRandomBots
 *
 * @ORM\Table(name="ai_playerbot_random_bots", indexes={@ORM\Index(name="owner", columns={"owner"}), @ORM\Index(name="bot", columns={"bot"}), @ORM\Index(name="event", columns={"event"})})
 * @ORM\Entity
 */
class AiPlayerbotRandomBots
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="owner", type="bigint", nullable=false)
     */
    protected $owner;

    /**
     * @var integer
     *
     * @ORM\Column(name="bot", type="bigint", nullable=false)
     */
    protected $bot;

    /**
     * @var integer
     *
     * @ORM\Column(name="time", type="bigint", nullable=false)
     */
    protected $time;

    /**
     * @var integer
     *
     * @ORM\Column(name="validIn", type="bigint", nullable=true)
     */
    protected $validin;

    /**
     * @var string
     *
     * @ORM\Column(name="event", type="string", length=45, nullable=true)
     */
    protected $event;

    /**
     * @var integer
     *
     * @ORM\Column(name="value", type="bigint", nullable=true)
     */
    protected $value;

    /**
     * @var string
     *
     * @ORM\Column(name="data", type="string", length=255, nullable=true)
     */
    protected $data;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set owner
     *
     * @param integer $owner
     *
     * @return AiPlayerbotRandomBots
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return integer
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * Set bot
     *
     * @param integer $bot
     *
     * @return AiPlayerbotRandomBots
     */
    public function setBot($bot)
    {
        $this->bot = $bot;

        return $this;
    }

    /**
     * Get bot
     *
     * @return integer
     */
    public function getBot()
    {
        return $this->bot;
    }

    /**
     * Set time
     *
     * @param integer $time
     *
     * @return AiPlayerbotRandomBots
     */
    public function setTime($time)
    {
        $this->time = $time;

        return $this;
    }

    /**
     * Get time
     *
     * @return integer
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set validin
     *
     * @param integer $validin
     *
     * @return AiPlayerbotRandomBots
     */
    public function setValidin($validin)
    {
        $this->validin = $validin;

        return $this;
    }

    /**
     * Get validin
     *
     * @return integer
     */
    public function getValidin()
    {
        return $this->validin;
    }

    /**
     * Set event
     *
     * @param string $event
     *
     * @return AiPlayerbotRandomBots
     */
    public function setEvent($event)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return string
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Set value
     *
     * @param integer $value
     *
     * @return AiPlayerbotRandomBots
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return integer
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set data
     *
     * @param string $data
     *
     * @return AiPlayerbotRandomBots
     */
    public function setData($data)
    {
        $this->data = $data;

        return $this;
    }

    /**
     * Get data
     *
     * @return string
     */
    public function getData()
    {
        return $this->data;
    }
}
