<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Pvprewards
 *
 * @ORM\Table(name="pvprewards")
 * @ORM\Entity
 */
class Pvprewards
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="bigint", nullable=false)
     */
    protected $guid;

    /**
     * @var integer
     *
     * @ORM\Column(name="arena_type", type="integer", nullable=false)
     */
    protected $arenaType;

    /**
     * @var integer
     *
     * @ORM\Column(name="rank", type="integer", nullable=false)
     */
    protected $rank;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return Pvprewards
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set arenaType
     *
     * @param integer $arenaType
     *
     * @return Pvprewards
     */
    public function setArenaType($arenaType)
    {
        $this->arenaType = $arenaType;

        return $this;
    }

    /**
     * Get arenaType
     *
     * @return integer
     */
    public function getArenaType()
    {
        return $this->arenaType;
    }

    /**
     * Set rank
     *
     * @param integer $rank
     *
     * @return Pvprewards
     */
    public function setRank($rank)
    {
        $this->rank = $rank;

        return $this;
    }

    /**
     * Get rank
     *
     * @return integer
     */
    public function getRank()
    {
        return $this->rank;
    }
}
