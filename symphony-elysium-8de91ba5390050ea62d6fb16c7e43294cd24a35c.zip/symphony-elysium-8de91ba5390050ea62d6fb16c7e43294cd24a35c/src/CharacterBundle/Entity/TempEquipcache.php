<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TempEquipcache
 *
 * @ORM\Table(name="temp_equipcache")
 * @ORM\Entity
 */
class TempEquipcache
{
    /**
     * @var integer
     *
     * @ORM\Column(name="i", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $i;



    /**
     * Get i
     *
     * @return integer
     */
    public function getI()
    {
        return $this->i;
    }
}
