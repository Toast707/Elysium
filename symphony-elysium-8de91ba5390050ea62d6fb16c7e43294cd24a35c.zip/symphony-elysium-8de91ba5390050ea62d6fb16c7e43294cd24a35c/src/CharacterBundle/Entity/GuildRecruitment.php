<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GuildRecruitment
 *
 * @ORM\Table(name="guild_recruitment", uniqueConstraints={@ORM\UniqueConstraint(name="guildid", columns={"guildid"})})
 * @ORM\Entity
 */
class GuildRecruitment
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=50, nullable=false)
     */
    protected $title;

    /**
     * @var string
     *
     * @ORM\Column(name="text", type="text", length=65535, nullable=false)
     */
    protected $text;

    /**
     * @var integer
     *
     * @ORM\Column(name="druid", type="integer", nullable=false)
     */
    protected $druid;

    /**
     * @var integer
     *
     * @ORM\Column(name="hunt", type="integer", nullable=false)
     */
    protected $hunt;

    /**
     * @var integer
     *
     * @ORM\Column(name="mage", type="integer", nullable=false)
     */
    protected $mage;

    /**
     * @var integer
     *
     * @ORM\Column(name="paladin", type="integer", nullable=false)
     */
    protected $paladin;

    /**
     * @var integer
     *
     * @ORM\Column(name="priest", type="integer", nullable=false)
     */
    protected $priest;

    /**
     * @var integer
     *
     * @ORM\Column(name="rogue", type="integer", nullable=false)
     */
    protected $rogue;

    /**
     * @var integer
     *
     * @ORM\Column(name="shaman", type="integer", nullable=false)
     */
    protected $shaman;

    /**
     * @var integer
     *
     * @ORM\Column(name="warlock", type="integer", nullable=false)
     */
    protected $warlock;

    /**
     * @var integer
     *
     * @ORM\Column(name="warrior", type="integer", nullable=false)
     */
    protected $warrior;

    /**
     * @var \CharacterBundle\Entity\Guild
     *
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\Guild")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="guildid", referencedColumnName="guildid", unique=true)
     * })
     */
    protected $guildid;


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return GuildRecruitment
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set text
     *
     * @param string $text
     *
     * @return GuildRecruitment
     */
    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Get text
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * Set druid
     *
     * @param integer $druid
     *
     * @return GuildRecruitment
     */
    public function setDruid($druid)
    {
        $this->druid = $druid;

        return $this;
    }

    /**
     * Get druid
     *
     * @return integer
     */
    public function getDruid()
    {
        return $this->druid;
    }

    /**
     * Set hunt
     *
     * @param integer $hunt
     *
     * @return GuildRecruitment
     */
    public function setHunt($hunt)
    {
        $this->hunt = $hunt;

        return $this;
    }

    /**
     * Get hunt
     *
     * @return integer
     */
    public function getHunt()
    {
        return $this->hunt;
    }

    /**
     * Set mage
     *
     * @param integer $mage
     *
     * @return GuildRecruitment
     */
    public function setMage($mage)
    {
        $this->mage = $mage;

        return $this;
    }

    /**
     * Get mage
     *
     * @return integer
     */
    public function getMage()
    {
        return $this->mage;
    }

    /**
     * Set paladin
     *
     * @param integer $paladin
     *
     * @return GuildRecruitment
     */
    public function setPaladin($paladin)
    {
        $this->paladin = $paladin;

        return $this;
    }

    /**
     * Get paladin
     *
     * @return integer
     */
    public function getPaladin()
    {
        return $this->paladin;
    }

    /**
     * Set priest
     *
     * @param integer $priest
     *
     * @return GuildRecruitment
     */
    public function setPriest($priest)
    {
        $this->priest = $priest;

        return $this;
    }

    /**
     * Get priest
     *
     * @return integer
     */
    public function getPriest()
    {
        return $this->priest;
    }

    /**
     * Set rogue
     *
     * @param integer $rogue
     *
     * @return GuildRecruitment
     */
    public function setRogue($rogue)
    {
        $this->rogue = $rogue;

        return $this;
    }

    /**
     * Get rogue
     *
     * @return integer
     */
    public function getRogue()
    {
        return $this->rogue;
    }

    /**
     * Set shaman
     *
     * @param integer $shaman
     *
     * @return GuildRecruitment
     */
    public function setShaman($shaman)
    {
        $this->shaman = $shaman;

        return $this;
    }

    /**
     * Get shaman
     *
     * @return integer
     */
    public function getShaman()
    {
        return $this->shaman;
    }

    /**
     * Set warlock
     *
     * @param integer $warlock
     *
     * @return GuildRecruitment
     */
    public function setWarlock($warlock)
    {
        $this->warlock = $warlock;

        return $this;
    }

    /**
     * Get warlock
     *
     * @return integer
     */
    public function getWarlock()
    {
        return $this->warlock;
    }

    /**
     * Set warrior
     *
     * @param integer $warrior
     *
     * @return GuildRecruitment
     */
    public function setWarrior($warrior)
    {
        $this->warrior = $warrior;

        return $this;
    }

    /**
     * Get warrior
     *
     * @return integer
     */
    public function getWarrior()
    {
        return $this->warrior;
    }

    /**
     * Set guildid
     *
     * @param \CharacterBundle\Entity\Guild $guildid
     *
     * @return GuildRecruitment
     */
    public function setGuildid(\CharacterBundle\Entity\Guild $guildid = null)
    {
        $this->guildid = $guildid;

        return $this;
    }

    /**
     * Get guildid
     *
     * @return \CharacterBundle\Entity\Guild
     */
    public function getGuildid()
    {
        return $this->guildid;
    }
}
