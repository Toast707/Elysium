<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AiPlayerbotGuildNames
 *
 * @ORM\Table(name="ai_playerbot_guild_names", uniqueConstraints={@ORM\UniqueConstraint(name="name_id", columns={"name_id"}), @ORM\UniqueConstraint(name="name", columns={"name"})})
 * @ORM\Entity
 */
class AiPlayerbotGuildNames
{
    /**
     * @var integer
     *
     * @ORM\Column(name="name_id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $nameId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=24, nullable=false)
     */
    protected $name;



    /**
     * Get nameId
     *
     * @return integer
     */
    public function getNameId()
    {
        return $this->nameId;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return AiPlayerbotGuildNames
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }
}
