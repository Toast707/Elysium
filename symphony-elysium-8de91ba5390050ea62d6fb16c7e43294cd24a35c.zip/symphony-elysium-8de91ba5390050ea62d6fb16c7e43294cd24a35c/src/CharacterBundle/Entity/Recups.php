<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Recups
 *
 * @ORM\Table(name="recups")
 * @ORM\Entity
 */
class Recups
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="account", type="integer", nullable=false)
     */
    protected $account;

    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer", nullable=false)
     */
    protected $guid;

    /**
     * @var integer
     *
     * @ORM\Column(name="classe", type="integer", nullable=false)
     */
    protected $classe;

    /**
     * @var integer
     *
     * @ORM\Column(name="faction", type="integer", nullable=false)
     */
    protected $faction;

    /**
     * @var integer
     *
     * @ORM\Column(name="metier1", type="integer", nullable=false)
     */
    protected $metier1;

    /**
     * @var integer
     *
     * @ORM\Column(name="metier1_level", type="integer", nullable=false)
     */
    protected $metier1Level;

    /**
     * @var integer
     *
     * @ORM\Column(name="metier2", type="integer", nullable=false)
     */
    protected $metier2;

    /**
     * @var integer
     *
     * @ORM\Column(name="metier2_level", type="integer", nullable=false)
     */
    protected $metier2Level;

    /**
     * @var string
     *
     * @ORM\Column(name="reputs", type="text", length=65535, nullable=true)
     */
    protected $reputs;

    /**
     * @var integer
     *
     * @ORM\Column(name="phase", type="integer", nullable=false)
     */
    protected $phase = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="active", type="integer", nullable=false)
     */
    protected $active;

    /**
     * @var integer
     *
     * @ORM\Column(name="stuff", type="integer", nullable=false)
     */
    protected $stuff;

    /**
     * @var string
     *
     * @ORM\Column(name="nickfofo", type="text", length=65535, nullable=false)
     */
    protected $nickfofo;

    /**
     * @var string
     *
     * @ORM\Column(name="screenshots", type="text", length=65535, nullable=false)
     */
    protected $screenshots;

    /**
     * @var integer
     *
     * @ORM\Column(name="metier3", type="integer", nullable=false)
     */
    protected $metier3;

    /**
     * @var integer
     *
     * @ORM\Column(name="metier3_level", type="integer", nullable=false)
     */
    protected $metier3Level;

    /**
     * @var string
     *
     * @ORM\Column(name="comment", type="text", length=65535, nullable=false)
     */
    protected $comment;

    /**
     * @var string
     *
     * @ORM\Column(name="origserv", type="text", length=65535, nullable=false)
     */
    protected $origserv;

    /**
     * @var integer
     *
     * @ORM\Column(name="stufflevel", type="integer", nullable=false)
     */
    protected $stufflevel;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set account
     *
     * @param integer $account
     *
     * @return Recups
     */
    public function setAccount($account)
    {
        $this->account = $account;

        return $this;
    }

    /**
     * Get account
     *
     * @return integer
     */
    public function getAccount()
    {
        return $this->account;
    }

    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return Recups
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set classe
     *
     * @param integer $classe
     *
     * @return Recups
     */
    public function setClasse($classe)
    {
        $this->classe = $classe;

        return $this;
    }

    /**
     * Get classe
     *
     * @return integer
     */
    public function getClasse()
    {
        return $this->classe;
    }

    /**
     * Set faction
     *
     * @param integer $faction
     *
     * @return Recups
     */
    public function setFaction($faction)
    {
        $this->faction = $faction;

        return $this;
    }

    /**
     * Get faction
     *
     * @return integer
     */
    public function getFaction()
    {
        return $this->faction;
    }

    /**
     * Set metier1
     *
     * @param integer $metier1
     *
     * @return Recups
     */
    public function setMetier1($metier1)
    {
        $this->metier1 = $metier1;

        return $this;
    }

    /**
     * Get metier1
     *
     * @return integer
     */
    public function getMetier1()
    {
        return $this->metier1;
    }

    /**
     * Set metier1Level
     *
     * @param integer $metier1Level
     *
     * @return Recups
     */
    public function setMetier1Level($metier1Level)
    {
        $this->metier1Level = $metier1Level;

        return $this;
    }

    /**
     * Get metier1Level
     *
     * @return integer
     */
    public function getMetier1Level()
    {
        return $this->metier1Level;
    }

    /**
     * Set metier2
     *
     * @param integer $metier2
     *
     * @return Recups
     */
    public function setMetier2($metier2)
    {
        $this->metier2 = $metier2;

        return $this;
    }

    /**
     * Get metier2
     *
     * @return integer
     */
    public function getMetier2()
    {
        return $this->metier2;
    }

    /**
     * Set metier2Level
     *
     * @param integer $metier2Level
     *
     * @return Recups
     */
    public function setMetier2Level($metier2Level)
    {
        $this->metier2Level = $metier2Level;

        return $this;
    }

    /**
     * Get metier2Level
     *
     * @return integer
     */
    public function getMetier2Level()
    {
        return $this->metier2Level;
    }

    /**
     * Set reputs
     *
     * @param string $reputs
     *
     * @return Recups
     */
    public function setReputs($reputs)
    {
        $this->reputs = $reputs;

        return $this;
    }

    /**
     * Get reputs
     *
     * @return string
     */
    public function getReputs()
    {
        return $this->reputs;
    }

    /**
     * Set phase
     *
     * @param integer $phase
     *
     * @return Recups
     */
    public function setPhase($phase)
    {
        $this->phase = $phase;

        return $this;
    }

    /**
     * Get phase
     *
     * @return integer
     */
    public function getPhase()
    {
        return $this->phase;
    }

    /**
     * Set active
     *
     * @param integer $active
     *
     * @return Recups
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return integer
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set stuff
     *
     * @param integer $stuff
     *
     * @return Recups
     */
    public function setStuff($stuff)
    {
        $this->stuff = $stuff;

        return $this;
    }

    /**
     * Get stuff
     *
     * @return integer
     */
    public function getStuff()
    {
        return $this->stuff;
    }

    /**
     * Set nickfofo
     *
     * @param string $nickfofo
     *
     * @return Recups
     */
    public function setNickfofo($nickfofo)
    {
        $this->nickfofo = $nickfofo;

        return $this;
    }

    /**
     * Get nickfofo
     *
     * @return string
     */
    public function getNickfofo()
    {
        return $this->nickfofo;
    }

    /**
     * Set screenshots
     *
     * @param string $screenshots
     *
     * @return Recups
     */
    public function setScreenshots($screenshots)
    {
        $this->screenshots = $screenshots;

        return $this;
    }

    /**
     * Get screenshots
     *
     * @return string
     */
    public function getScreenshots()
    {
        return $this->screenshots;
    }

    /**
     * Set metier3
     *
     * @param integer $metier3
     *
     * @return Recups
     */
    public function setMetier3($metier3)
    {
        $this->metier3 = $metier3;

        return $this;
    }

    /**
     * Get metier3
     *
     * @return integer
     */
    public function getMetier3()
    {
        return $this->metier3;
    }

    /**
     * Set metier3Level
     *
     * @param integer $metier3Level
     *
     * @return Recups
     */
    public function setMetier3Level($metier3Level)
    {
        $this->metier3Level = $metier3Level;

        return $this;
    }

    /**
     * Get metier3Level
     *
     * @return integer
     */
    public function getMetier3Level()
    {
        return $this->metier3Level;
    }

    /**
     * Set comment
     *
     * @param string $comment
     *
     * @return Recups
     */
    public function setComment($comment)
    {
        $this->comment = $comment;

        return $this;
    }

    /**
     * Get comment
     *
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * Set origserv
     *
     * @param string $origserv
     *
     * @return Recups
     */
    public function setOrigserv($origserv)
    {
        $this->origserv = $origserv;

        return $this;
    }

    /**
     * Get origserv
     *
     * @return string
     */
    public function getOrigserv()
    {
        return $this->origserv;
    }

    /**
     * Set stufflevel
     *
     * @param integer $stufflevel
     *
     * @return Recups
     */
    public function setStufflevel($stufflevel)
    {
        $this->stufflevel = $stufflevel;

        return $this;
    }

    /**
     * Get stufflevel
     *
     * @return integer
     */
    public function getStufflevel()
    {
        return $this->stufflevel;
    }
}
