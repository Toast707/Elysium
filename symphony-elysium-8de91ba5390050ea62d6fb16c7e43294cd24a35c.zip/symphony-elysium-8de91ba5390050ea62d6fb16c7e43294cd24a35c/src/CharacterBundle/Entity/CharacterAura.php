<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterAura
 *
 * @ORM\Table(name="character_aura")
 * @ORM\Entity
 */
class CharacterAura
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $guid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="spell", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $spell = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="effect_index", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $effectIndex = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="caster_guid", type="bigint", nullable=false)
     */
    protected $casterGuid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="stackcount", type="integer", nullable=false)
     */
    protected $stackcount = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="amount", type="integer", nullable=false)
     */
    protected $amount = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxduration", type="integer", nullable=false)
     */
    protected $maxduration = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="remaintime", type="integer", nullable=false)
     */
    protected $remaintime = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="remaincharges", type="integer", nullable=false)
     */
    protected $remaincharges = '0';



    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return CharacterAura
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set spell
     *
     * @param integer $spell
     *
     * @return CharacterAura
     */
    public function setSpell($spell)
    {
        $this->spell = $spell;

        return $this;
    }

    /**
     * Get spell
     *
     * @return integer
     */
    public function getSpell()
    {
        return $this->spell;
    }

    /**
     * Set effectIndex
     *
     * @param integer $effectIndex
     *
     * @return CharacterAura
     */
    public function setEffectIndex($effectIndex)
    {
        $this->effectIndex = $effectIndex;

        return $this;
    }

    /**
     * Get effectIndex
     *
     * @return integer
     */
    public function getEffectIndex()
    {
        return $this->effectIndex;
    }

    /**
     * Set casterGuid
     *
     * @param integer $casterGuid
     *
     * @return CharacterAura
     */
    public function setCasterGuid($casterGuid)
    {
        $this->casterGuid = $casterGuid;

        return $this;
    }

    /**
     * Get casterGuid
     *
     * @return integer
     */
    public function getCasterGuid()
    {
        return $this->casterGuid;
    }

    /**
     * Set stackcount
     *
     * @param integer $stackcount
     *
     * @return CharacterAura
     */
    public function setStackcount($stackcount)
    {
        $this->stackcount = $stackcount;

        return $this;
    }

    /**
     * Get stackcount
     *
     * @return integer
     */
    public function getStackcount()
    {
        return $this->stackcount;
    }

    /**
     * Set amount
     *
     * @param integer $amount
     *
     * @return CharacterAura
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return integer
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set maxduration
     *
     * @param integer $maxduration
     *
     * @return CharacterAura
     */
    public function setMaxduration($maxduration)
    {
        $this->maxduration = $maxduration;

        return $this;
    }

    /**
     * Get maxduration
     *
     * @return integer
     */
    public function getMaxduration()
    {
        return $this->maxduration;
    }

    /**
     * Set remaintime
     *
     * @param integer $remaintime
     *
     * @return CharacterAura
     */
    public function setRemaintime($remaintime)
    {
        $this->remaintime = $remaintime;

        return $this;
    }

    /**
     * Get remaintime
     *
     * @return integer
     */
    public function getRemaintime()
    {
        return $this->remaintime;
    }

    /**
     * Set remaincharges
     *
     * @param integer $remaincharges
     *
     * @return CharacterAura
     */
    public function setRemaincharges($remaincharges)
    {
        $this->remaincharges = $remaincharges;

        return $this;
    }

    /**
     * Get remaincharges
     *
     * @return integer
     */
    public function getRemaincharges()
    {
        return $this->remaincharges;
    }
}
