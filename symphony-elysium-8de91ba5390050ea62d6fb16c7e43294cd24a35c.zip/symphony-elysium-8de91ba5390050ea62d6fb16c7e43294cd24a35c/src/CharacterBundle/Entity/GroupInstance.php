<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GroupInstance
 *
 * @ORM\Table(name="group_instance", indexes={@ORM\Index(name="instance", columns={"instance"})})
 * @ORM\Entity
 */
class GroupInstance
{
    /**
     * @var integer
     *
     * @ORM\Column(name="instance", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $instance = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="leaderGuid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $leaderguid = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="permanent", type="boolean", nullable=false)
     */
    protected $permanent = '0';



    /**
     * Set instance
     *
     * @param integer $instance
     *
     * @return GroupInstance
     */
    public function setInstance($instance)
    {
        $this->instance = $instance;

        return $this;
    }

    /**
     * Get instance
     *
     * @return integer
     */
    public function getInstance()
    {
        return $this->instance;
    }

    /**
     * Set leaderguid
     *
     * @param integer $leaderguid
     *
     * @return GroupInstance
     */
    public function setLeaderguid($leaderguid)
    {
        $this->leaderguid = $leaderguid;

        return $this;
    }

    /**
     * Get leaderguid
     *
     * @return integer
     */
    public function getLeaderguid()
    {
        return $this->leaderguid;
    }

    /**
     * Set permanent
     *
     * @param boolean $permanent
     *
     * @return GroupInstance
     */
    public function setPermanent($permanent)
    {
        $this->permanent = $permanent;

        return $this;
    }

    /**
     * Get permanent
     *
     * @return boolean
     */
    public function getPermanent()
    {
        return $this->permanent;
    }
}
