<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Auctionhousebot
 *
 * @ORM\Table(name="auctionhousebot")
 * @ORM\Entity
 */
class Auctionhousebot
{
    /**
     * @var integer
     *
     * @ORM\Column(name="auctionhouse", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $auctionhouse = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=25, nullable=true)
     */
    protected $name;

    /**
     * @var integer
     *
     * @ORM\Column(name="minitems", type="integer", nullable=true)
     */
    protected $minitems = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxitems", type="integer", nullable=true)
     */
    protected $maxitems = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="mintime", type="integer", nullable=true)
     */
    protected $mintime = '8';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxtime", type="integer", nullable=true)
     */
    protected $maxtime = '24';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentwhitetradegoods", type="integer", nullable=true)
     */
    protected $percentwhitetradegoods = '27';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentgreentradegoods", type="integer", nullable=true)
     */
    protected $percentgreentradegoods = '12';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentbluetradegoods", type="integer", nullable=true)
     */
    protected $percentbluetradegoods = '10';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentpurpletradegoods", type="integer", nullable=true)
     */
    protected $percentpurpletradegoods = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentwhiteitems", type="integer", nullable=true)
     */
    protected $percentwhiteitems = '10';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentgreenitems", type="integer", nullable=true)
     */
    protected $percentgreenitems = '30';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentblueitems", type="integer", nullable=true)
     */
    protected $percentblueitems = '8';

    /**
     * @var integer
     *
     * @ORM\Column(name="percentpurpleitems", type="integer", nullable=true)
     */
    protected $percentpurpleitems = '2';

    /**
     * @var integer
     *
     * @ORM\Column(name="minpricewhite", type="integer", nullable=true)
     */
    protected $minpricewhite = '150';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxpricewhite", type="integer", nullable=true)
     */
    protected $maxpricewhite = '250';

    /**
     * @var integer
     *
     * @ORM\Column(name="minpricegreen", type="integer", nullable=true)
     */
    protected $minpricegreen = '800';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxpricegreen", type="integer", nullable=true)
     */
    protected $maxpricegreen = '1400';

    /**
     * @var integer
     *
     * @ORM\Column(name="minpriceblue", type="integer", nullable=true)
     */
    protected $minpriceblue = '1250';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxpriceblue", type="integer", nullable=true)
     */
    protected $maxpriceblue = '1750';

    /**
     * @var integer
     *
     * @ORM\Column(name="minpricepurple", type="integer", nullable=true)
     */
    protected $minpricepurple = '2250';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxpricepurple", type="integer", nullable=true)
     */
    protected $maxpricepurple = '4550';

    /**
     * @var integer
     *
     * @ORM\Column(name="minbidpricewhite", type="integer", nullable=true)
     */
    protected $minbidpricewhite = '70';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxbidpricewhite", type="integer", nullable=true)
     */
    protected $maxbidpricewhite = '100';

    /**
     * @var integer
     *
     * @ORM\Column(name="minbidpricegreen", type="integer", nullable=true)
     */
    protected $minbidpricegreen = '80';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxbidpricegreen", type="integer", nullable=true)
     */
    protected $maxbidpricegreen = '100';

    /**
     * @var integer
     *
     * @ORM\Column(name="minbidpriceblue", type="integer", nullable=true)
     */
    protected $minbidpriceblue = '75';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxbidpriceblue", type="integer", nullable=true)
     */
    protected $maxbidpriceblue = '100';

    /**
     * @var integer
     *
     * @ORM\Column(name="minbidpricepurple", type="integer", nullable=true)
     */
    protected $minbidpricepurple = '80';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxbidpricepurple", type="integer", nullable=true)
     */
    protected $maxbidpricepurple = '100';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxstackwhite", type="integer", nullable=true)
     */
    protected $maxstackwhite = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxstackgreen", type="integer", nullable=true)
     */
    protected $maxstackgreen = '3';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxstackblue", type="integer", nullable=true)
     */
    protected $maxstackblue = '2';

    /**
     * @var integer
     *
     * @ORM\Column(name="maxstackpurple", type="integer", nullable=true)
     */
    protected $maxstackpurple = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerpricegrey", type="integer", nullable=true)
     */
    protected $buyerpricegrey = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerpricewhite", type="integer", nullable=true)
     */
    protected $buyerpricewhite = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerpricegreen", type="integer", nullable=true)
     */
    protected $buyerpricegreen = '5';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerpriceblue", type="integer", nullable=true)
     */
    protected $buyerpriceblue = '12';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerpricepurple", type="integer", nullable=true)
     */
    protected $buyerpricepurple = '15';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerbiddinginterval", type="integer", nullable=true)
     */
    protected $buyerbiddinginterval = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="buyerbidsperinterval", type="integer", nullable=true)
     */
    protected $buyerbidsperinterval = '1';



    /**
     * Get auctionhouse
     *
     * @return integer
     */
    public function getAuctionhouse()
    {
        return $this->auctionhouse;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Auctionhousebot
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set minitems
     *
     * @param integer $minitems
     *
     * @return Auctionhousebot
     */
    public function setMinitems($minitems)
    {
        $this->minitems = $minitems;

        return $this;
    }

    /**
     * Get minitems
     *
     * @return integer
     */
    public function getMinitems()
    {
        return $this->minitems;
    }

    /**
     * Set maxitems
     *
     * @param integer $maxitems
     *
     * @return Auctionhousebot
     */
    public function setMaxitems($maxitems)
    {
        $this->maxitems = $maxitems;

        return $this;
    }

    /**
     * Get maxitems
     *
     * @return integer
     */
    public function getMaxitems()
    {
        return $this->maxitems;
    }

    /**
     * Set mintime
     *
     * @param integer $mintime
     *
     * @return Auctionhousebot
     */
    public function setMintime($mintime)
    {
        $this->mintime = $mintime;

        return $this;
    }

    /**
     * Get mintime
     *
     * @return integer
     */
    public function getMintime()
    {
        return $this->mintime;
    }

    /**
     * Set maxtime
     *
     * @param integer $maxtime
     *
     * @return Auctionhousebot
     */
    public function setMaxtime($maxtime)
    {
        $this->maxtime = $maxtime;

        return $this;
    }

    /**
     * Get maxtime
     *
     * @return integer
     */
    public function getMaxtime()
    {
        return $this->maxtime;
    }

    /**
     * Set percentwhitetradegoods
     *
     * @param integer $percentwhitetradegoods
     *
     * @return Auctionhousebot
     */
    public function setPercentwhitetradegoods($percentwhitetradegoods)
    {
        $this->percentwhitetradegoods = $percentwhitetradegoods;

        return $this;
    }

    /**
     * Get percentwhitetradegoods
     *
     * @return integer
     */
    public function getPercentwhitetradegoods()
    {
        return $this->percentwhitetradegoods;
    }

    /**
     * Set percentgreentradegoods
     *
     * @param integer $percentgreentradegoods
     *
     * @return Auctionhousebot
     */
    public function setPercentgreentradegoods($percentgreentradegoods)
    {
        $this->percentgreentradegoods = $percentgreentradegoods;

        return $this;
    }

    /**
     * Get percentgreentradegoods
     *
     * @return integer
     */
    public function getPercentgreentradegoods()
    {
        return $this->percentgreentradegoods;
    }

    /**
     * Set percentbluetradegoods
     *
     * @param integer $percentbluetradegoods
     *
     * @return Auctionhousebot
     */
    public function setPercentbluetradegoods($percentbluetradegoods)
    {
        $this->percentbluetradegoods = $percentbluetradegoods;

        return $this;
    }

    /**
     * Get percentbluetradegoods
     *
     * @return integer
     */
    public function getPercentbluetradegoods()
    {
        return $this->percentbluetradegoods;
    }

    /**
     * Set percentpurpletradegoods
     *
     * @param integer $percentpurpletradegoods
     *
     * @return Auctionhousebot
     */
    public function setPercentpurpletradegoods($percentpurpletradegoods)
    {
        $this->percentpurpletradegoods = $percentpurpletradegoods;

        return $this;
    }

    /**
     * Get percentpurpletradegoods
     *
     * @return integer
     */
    public function getPercentpurpletradegoods()
    {
        return $this->percentpurpletradegoods;
    }

    /**
     * Set percentwhiteitems
     *
     * @param integer $percentwhiteitems
     *
     * @return Auctionhousebot
     */
    public function setPercentwhiteitems($percentwhiteitems)
    {
        $this->percentwhiteitems = $percentwhiteitems;

        return $this;
    }

    /**
     * Get percentwhiteitems
     *
     * @return integer
     */
    public function getPercentwhiteitems()
    {
        return $this->percentwhiteitems;
    }

    /**
     * Set percentgreenitems
     *
     * @param integer $percentgreenitems
     *
     * @return Auctionhousebot
     */
    public function setPercentgreenitems($percentgreenitems)
    {
        $this->percentgreenitems = $percentgreenitems;

        return $this;
    }

    /**
     * Get percentgreenitems
     *
     * @return integer
     */
    public function getPercentgreenitems()
    {
        return $this->percentgreenitems;
    }

    /**
     * Set percentblueitems
     *
     * @param integer $percentblueitems
     *
     * @return Auctionhousebot
     */
    public function setPercentblueitems($percentblueitems)
    {
        $this->percentblueitems = $percentblueitems;

        return $this;
    }

    /**
     * Get percentblueitems
     *
     * @return integer
     */
    public function getPercentblueitems()
    {
        return $this->percentblueitems;
    }

    /**
     * Set percentpurpleitems
     *
     * @param integer $percentpurpleitems
     *
     * @return Auctionhousebot
     */
    public function setPercentpurpleitems($percentpurpleitems)
    {
        $this->percentpurpleitems = $percentpurpleitems;

        return $this;
    }

    /**
     * Get percentpurpleitems
     *
     * @return integer
     */
    public function getPercentpurpleitems()
    {
        return $this->percentpurpleitems;
    }

    /**
     * Set minpricewhite
     *
     * @param integer $minpricewhite
     *
     * @return Auctionhousebot
     */
    public function setMinpricewhite($minpricewhite)
    {
        $this->minpricewhite = $minpricewhite;

        return $this;
    }

    /**
     * Get minpricewhite
     *
     * @return integer
     */
    public function getMinpricewhite()
    {
        return $this->minpricewhite;
    }

    /**
     * Set maxpricewhite
     *
     * @param integer $maxpricewhite
     *
     * @return Auctionhousebot
     */
    public function setMaxpricewhite($maxpricewhite)
    {
        $this->maxpricewhite = $maxpricewhite;

        return $this;
    }

    /**
     * Get maxpricewhite
     *
     * @return integer
     */
    public function getMaxpricewhite()
    {
        return $this->maxpricewhite;
    }

    /**
     * Set minpricegreen
     *
     * @param integer $minpricegreen
     *
     * @return Auctionhousebot
     */
    public function setMinpricegreen($minpricegreen)
    {
        $this->minpricegreen = $minpricegreen;

        return $this;
    }

    /**
     * Get minpricegreen
     *
     * @return integer
     */
    public function getMinpricegreen()
    {
        return $this->minpricegreen;
    }

    /**
     * Set maxpricegreen
     *
     * @param integer $maxpricegreen
     *
     * @return Auctionhousebot
     */
    public function setMaxpricegreen($maxpricegreen)
    {
        $this->maxpricegreen = $maxpricegreen;

        return $this;
    }

    /**
     * Get maxpricegreen
     *
     * @return integer
     */
    public function getMaxpricegreen()
    {
        return $this->maxpricegreen;
    }

    /**
     * Set minpriceblue
     *
     * @param integer $minpriceblue
     *
     * @return Auctionhousebot
     */
    public function setMinpriceblue($minpriceblue)
    {
        $this->minpriceblue = $minpriceblue;

        return $this;
    }

    /**
     * Get minpriceblue
     *
     * @return integer
     */
    public function getMinpriceblue()
    {
        return $this->minpriceblue;
    }

    /**
     * Set maxpriceblue
     *
     * @param integer $maxpriceblue
     *
     * @return Auctionhousebot
     */
    public function setMaxpriceblue($maxpriceblue)
    {
        $this->maxpriceblue = $maxpriceblue;

        return $this;
    }

    /**
     * Get maxpriceblue
     *
     * @return integer
     */
    public function getMaxpriceblue()
    {
        return $this->maxpriceblue;
    }

    /**
     * Set minpricepurple
     *
     * @param integer $minpricepurple
     *
     * @return Auctionhousebot
     */
    public function setMinpricepurple($minpricepurple)
    {
        $this->minpricepurple = $minpricepurple;

        return $this;
    }

    /**
     * Get minpricepurple
     *
     * @return integer
     */
    public function getMinpricepurple()
    {
        return $this->minpricepurple;
    }

    /**
     * Set maxpricepurple
     *
     * @param integer $maxpricepurple
     *
     * @return Auctionhousebot
     */
    public function setMaxpricepurple($maxpricepurple)
    {
        $this->maxpricepurple = $maxpricepurple;

        return $this;
    }

    /**
     * Get maxpricepurple
     *
     * @return integer
     */
    public function getMaxpricepurple()
    {
        return $this->maxpricepurple;
    }

    /**
     * Set minbidpricewhite
     *
     * @param integer $minbidpricewhite
     *
     * @return Auctionhousebot
     */
    public function setMinbidpricewhite($minbidpricewhite)
    {
        $this->minbidpricewhite = $minbidpricewhite;

        return $this;
    }

    /**
     * Get minbidpricewhite
     *
     * @return integer
     */
    public function getMinbidpricewhite()
    {
        return $this->minbidpricewhite;
    }

    /**
     * Set maxbidpricewhite
     *
     * @param integer $maxbidpricewhite
     *
     * @return Auctionhousebot
     */
    public function setMaxbidpricewhite($maxbidpricewhite)
    {
        $this->maxbidpricewhite = $maxbidpricewhite;

        return $this;
    }

    /**
     * Get maxbidpricewhite
     *
     * @return integer
     */
    public function getMaxbidpricewhite()
    {
        return $this->maxbidpricewhite;
    }

    /**
     * Set minbidpricegreen
     *
     * @param integer $minbidpricegreen
     *
     * @return Auctionhousebot
     */
    public function setMinbidpricegreen($minbidpricegreen)
    {
        $this->minbidpricegreen = $minbidpricegreen;

        return $this;
    }

    /**
     * Get minbidpricegreen
     *
     * @return integer
     */
    public function getMinbidpricegreen()
    {
        return $this->minbidpricegreen;
    }

    /**
     * Set maxbidpricegreen
     *
     * @param integer $maxbidpricegreen
     *
     * @return Auctionhousebot
     */
    public function setMaxbidpricegreen($maxbidpricegreen)
    {
        $this->maxbidpricegreen = $maxbidpricegreen;

        return $this;
    }

    /**
     * Get maxbidpricegreen
     *
     * @return integer
     */
    public function getMaxbidpricegreen()
    {
        return $this->maxbidpricegreen;
    }

    /**
     * Set minbidpriceblue
     *
     * @param integer $minbidpriceblue
     *
     * @return Auctionhousebot
     */
    public function setMinbidpriceblue($minbidpriceblue)
    {
        $this->minbidpriceblue = $minbidpriceblue;

        return $this;
    }

    /**
     * Get minbidpriceblue
     *
     * @return integer
     */
    public function getMinbidpriceblue()
    {
        return $this->minbidpriceblue;
    }

    /**
     * Set maxbidpriceblue
     *
     * @param integer $maxbidpriceblue
     *
     * @return Auctionhousebot
     */
    public function setMaxbidpriceblue($maxbidpriceblue)
    {
        $this->maxbidpriceblue = $maxbidpriceblue;

        return $this;
    }

    /**
     * Get maxbidpriceblue
     *
     * @return integer
     */
    public function getMaxbidpriceblue()
    {
        return $this->maxbidpriceblue;
    }

    /**
     * Set minbidpricepurple
     *
     * @param integer $minbidpricepurple
     *
     * @return Auctionhousebot
     */
    public function setMinbidpricepurple($minbidpricepurple)
    {
        $this->minbidpricepurple = $minbidpricepurple;

        return $this;
    }

    /**
     * Get minbidpricepurple
     *
     * @return integer
     */
    public function getMinbidpricepurple()
    {
        return $this->minbidpricepurple;
    }

    /**
     * Set maxbidpricepurple
     *
     * @param integer $maxbidpricepurple
     *
     * @return Auctionhousebot
     */
    public function setMaxbidpricepurple($maxbidpricepurple)
    {
        $this->maxbidpricepurple = $maxbidpricepurple;

        return $this;
    }

    /**
     * Get maxbidpricepurple
     *
     * @return integer
     */
    public function getMaxbidpricepurple()
    {
        return $this->maxbidpricepurple;
    }

    /**
     * Set maxstackwhite
     *
     * @param integer $maxstackwhite
     *
     * @return Auctionhousebot
     */
    public function setMaxstackwhite($maxstackwhite)
    {
        $this->maxstackwhite = $maxstackwhite;

        return $this;
    }

    /**
     * Get maxstackwhite
     *
     * @return integer
     */
    public function getMaxstackwhite()
    {
        return $this->maxstackwhite;
    }

    /**
     * Set maxstackgreen
     *
     * @param integer $maxstackgreen
     *
     * @return Auctionhousebot
     */
    public function setMaxstackgreen($maxstackgreen)
    {
        $this->maxstackgreen = $maxstackgreen;

        return $this;
    }

    /**
     * Get maxstackgreen
     *
     * @return integer
     */
    public function getMaxstackgreen()
    {
        return $this->maxstackgreen;
    }

    /**
     * Set maxstackblue
     *
     * @param integer $maxstackblue
     *
     * @return Auctionhousebot
     */
    public function setMaxstackblue($maxstackblue)
    {
        $this->maxstackblue = $maxstackblue;

        return $this;
    }

    /**
     * Get maxstackblue
     *
     * @return integer
     */
    public function getMaxstackblue()
    {
        return $this->maxstackblue;
    }

    /**
     * Set maxstackpurple
     *
     * @param integer $maxstackpurple
     *
     * @return Auctionhousebot
     */
    public function setMaxstackpurple($maxstackpurple)
    {
        $this->maxstackpurple = $maxstackpurple;

        return $this;
    }

    /**
     * Get maxstackpurple
     *
     * @return integer
     */
    public function getMaxstackpurple()
    {
        return $this->maxstackpurple;
    }

    /**
     * Set buyerpricegrey
     *
     * @param integer $buyerpricegrey
     *
     * @return Auctionhousebot
     */
    public function setBuyerpricegrey($buyerpricegrey)
    {
        $this->buyerpricegrey = $buyerpricegrey;

        return $this;
    }

    /**
     * Get buyerpricegrey
     *
     * @return integer
     */
    public function getBuyerpricegrey()
    {
        return $this->buyerpricegrey;
    }

    /**
     * Set buyerpricewhite
     *
     * @param integer $buyerpricewhite
     *
     * @return Auctionhousebot
     */
    public function setBuyerpricewhite($buyerpricewhite)
    {
        $this->buyerpricewhite = $buyerpricewhite;

        return $this;
    }

    /**
     * Get buyerpricewhite
     *
     * @return integer
     */
    public function getBuyerpricewhite()
    {
        return $this->buyerpricewhite;
    }

    /**
     * Set buyerpricegreen
     *
     * @param integer $buyerpricegreen
     *
     * @return Auctionhousebot
     */
    public function setBuyerpricegreen($buyerpricegreen)
    {
        $this->buyerpricegreen = $buyerpricegreen;

        return $this;
    }

    /**
     * Get buyerpricegreen
     *
     * @return integer
     */
    public function getBuyerpricegreen()
    {
        return $this->buyerpricegreen;
    }

    /**
     * Set buyerpriceblue
     *
     * @param integer $buyerpriceblue
     *
     * @return Auctionhousebot
     */
    public function setBuyerpriceblue($buyerpriceblue)
    {
        $this->buyerpriceblue = $buyerpriceblue;

        return $this;
    }

    /**
     * Get buyerpriceblue
     *
     * @return integer
     */
    public function getBuyerpriceblue()
    {
        return $this->buyerpriceblue;
    }

    /**
     * Set buyerpricepurple
     *
     * @param integer $buyerpricepurple
     *
     * @return Auctionhousebot
     */
    public function setBuyerpricepurple($buyerpricepurple)
    {
        $this->buyerpricepurple = $buyerpricepurple;

        return $this;
    }

    /**
     * Get buyerpricepurple
     *
     * @return integer
     */
    public function getBuyerpricepurple()
    {
        return $this->buyerpricepurple;
    }

    /**
     * Set buyerbiddinginterval
     *
     * @param integer $buyerbiddinginterval
     *
     * @return Auctionhousebot
     */
    public function setBuyerbiddinginterval($buyerbiddinginterval)
    {
        $this->buyerbiddinginterval = $buyerbiddinginterval;

        return $this;
    }

    /**
     * Get buyerbiddinginterval
     *
     * @return integer
     */
    public function getBuyerbiddinginterval()
    {
        return $this->buyerbiddinginterval;
    }

    /**
     * Set buyerbidsperinterval
     *
     * @param integer $buyerbidsperinterval
     *
     * @return Auctionhousebot
     */
    public function setBuyerbidsperinterval($buyerbidsperinterval)
    {
        $this->buyerbidsperinterval = $buyerbidsperinterval;

        return $this;
    }

    /**
     * Get buyerbidsperinterval
     *
     * @return integer
     */
    public function getBuyerbidsperinterval()
    {
        return $this->buyerbidsperinterval;
    }
}
