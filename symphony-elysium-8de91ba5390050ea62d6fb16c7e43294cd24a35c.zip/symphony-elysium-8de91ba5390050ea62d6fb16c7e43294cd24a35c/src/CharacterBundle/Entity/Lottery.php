<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Lottery
 *
 * @ORM\Table(name="lottery")
 * @ORM\Entity
 */
class Lottery
{
    /**
     * @var integer
     *
     * @ORM\Column(name="accountid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $accountid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer", nullable=false)
     */
    protected $guid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="registertime", type="bigint", nullable=false)
     */
    protected $registertime = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="faction", type="integer", nullable=false)
     */
    protected $faction = '0';



    /**
     * Get accountid
     *
     * @return integer
     */
    public function getAccountid()
    {
        return $this->accountid;
    }

    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return Lottery
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set registertime
     *
     * @param integer $registertime
     *
     * @return Lottery
     */
    public function setRegistertime($registertime)
    {
        $this->registertime = $registertime;

        return $this;
    }

    /**
     * Get registertime
     *
     * @return integer
     */
    public function getRegistertime()
    {
        return $this->registertime;
    }

    /**
     * Set faction
     *
     * @param integer $faction
     *
     * @return Lottery
     */
    public function setFaction($faction)
    {
        $this->faction = $faction;

        return $this;
    }

    /**
     * Get faction
     *
     * @return integer
     */
    public function getFaction()
    {
        return $this->faction;
    }
}
