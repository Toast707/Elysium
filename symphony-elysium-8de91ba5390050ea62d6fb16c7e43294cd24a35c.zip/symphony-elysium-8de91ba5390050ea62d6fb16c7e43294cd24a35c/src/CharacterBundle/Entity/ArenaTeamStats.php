<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ArenaTeamStats
 *
 * @ORM\Table(name="arena_team_stats")
 * @ORM\Entity
 */
class ArenaTeamStats
{
    /**
     * @var integer
     *
     * @ORM\Id
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\ArenaTeam", inversedBy="stats")
     * @ORM\JoinColumn(name="arenateamid", referencedColumnName="arenateamid")
     */
    protected $arenateamid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="rating", type="integer", nullable=false)
     */
    protected $rating = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="games", type="integer", nullable=false)
     */
    protected $games = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="wins", type="integer", nullable=false)
     */
    protected $wins = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="played", type="integer", nullable=false)
     */
    protected $played = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="wins2", type="integer", nullable=false)
     */
    protected $wins2 = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="rank", type="integer", nullable=false)
     */
    protected $rank = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="nonplayedweeks", type="integer", nullable=false)
     */
    protected $nonplayedweeks = '0';



    /**
     * Get arenateamid
     *
     * @return integer
     */
    public function getArenateamid()
    {
        return $this->arenateamid;
    }

    /**
     * Set rating
     *
     * @param integer $rating
     *
     * @return ArenaTeamStats
     */
    public function setRating($rating)
    {
        $this->rating = $rating;

        return $this;
    }

    /**
     * Get rating
     *
     * @return integer
     */
    public function getRating()
    {
        return $this->rating;
    }

    /**
     * Set games
     *
     * @param integer $games
     *
     * @return ArenaTeamStats
     */
    public function setGames($games)
    {
        $this->games = $games;

        return $this;
    }

    /**
     * Get games
     *
     * @return integer
     */
    public function getGames()
    {
        return $this->games;
    }

    /**
     * Set wins
     *
     * @param integer $wins
     *
     * @return ArenaTeamStats
     */
    public function setWins($wins)
    {
        $this->wins = $wins;

        return $this;
    }

    /**
     * Get wins
     *
     * @return integer
     */
    public function getWins()
    {
        return $this->wins;
    }

    /**
     * Set played
     *
     * @param integer $played
     *
     * @return ArenaTeamStats
     */
    public function setPlayed($played)
    {
        $this->played = $played;

        return $this;
    }

    /**
     * Get played
     *
     * @return integer
     */
    public function getPlayed()
    {
        return $this->played;
    }

    /**
     * Set wins2
     *
     * @param integer $wins2
     *
     * @return ArenaTeamStats
     */
    public function setWins2($wins2)
    {
        $this->wins2 = $wins2;

        return $this;
    }

    /**
     * Get wins2
     *
     * @return integer
     */
    public function getWins2()
    {
        return $this->wins2;
    }

    /**
     * Set rank
     *
     * @param integer $rank
     *
     * @return ArenaTeamStats
     */
    public function setRank($rank)
    {
        $this->rank = $rank;

        return $this;
    }

    /**
     * Get rank
     *
     * @return integer
     */
    public function getRank()
    {
        return $this->rank;
    }

    /**
     * Set nonplayedweeks
     *
     * @param integer $nonplayedweeks
     *
     * @return ArenaTeamStats
     */
    public function setNonplayedweeks($nonplayedweeks)
    {
        $this->nonplayedweeks = $nonplayedweeks;

        return $this;
    }

    /**
     * Get nonplayedweeks
     *
     * @return integer
     */
    public function getNonplayedweeks()
    {
        return $this->nonplayedweeks;
    }
}
