<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GuildScreenshot
 *
 * @ORM\Table(name="guild_screenshot", indexes={@ORM\Index(name="guildid", columns={"guildid"})})
 * @ORM\Entity
 */
class GuildScreenshot
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="screenshot", type="string", length=100, nullable=false)
     */
    protected $screenshot;

    /**
     * @var string
     *
     * @ORM\Column(name="label", type="string", length=50, nullable=false)
     */
    protected $label;

    /**
     * @var \CharacterBundle\Entity\Guild
     *
     * @ORM\ManyToOne(targetEntity="CharacterBundle\Entity\Guild")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="guildid", referencedColumnName="guildid")
     * })
     */
    protected $guildid;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set screenshot
     *
     * @param string $screenshot
     *
     * @return GuildScreenshot
     */
    public function setScreenshot($screenshot)
    {
        $this->screenshot = $screenshot;

        return $this;
    }

    /**
     * Get screenshot
     *
     * @return string
     */
    public function getScreenshot()
    {
        return $this->screenshot;
    }

    /**
     * Set label
     *
     * @param string $label
     *
     * @return GuildScreenshot
     */
    public function setLabel($label)
    {
        $this->label = $label;

        return $this;
    }

    /**
     * Get label
     *
     * @return string
     */
    public function getLabel()
    {
        return $this->label;
    }

    /**
     * Set guildid
     *
     * @param \CharacterBundle\Entity\Guild $guildid
     *
     * @return GuildScreenshot
     */
    public function setGuildid(\CharacterBundle\Entity\Guild $guildid = null)
    {
        $this->guildid = $guildid;

        return $this;
    }

    /**
     * Get guildid
     *
     * @return \CharacterBundle\Entity\Guild
     */
    public function getGuildid()
    {
        return $this->guildid;
    }
}
