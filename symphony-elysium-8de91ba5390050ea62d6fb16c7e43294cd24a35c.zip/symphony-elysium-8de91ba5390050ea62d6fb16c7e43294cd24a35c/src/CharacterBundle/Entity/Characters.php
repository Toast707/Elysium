<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Characters
 *
 * @ORM\Table(name="characters", indexes={@ORM\Index(name="idx_account", columns={"account"}), @ORM\Index(name="idx_online", columns={"online"}), @ORM\Index(name="idx_name", columns={"name"})})
 * @ORM\Entity(repositoryClass="CharacterBundle\Repository\CharactersRepository")
 */
class Characters implements \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $guid;

    /**
     * @var integer
     *
     * @ORM\Column(name="account", type="integer")
     */
    protected $account;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=12, nullable=false)
     */
    protected $name;

    /**
     * @var boolean
     *
     * @ORM\Column(name="race", type="integer", nullable=false)
     */
    protected $race;

    /**
     * @var boolean
     *
     * @ORM\Column(name="class", type="integer", nullable=false)
     */
    protected $class;

    /**
     * @var boolean
     *
     * @ORM\Column(name="gender", type="boolean", nullable=false)
     */
    protected $gender;

    /**
     * @var boolean
     *
     * @ORM\Column(name="level", type="integer", nullable=false)
     */
    protected $level;

    /**
     * @var integer
     *
     * @ORM\Column(name="xp", type="integer", nullable=false)
     */
    protected $xp;

    /**
     * @var integer
     *
     * @ORM\Column(name="money", type="integer", nullable=false)
     */
    protected $money;

    /**
     * @var integer
     *
     * @ORM\Column(name="playerBytes", type="integer", nullable=false)
     */
    protected $playerbytes;

    /**
     * @var integer
     *
     * @ORM\Column(name="playerBytes2", type="integer", nullable=false)
     */
    protected $playerbytes2;

    /**
     * @var integer
     *
     * @ORM\Column(name="playerFlags", type="integer", nullable=false)
     */
    protected $playerflags;

    /**
     * @var float
     *
     * @ORM\Column(name="position_x", type="float", precision=10, scale=0, nullable=false)
     */
    protected $positionX;

    /**
     * @var float
     *
     * @ORM\Column(name="position_y", type="float", precision=10, scale=0, nullable=false)
     */
    protected $positionY;

    /**
     * @var float
     *
     * @ORM\Column(name="position_z", type="float", precision=10, scale=0, nullable=false)
     */
    protected $positionZ;

    /**
     * @var integer
     *
     * @ORM\Column(name="map", type="integer", nullable=false)
     */
    protected $map;

    /**
     * @var float
     *
     * @ORM\Column(name="orientation", type="float", precision=10, scale=0, nullable=false)
     */
    protected $orientation;

    /**
     * @var string
     *
     * @ORM\Column(name="taximask", type="text", nullable=true)
     */
    protected $taximask;

    /**
     * @var boolean
     *
     * @ORM\Column(name="online", type="boolean", nullable=false)
     */
    protected $online;

    /**
     * @var boolean
     *
     * @ORM\Column(name="cinematic", type="boolean", nullable=false)
     */
    protected $cinematic;

    /**
     * @var integer
     *
     * @ORM\Column(name="totaltime", type="integer", nullable=false)
     */
    protected $totaltime;

    /**
     * @var integer
     *
     * @ORM\Column(name="leveltime", type="integer", nullable=false)
     */
    protected $leveltime;

    /**
     * @var integer
     *
     * @ORM\Column(name="logout_time", type="bigint", nullable=false)
     */
    protected $logoutTime;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_logout_resting", type="boolean", nullable=false)
     */
    protected $isLogoutResting;

    /**
     * @var float
     *
     * @ORM\Column(name="rest_bonus", type="float", precision=10, scale=0, nullable=false)
     */
    protected $restBonus;

    /**
     * @var integer
     *
     * @ORM\Column(name="resettalents_cost", type="integer", nullable=false)
     */
    protected $resettalentsCost;

    /**
     * @var integer
     *
     * @ORM\Column(name="resettalents_time", type="bigint", nullable=false)
     */
    protected $resettalentsTime;

    /**
     * @var float
     *
     * @ORM\Column(name="trans_x", type="float", precision=10, scale=0, nullable=false)
     */
    protected $transX;

    /**
     * @var float
     *
     * @ORM\Column(name="trans_y", type="float", precision=10, scale=0, nullable=false)
     */
    protected $transY;

    /**
     * @var float
     *
     * @ORM\Column(name="trans_z", type="float", precision=10, scale=0, nullable=false)
     */
    protected $transZ;

    /**
     * @var float
     *
     * @ORM\Column(name="trans_o", type="float", precision=10, scale=0, nullable=false)
     */
    protected $transO;

    /**
     * @var integer
     *
     * @ORM\Column(name="transguid", type="bigint", nullable=false)
     */
    protected $transguid;

    /**
     * @var integer
     *
     * @ORM\Column(name="extra_flags", type="smallint", nullable=false)
     */
    protected $extraFlags;

    /**
     * @var boolean
     *
     * @ORM\Column(name="stable_slots", type="boolean", nullable=false)
     */
    protected $stableSlots;

    /**
     * @var integer
     *
     * @ORM\Column(name="at_login", type="integer", nullable=false)
     */
    protected $atLogin;

    /**
     * @var integer
     *
     * @ORM\Column(name="zone", type="integer", nullable=false)
     */
    protected $zone;

    /**
     * @var integer
     *
     * @ORM\Column(name="death_expire_time", type="bigint", nullable=false)
     */
    protected $deathExpireTime;

    /**
     * @var string
     *
     * @ORM\Column(name="taxi_path", type="text", length=65535, nullable=true)
     */
    protected $taxiPath;

    /**
     * @var integer
     *
     * @ORM\Column(name="watchedFaction", type="integer", nullable=true)
     */
    protected $watchedfaction;

    /**
     * @var integer
     *
     * @ORM\Column(name="drunk", type="smallint", nullable=false)
     */
    protected $drunk;

    /**
     * @var integer
     *
     * @ORM\Column(name="health", type="integer", nullable=false)
     */
    protected $health;

    /**
     * @var integer
     *
     * @ORM\Column(name="power1", type="integer", nullable=false)
     */
    protected $power1;

    /**
     * @var integer
     *
     * @ORM\Column(name="power2", type="integer", nullable=false)
     */
    protected $power2;

    /**
     * @var integer
     *
     * @ORM\Column(name="power3", type="integer", nullable=false)
     */
    protected $power3;

    /**
     * @var integer
     *
     * @ORM\Column(name="power4", type="integer", nullable=false)
     */
    protected $power4;

    /**
     * @var integer
     *
     * @ORM\Column(name="power5", type="integer", nullable=false)
     */
    protected $power5;

    /**
     * @var string
     *
     * @ORM\Column(name="exploredZones", type="text", nullable=true)
     */
    protected $exploredzones;

    /**
     * @var string
     *
     * @ORM\Column(name="equipmentCache", type="text", nullable=true)
     */
    protected $equipmentcache;

    /**
     * @var integer
     *
     * @ORM\Column(name="ammoId", type="integer", nullable=false)
     */
    protected $ammoid;

    /**
     * @var boolean
     *
     * @ORM\Column(name="actionBars", type="boolean", nullable=false)
     */
    protected $actionbars;

    /**
     * @var integer
     *
     * @ORM\Column(name="deleteInfos_Account", type="integer", nullable=true)
     */
    protected $deleteinfosAccount;

    /**
     * @var string
     *
     * @ORM\Column(name="deleteInfos_Name", type="string", length=12, nullable=true)
     */
    protected $deleteinfosName;

    /**
     * @var integer
     *
     * @ORM\Column(name="deleteDate", type="integer", nullable=true)
     */
    protected $deletedate;

    /**
     * @var integer
     *
     * @ORM\Column(name="area", type="integer")
     */
    protected $area;

    /**
     * @var $realm
     */
    protected $realm;

    /**
     * @var $integer
     */
    protected $rank = 0;

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->name;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set account
     *
     * @param integer $account
     *
     * @return Characters
     */
    public function setAccount($account)
    {
        $this->account = $account;

        return $this;
    }

    /**
     * Get account
     *
     * @return integer
     */
    public function getAccount()
    {
        return $this->account;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Characters
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set race
     *
     * @param boolean $race
     *
     * @return Characters
     */
    public function setRace($race)
    {
        $this->race = $race;

        return $this;
    }

    /**
     * Get race
     *
     * @return boolean
     */
    public function getRace()
    {
        return $this->race;
    }

    /**
     * Set class
     *
     * @param boolean $class
     *
     * @return Characters
     */
    public function setClass($class)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return boolean
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Set gender
     *
     * @param boolean $gender
     *
     * @return Characters
     */
    public function setGender($gender)
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get gender
     *
     * @return boolean
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set level
     *
     * @param boolean $level
     *
     * @return Characters
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return boolean
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set xp
     *
     * @param integer $xp
     *
     * @return Characters
     */
    public function setXp($xp)
    {
        $this->xp = $xp;

        return $this;
    }

    /**
     * Get xp
     *
     * @return integer
     */
    public function getXp()
    {
        return $this->xp;
    }

    /**
     * Set money
     *
     * @param integer $money
     *
     * @return Characters
     */
    public function setMoney($money)
    {
        $this->money = $money;

        return $this;
    }

    /**
     * Get money
     *
     * @return integer
     */
    public function getMoney()
    {
        return $this->money;
    }

    /**
     * Set playerbytes
     *
     * @param integer $playerbytes
     *
     * @return Characters
     */
    public function setPlayerbytes($playerbytes)
    {
        $this->playerbytes = $playerbytes;

        return $this;
    }

    /**
     * Get playerbytes
     *
     * @return integer
     */
    public function getPlayerbytes()
    {
        return $this->playerbytes;
    }

    /**
     * Set playerbytes2
     *
     * @param integer $playerbytes2
     *
     * @return Characters
     */
    public function setPlayerbytes2($playerbytes2)
    {
        $this->playerbytes2 = $playerbytes2;

        return $this;
    }

    /**
     * Get playerbytes2
     *
     * @return integer
     */
    public function getPlayerbytes2()
    {
        return $this->playerbytes2;
    }

    /**
     * Set playerflags
     *
     * @param integer $playerflags
     *
     * @return Characters
     */
    public function setPlayerflags($playerflags)
    {
        $this->playerflags = $playerflags;

        return $this;
    }

    /**
     * Get playerflags
     *
     * @return integer
     */
    public function getPlayerflags()
    {
        return $this->playerflags;
    }

    /**
     * Set positionX
     *
     * @param float $positionX
     *
     * @return Characters
     */
    public function setPositionX($positionX)
    {
        $this->positionX = $positionX;

        return $this;
    }

    /**
     * Get positionX
     *
     * @return float
     */
    public function getPositionX()
    {
        return $this->positionX;
    }

    /**
     * Set positionY
     *
     * @param float $positionY
     *
     * @return Characters
     */
    public function setPositionY($positionY)
    {
        $this->positionY = $positionY;

        return $this;
    }

    /**
     * Get positionY
     *
     * @return float
     */
    public function getPositionY()
    {
        return $this->positionY;
    }

    /**
     * Set positionZ
     *
     * @param float $positionZ
     *
     * @return Characters
     */
    public function setPositionZ($positionZ)
    {
        $this->positionZ = $positionZ;

        return $this;
    }

    /**
     * Get positionZ
     *
     * @return float
     */
    public function getPositionZ()
    {
        return $this->positionZ;
    }

    /**
     * Set map
     *
     * @param integer $map
     *
     * @return Characters
     */
    public function setMap($map)
    {
        $this->map = $map;

        return $this;
    }

    /**
     * Get map
     *
     * @return integer
     */
    public function getMap()
    {
        return $this->map;
    }

    /**
     * Set orientation
     *
     * @param float $orientation
     *
     * @return Characters
     */
    public function setOrientation($orientation)
    {
        $this->orientation = $orientation;

        return $this;
    }

    /**
     * Get orientation
     *
     * @return float
     */
    public function getOrientation()
    {
        return $this->orientation;
    }

    /**
     * Set taximask
     *
     * @param string $taximask
     *
     * @return Characters
     */
    public function setTaximask($taximask)
    {
        $this->taximask = $taximask;

        return $this;
    }

    /**
     * Get taximask
     *
     * @return string
     */
    public function getTaximask()
    {
        return $this->taximask;
    }

    /**
     * Set online
     *
     * @param boolean $online
     *
     * @return Characters
     */
    public function setOnline($online)
    {
        $this->online = $online;

        return $this;
    }

    /**
     * @return boolean
     */
    public function isOnline()
    {
        return $this->online;
    }

    /**
     * Set cinematic
     *
     * @param boolean $cinematic
     *
     * @return Characters
     */
    public function setCinematic($cinematic)
    {
        $this->cinematic = $cinematic;

        return $this;
    }

    /**
     * Get cinematic
     *
     * @return boolean
     */
    public function getCinematic()
    {
        return $this->cinematic;
    }

    /**
     * Set totaltime
     *
     * @param integer $totaltime
     *
     * @return Characters
     */
    public function setTotaltime($totaltime)
    {
        $this->totaltime = $totaltime;

        return $this;
    }

    /**
     * Get totaltime
     *
     * @return integer
     */
    public function getTotaltime()
    {
        return $this->totaltime;
    }

    /**
     * Set leveltime
     *
     * @param integer $leveltime
     *
     * @return Characters
     */
    public function setLeveltime($leveltime)
    {
        $this->leveltime = $leveltime;

        return $this;
    }

    /**
     * Get leveltime
     *
     * @return integer
     */
    public function getLeveltime()
    {
        return $this->leveltime;
    }

    /**
     * Set logoutTime
     *
     * @param integer $logoutTime
     *
     * @return Characters
     */
    public function setLogoutTime($logoutTime)
    {
        $this->logoutTime = $logoutTime;

        return $this;
    }

    /**
     * Get logoutTime
     *
     * @return integer
     */
    public function getLogoutTime()
    {
        return $this->logoutTime;
    }

    /**
     * Set isLogoutResting
     *
     * @param boolean $isLogoutResting
     *
     * @return Characters
     */
    public function setIsLogoutResting($isLogoutResting)
    {
        $this->isLogoutResting = $isLogoutResting;

        return $this;
    }

    /**
     * Get isLogoutResting
     *
     * @return boolean
     */
    public function getIsLogoutResting()
    {
        return $this->isLogoutResting;
    }

    /**
     * Set restBonus
     *
     * @param float $restBonus
     *
     * @return Characters
     */
    public function setRestBonus($restBonus)
    {
        $this->restBonus = $restBonus;

        return $this;
    }

    /**
     * Get restBonus
     *
     * @return float
     */
    public function getRestBonus()
    {
        return $this->restBonus;
    }

    /**
     * Set resettalentsCost
     *
     * @param integer $resettalentsCost
     *
     * @return Characters
     */
    public function setResettalentsCost($resettalentsCost)
    {
        $this->resettalentsCost = $resettalentsCost;

        return $this;
    }

    /**
     * Get resettalentsCost
     *
     * @return integer
     */
    public function getResettalentsCost()
    {
        return $this->resettalentsCost;
    }

    /**
     * Set resettalentsTime
     *
     * @param integer $resettalentsTime
     *
     * @return Characters
     */
    public function setResettalentsTime($resettalentsTime)
    {
        $this->resettalentsTime = $resettalentsTime;

        return $this;
    }

    /**
     * Get resettalentsTime
     *
     * @return integer
     */
    public function getResettalentsTime()
    {
        return $this->resettalentsTime;
    }

    /**
     * Set transX
     *
     * @param float $transX
     *
     * @return Characters
     */
    public function setTransX($transX)
    {
        $this->transX = $transX;

        return $this;
    }

    /**
     * Get transX
     *
     * @return float
     */
    public function getTransX()
    {
        return $this->transX;
    }

    /**
     * Set transY
     *
     * @param float $transY
     *
     * @return Characters
     */
    public function setTransY($transY)
    {
        $this->transY = $transY;

        return $this;
    }

    /**
     * Get transY
     *
     * @return float
     */
    public function getTransY()
    {
        return $this->transY;
    }

    /**
     * Set transZ
     *
     * @param float $transZ
     *
     * @return Characters
     */
    public function setTransZ($transZ)
    {
        $this->transZ = $transZ;

        return $this;
    }

    /**
     * Get transZ
     *
     * @return float
     */
    public function getTransZ()
    {
        return $this->transZ;
    }

    /**
     * Set transO
     *
     * @param float $transO
     *
     * @return Characters
     */
    public function setTransO($transO)
    {
        $this->transO = $transO;

        return $this;
    }

    /**
     * Get transO
     *
     * @return float
     */
    public function getTransO()
    {
        return $this->transO;
    }

    /**
     * Set transguid
     *
     * @param integer $transguid
     *
     * @return Characters
     */
    public function setTransguid($transguid)
    {
        $this->transguid = $transguid;

        return $this;
    }

    /**
     * Get transguid
     *
     * @return integer
     */
    public function getTransguid()
    {
        return $this->transguid;
    }

    /**
     * Set extraFlags
     *
     * @param integer $extraFlags
     *
     * @return Characters
     */
    public function setExtraFlags($extraFlags)
    {
        $this->extraFlags = $extraFlags;

        return $this;
    }

    /**
     * Get extraFlags
     *
     * @return integer
     */
    public function getExtraFlags()
    {
        return $this->extraFlags;
    }

    /**
     * Set stableSlots
     *
     * @param boolean $stableSlots
     *
     * @return Characters
     */
    public function setStableSlots($stableSlots)
    {
        $this->stableSlots = $stableSlots;

        return $this;
    }

    /**
     * Get stableSlots
     *
     * @return boolean
     */
    public function getStableSlots()
    {
        return $this->stableSlots;
    }

    /**
     * Set atLogin
     *
     * @param integer $atLogin
     *
     * @return Characters
     */
    public function setAtLogin($atLogin)
    {
        $this->atLogin = $atLogin;

        return $this;
    }

    /**
     * Get atLogin
     *
     * @return integer
     */
    public function getAtLogin()
    {
        return $this->atLogin;
    }

    /**
     * Set zone
     *
     * @param integer $zone
     *
     * @return Characters
     */
    public function setZone($zone)
    {
        $this->zone = $zone;

        return $this;
    }

    /**
     * Get zone
     *
     * @return integer
     */
    public function getZone()
    {
        return $this->zone;
    }

    /**
     * Set deathExpireTime
     *
     * @param integer $deathExpireTime
     *
     * @return Characters
     */
    public function setDeathExpireTime($deathExpireTime)
    {
        $this->deathExpireTime = $deathExpireTime;

        return $this;
    }

    /**
     * Get deathExpireTime
     *
     * @return integer
     */
    public function getDeathExpireTime()
    {
        return $this->deathExpireTime;
    }

    /**
     * Set taxiPath
     *
     * @param string $taxiPath
     *
     * @return Characters
     */
    public function setTaxiPath($taxiPath)
    {
        $this->taxiPath = $taxiPath;

        return $this;
    }

    /**
     * Get taxiPath
     *
     * @return string
     */
    public function getTaxiPath()
    {
        return $this->taxiPath;
    }

    /**
     * Set watchedfaction
     *
     * @param integer $watchedfaction
     *
     * @return Characters
     */
    public function setWatchedfaction($watchedfaction)
    {
        $this->watchedfaction = $watchedfaction;

        return $this;
    }

    /**
     * Get watchedfaction
     *
     * @return integer
     */
    public function getWatchedfaction()
    {
        return $this->watchedfaction;
    }

    /**
     * Set drunk
     *
     * @param integer $drunk
     *
     * @return Characters
     */
    public function setDrunk($drunk)
    {
        $this->drunk = $drunk;

        return $this;
    }

    /**
     * Get drunk
     *
     * @return integer
     */
    public function getDrunk()
    {
        return $this->drunk;
    }

    /**
     * Set health
     *
     * @param integer $health
     *
     * @return Characters
     */
    public function setHealth($health)
    {
        $this->health = $health;

        return $this;
    }

    /**
     * Get health
     *
     * @return integer
     */
    public function getHealth()
    {
        return $this->health;
    }

    /**
     * Set power1
     *
     * @param integer $power1
     *
     * @return Characters
     */
    public function setPower1($power1)
    {
        $this->power1 = $power1;

        return $this;
    }

    /**
     * Get power1
     *
     * @return integer
     */
    public function getPower1()
    {
        return $this->power1;
    }

    /**
     * Set power2
     *
     * @param integer $power2
     *
     * @return Characters
     */
    public function setPower2($power2)
    {
        $this->power2 = $power2;

        return $this;
    }

    /**
     * Get power2
     *
     * @return integer
     */
    public function getPower2()
    {
        return $this->power2;
    }

    /**
     * Set power3
     *
     * @param integer $power3
     *
     * @return Characters
     */
    public function setPower3($power3)
    {
        $this->power3 = $power3;

        return $this;
    }

    /**
     * Get power3
     *
     * @return integer
     */
    public function getPower3()
    {
        return $this->power3;
    }

    /**
     * Set power4
     *
     * @param integer $power4
     *
     * @return Characters
     */
    public function setPower4($power4)
    {
        $this->power4 = $power4;

        return $this;
    }

    /**
     * Get power4
     *
     * @return integer
     */
    public function getPower4()
    {
        return $this->power4;
    }

    /**
     * Set power5
     *
     * @param integer $power5
     *
     * @return Characters
     */
    public function setPower5($power5)
    {
        $this->power5 = $power5;

        return $this;
    }

    /**
     * Get power5
     *
     * @return integer
     */
    public function getPower5()
    {
        return $this->power5;
    }

    /**
     * Set exploredzones
     *
     * @param string $exploredzones
     *
     * @return Characters
     */
    public function setExploredzones($exploredzones)
    {
        $this->exploredzones = $exploredzones;

        return $this;
    }

    /**
     * Get exploredzones
     *
     * @return string
     */
    public function getExploredzones()
    {
        return $this->exploredzones;
    }

    /**
     * Set equipmentcache
     *
     * @param string $equipmentcache
     *
     * @return Characters
     */
    public function setEquipmentcache($equipmentcache)
    {
        $this->equipmentcache = $equipmentcache;

        return $this;
    }

    /**
     * Get equipmentcache
     *
     * @return string
     */
    public function getEquipmentcache()
    {
        return $this->equipmentcache;
    }

    /**
     * Set ammoid
     *
     * @param integer $ammoid
     *
     * @return Characters
     */
    public function setAmmoid($ammoid)
    {
        $this->ammoid = $ammoid;

        return $this;
    }

    /**
     * Get ammoid
     *
     * @return integer
     */
    public function getAmmoid()
    {
        return $this->ammoid;
    }

    /**
     * Set actionbars
     *
     * @param boolean $actionbars
     *
     * @return Characters
     */
    public function setActionbars($actionbars)
    {
        $this->actionbars = $actionbars;

        return $this;
    }

    /**
     * Get actionbars
     *
     * @return boolean
     */
    public function getActionbars()
    {
        return $this->actionbars;
    }

    /**
     * Set deleteinfosAccount
     *
     * @param integer $deleteinfosAccount
     *
     * @return Characters
     */
    public function setDeleteinfosAccount($deleteinfosAccount)
    {
        $this->deleteinfosAccount = $deleteinfosAccount;

        return $this;
    }

    /**
     * Get deleteinfosAccount
     *
     * @return integer
     */
    public function getDeleteinfosAccount()
    {
        return $this->deleteinfosAccount;
    }

    /**
     * Set deleteinfosName
     *
     * @param string $deleteinfosName
     *
     * @return Characters
     */
    public function setDeleteinfosName($deleteinfosName)
    {
        $this->deleteinfosName = $deleteinfosName;

        return $this;
    }

    /**
     * Get deleteinfosName
     *
     * @return string
     */
    public function getDeleteinfosName()
    {
        return $this->deleteinfosName;
    }

    /**
     * Set deletedate
     *
     * @param integer $deletedate
     *
     * @return Characters
     */
    public function setDeletedate($deletedate)
    {
        $this->deletedate = $deletedate;

        return $this;
    }

    /**
     * Get deletedate
     *
     * @return integer
     */
    public function getDeletedate()
    {
        return $this->deletedate;
    }

    /**
     * @return int
     */
    public function getArea()
    {
        return $this->area;
    }

    /**
     * @param int $area
     */
    public function setArea($area)
    {
        $this->area = $area;
    }

    /**
     * @return mixed
     */
    public function getRealm()
    {
        return $this->realm;
    }

    /**
     * @param mixed $realm
     */
    public function setRealm($realm)
    {
        $this->realm = $realm;
    }

    /**
     * @return mixed
     */
    public function getRank()
    {
        return $this->rank;
    }

    /**
     * @param mixed $rank
     */
    public function setRank($rank)
    {
        $this->rank = $rank;
    }

    /**
     * @return string
     */
    public function serialize()
    {
        return serialize(array(
            $this->guid,
            $this->name,
            $this->race,
            $this->class,
            $this->gender,
            $this->level,
            $this->money,
            $this->realm,
            $this->online,
            $this->rank,
        ));
    }

    /**
     * @param string $serialized
     */
    public function unserialize($serialized)
    {
        list (
            $this->guid,
            $this->name,
            $this->race,
            $this->class,
            $this->gender,
            $this->level,
            $this->money,
            $this->realm,
            $this->online,
            $this->rank,
            ) = unserialize($serialized);
    }
}