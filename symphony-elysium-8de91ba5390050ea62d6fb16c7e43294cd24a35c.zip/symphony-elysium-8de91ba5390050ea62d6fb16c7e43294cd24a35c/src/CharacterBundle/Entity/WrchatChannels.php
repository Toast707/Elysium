<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * WrchatChannels
 *
 * @ORM\Table(name="wrchat_channels", indexes={@ORM\Index(name="server", columns={"server"})})
 * @ORM\Entity
 */
class WrchatChannels
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="irc_channel", type="string", length=50, nullable=false)
     */
    protected $ircChannel = '';

    /**
     * @var string
     *
     * @ORM\Column(name="password", type="string", length=50, nullable=false)
     */
    protected $password = '';

    /**
     * @var string
     *
     * @ORM\Column(name="ingame_channel", type="string", length=50, nullable=false)
     */
    protected $ingameChannel = '';

    /**
     * @var boolean
     *
     * @ORM\Column(name="channel_type", type="boolean", nullable=false)
     */
    protected $channelType = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="join_message", type="string", length=255, nullable=false)
     */
    protected $joinMessage = '';

    /**
     * @var \CharacterBundle\Entity\WrchatServers
     *
     * @ORM\ManyToOne(targetEntity="CharacterBundle\Entity\WrchatServers")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="server", referencedColumnName="id")
     * })
     */
    protected $server;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set ircChannel
     *
     * @param string $ircChannel
     *
     * @return WrchatChannels
     */
    public function setIrcChannel($ircChannel)
    {
        $this->ircChannel = $ircChannel;

        return $this;
    }

    /**
     * Get ircChannel
     *
     * @return string
     */
    public function getIrcChannel()
    {
        return $this->ircChannel;
    }

    /**
     * Set password
     *
     * @param string $password
     *
     * @return WrchatChannels
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set ingameChannel
     *
     * @param string $ingameChannel
     *
     * @return WrchatChannels
     */
    public function setIngameChannel($ingameChannel)
    {
        $this->ingameChannel = $ingameChannel;

        return $this;
    }

    /**
     * Get ingameChannel
     *
     * @return string
     */
    public function getIngameChannel()
    {
        return $this->ingameChannel;
    }

    /**
     * Set channelType
     *
     * @param boolean $channelType
     *
     * @return WrchatChannels
     */
    public function setChannelType($channelType)
    {
        $this->channelType = $channelType;

        return $this;
    }

    /**
     * Get channelType
     *
     * @return boolean
     */
    public function getChannelType()
    {
        return $this->channelType;
    }

    /**
     * Set joinMessage
     *
     * @param string $joinMessage
     *
     * @return WrchatChannels
     */
    public function setJoinMessage($joinMessage)
    {
        $this->joinMessage = $joinMessage;

        return $this;
    }

    /**
     * Get joinMessage
     *
     * @return string
     */
    public function getJoinMessage()
    {
        return $this->joinMessage;
    }

    /**
     * Set server
     *
     * @param \CharacterBundle\Entity\WrchatServers $server
     *
     * @return WrchatChannels
     */
    public function setServer(\CharacterBundle\Entity\WrchatServers $server = null)
    {
        $this->server = $server;

        return $this;
    }

    /**
     * Get server
     *
     * @return \CharacterBundle\Entity\WrchatServers
     */
    public function getServer()
    {
        return $this->server;
    }
}
