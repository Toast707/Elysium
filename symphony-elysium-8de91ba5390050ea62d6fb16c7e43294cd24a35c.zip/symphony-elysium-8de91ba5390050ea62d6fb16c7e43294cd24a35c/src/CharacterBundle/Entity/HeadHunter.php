<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * HeadHunter
 *
 * @ORM\Table(name="head_hunter")
 * @ORM\Entity
 */
class HeadHunter
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="sourceguid", type="integer", nullable=false)
     */
    protected $sourceguid;

    /**
     * @var integer
     *
     * @ORM\Column(name="amount", type="integer", nullable=false)
     */
    protected $amount;

    /**
     * @var integer
     *
     * @ORM\Column(name="targetguid", type="integer", nullable=false)
     */
    protected $targetguid;

    /**
     * @var integer
     *
     * @ORM\Column(name="killedby", type="integer", nullable=false)
     */
    protected $killedby;

    /**
     * @var integer
     *
     * @ORM\Column(name="starttime", type="integer", nullable=false)
     */
    protected $starttime;

    /**
     * @var integer
     *
     * @ORM\Column(name="exectime", type="integer", nullable=false)
     */
    protected $exectime;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sourceguid
     *
     * @param integer $sourceguid
     *
     * @return HeadHunter
     */
    public function setSourceguid($sourceguid)
    {
        $this->sourceguid = $sourceguid;

        return $this;
    }

    /**
     * Get sourceguid
     *
     * @return integer
     */
    public function getSourceguid()
    {
        return $this->sourceguid;
    }

    /**
     * Set amount
     *
     * @param integer $amount
     *
     * @return HeadHunter
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return integer
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set targetguid
     *
     * @param integer $targetguid
     *
     * @return HeadHunter
     */
    public function setTargetguid($targetguid)
    {
        $this->targetguid = $targetguid;

        return $this;
    }

    /**
     * Get targetguid
     *
     * @return integer
     */
    public function getTargetguid()
    {
        return $this->targetguid;
    }

    /**
     * Set killedby
     *
     * @param integer $killedby
     *
     * @return HeadHunter
     */
    public function setKilledby($killedby)
    {
        $this->killedby = $killedby;

        return $this;
    }

    /**
     * Get killedby
     *
     * @return integer
     */
    public function getKilledby()
    {
        return $this->killedby;
    }

    /**
     * Set starttime
     *
     * @param integer $starttime
     *
     * @return HeadHunter
     */
    public function setStarttime($starttime)
    {
        $this->starttime = $starttime;

        return $this;
    }

    /**
     * Get starttime
     *
     * @return integer
     */
    public function getStarttime()
    {
        return $this->starttime;
    }

    /**
     * Set exectime
     *
     * @param integer $exectime
     *
     * @return HeadHunter
     */
    public function setExectime($exectime)
    {
        $this->exectime = $exectime;

        return $this;
    }

    /**
     * Get exectime
     *
     * @return integer
     */
    public function getExectime()
    {
        return $this->exectime;
    }
}
