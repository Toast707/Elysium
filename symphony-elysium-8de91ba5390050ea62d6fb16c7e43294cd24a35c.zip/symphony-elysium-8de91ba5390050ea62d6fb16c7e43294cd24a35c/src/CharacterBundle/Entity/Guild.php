<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Guild
 *
 * @ORM\Table(name="guild")
 * @ORM\Entity(repositoryClass="CharacterBundle\Repository\GuildRepository")
 */
class Guild
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guildid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $guildid;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=false)
     */
    protected $name;

    /**
     * @var integer
     *
     * @ORM\OneToOne(targetEntity="CharacterBundle\Entity\Characters")
     * @ORM\JoinColumn(name="leaderguid", referencedColumnName="guid")
     */
    protected $leaderguid;

    /**
     * @var integer
     *
     * @ORM\Column(name="EmblemStyle", type="integer", nullable=false)
     */
    protected $emblemstyle;

    /**
     * @var integer
     *
     * @ORM\Column(name="EmblemColor", type="integer", nullable=false)
     */
    protected $emblemcolor;

    /**
     * @var integer
     *
     * @ORM\Column(name="BorderStyle", type="integer", nullable=false)
     */
    protected $borderstyle;

    /**
     * @var integer
     *
     * @ORM\Column(name="BorderColor", type="integer", nullable=false)
     */
    protected $bordercolor;

    /**
     * @var integer
     *
     * @ORM\Column(name="BackgroundColor", type="integer", nullable=false)
     */
    protected $backgroundcolor;

    /**
     * @var string
     *
     * @ORM\Column(name="info", type="text", length=65535, nullable=false)
     */
    protected $info;

    /**
     * @var string
     *
     * @ORM\Column(name="motd", type="string", length=255, nullable=false)
     */
    protected $motd;

    /**
     * @var string
     *
     * @ORM\Column(name="createdate", type="string", nullable=true)
     */
    protected $createdate;

    /**
     * @var
     * @ORM\OneToMany(targetEntity="CharacterBundle\Entity\GuildMember", mappedBy="guildid")
     */
    protected $members;

    public function __construct()
    {
        $this->members = new ArrayCollection();
    }

    /**
     * @param int $guildid
     */
    public function setGuildid($guildid)
    {
        $this->guildid = $guildid;
    }

    /**
     * Get guildid
     *
     * @return integer
     */
    public function getGuildid()
    {
        return $this->guildid;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Guild
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set leaderguid
     *
     * @param integer $leaderguid
     *
     * @return Guild
     */
    public function setLeaderguid($leaderguid)
    {
        $this->leaderguid = $leaderguid;

        return $this;
    }

    /**
     * Get leaderguid
     *
     * @return integer
     */
    public function getLeaderguid()
    {
        return $this->leaderguid;
    }

    /**
     * Set emblemstyle
     *
     * @param integer $emblemstyle
     *
     * @return Guild
     */
    public function setEmblemstyle($emblemstyle)
    {
        $this->emblemstyle = $emblemstyle;

        return $this;
    }

    /**
     * Get emblemstyle
     *
     * @return integer
     */
    public function getEmblemstyle()
    {
        return $this->emblemstyle;
    }

    /**
     * Set emblemcolor
     *
     * @param integer $emblemcolor
     *
     * @return Guild
     */
    public function setEmblemcolor($emblemcolor)
    {
        $this->emblemcolor = $emblemcolor;

        return $this;
    }

    /**
     * Get emblemcolor
     *
     * @return integer
     */
    public function getEmblemcolor()
    {
        return $this->emblemcolor;
    }

    /**
     * Set borderstyle
     *
     * @param integer $borderstyle
     *
     * @return Guild
     */
    public function setBorderstyle($borderstyle)
    {
        $this->borderstyle = $borderstyle;

        return $this;
    }

    /**
     * Get borderstyle
     *
     * @return integer
     */
    public function getBorderstyle()
    {
        return $this->borderstyle;
    }

    /**
     * Set bordercolor
     *
     * @param integer $bordercolor
     *
     * @return Guild
     */
    public function setBordercolor($bordercolor)
    {
        $this->bordercolor = $bordercolor;

        return $this;
    }

    /**
     * Get bordercolor
     *
     * @return integer
     */
    public function getBordercolor()
    {
        return $this->bordercolor;
    }

    /**
     * Set backgroundcolor
     *
     * @param integer $backgroundcolor
     *
     * @return Guild
     */
    public function setBackgroundcolor($backgroundcolor)
    {
        $this->backgroundcolor = $backgroundcolor;

        return $this;
    }

    /**
     * Get backgroundcolor
     *
     * @return integer
     */
    public function getBackgroundcolor()
    {
        return $this->backgroundcolor;
    }

    /**
     * Set info
     *
     * @param string $info
     *
     * @return Guild
     */
    public function setInfo($info)
    {
        $this->info = $info;

        return $this;
    }

    /**
     * Get info
     *
     * @return string
     */
    public function getInfo()
    {
        return $this->info;
    }

    /**
     * Set motd
     *
     * @param string $motd
     *
     * @return Guild
     */
    public function setMotd($motd)
    {
        $this->motd = $motd;

        return $this;
    }

    /**
     * Get motd
     *
     * @return string
     */
    public function getMotd()
    {
        return $this->motd;
    }

    /**
     * Set createdate
     *
     * @param $createdate
     * @return $this
     */
    public function setCreatedate($createdate)
    {
        $this->createdate = $createdate;

        return $this;
    }

    /**
     * Get createdate
     *
     * @return string
     */
    public function getCreatedate()
    {
        return $this->createdate;
    }

    /**
     * Add member
     *
     * @param \CharacterBundle\Entity\GuildMember $member
     *
     * @return Guild
     */
    public function addMember(\CharacterBundle\Entity\GuildMember $member)
    {
        $this->members[] = $member;

        return $this;
    }

    /**
     * Remove member
     *
     * @param \CharacterBundle\Entity\GuildMember $member
     */
    public function removeMember(\CharacterBundle\Entity\GuildMember $member)
    {
        $this->members->removeElement($member);
    }
}
