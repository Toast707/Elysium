<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterAction
 *
 * @ORM\Table(name="character_action")
 * @ORM\Entity
 */
class CharacterAction
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $guid;

    /**
     * @var integer
     *
     * @ORM\Column(name="button", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    protected $button;

    /**
     * @var integer
     *
     * @ORM\Column(name="action", type="smallint", nullable=false)
     */
    protected $action;

    /**
     * @var integer
     *
     * @ORM\Column(name="type", type="integer", nullable=false)
     */
    protected $type;

    /**
     * @var integer
     *
     * @ORM\Column(name="misc", type="integer", nullable=false)
     */
    protected $misc;



    /**
     * Set guid
     *
     * @param integer $guid
     *
     * @return CharacterAction
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;

        return $this;
    }

    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set button
     *
     * @param boolean $button
     *
     * @return CharacterAction
     */
    public function setButton($button)
    {
        $this->button = $button;

        return $this;
    }

    /**
     * Get button
     *
     * @return boolean
     */
    public function getButton()
    {
        return $this->button;
    }

    /**
     * Set action
     *
     * @param integer $action
     *
     * @return CharacterAction
     */
    public function setAction($action)
    {
        $this->action = $action;

        return $this;
    }

    /**
     * Get action
     *
     * @return integer
     */
    public function getAction()
    {
        return $this->action;
    }

    /**
     * Set type
     *
     * @param boolean $type
     *
     * @return CharacterAction
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return boolean
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set misc
     *
     * @param boolean $misc
     *
     * @return CharacterAction
     */
    public function setMisc($misc)
    {
        $this->misc = $misc;

        return $this;
    }

    /**
     * Get misc
     *
     * @return boolean
     */
    public function getMisc()
    {
        return $this->misc;
    }
}
