<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterBgcoord
 *
 * @ORM\Table(name="character_bgcoord")
 * @ORM\Entity
 */
class CharacterBgcoord
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $guid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="bgid", type="integer", nullable=false)
     */
    protected $bgid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="bgteam", type="integer", nullable=false)
     */
    protected $bgteam = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="bgmap", type="integer", nullable=false)
     */
    protected $bgmap = '0';

    /**
     * @var float
     *
     * @ORM\Column(name="bgx", type="float", precision=10, scale=0, nullable=false)
     */
    protected $bgx = '0';

    /**
     * @var float
     *
     * @ORM\Column(name="bgy", type="float", precision=10, scale=0, nullable=false)
     */
    protected $bgy = '0';

    /**
     * @var float
     *
     * @ORM\Column(name="bgz", type="float", precision=10, scale=0, nullable=false)
     */
    protected $bgz = '0';

    /**
     * @var float
     *
     * @ORM\Column(name="bgo", type="float", precision=10, scale=0, nullable=false)
     */
    protected $bgo = '0';



    /**
     * Get guid
     *
     * @return integer
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * Set bgid
     *
     * @param integer $bgid
     *
     * @return CharacterBgcoord
     */
    public function setBgid($bgid)
    {
        $this->bgid = $bgid;

        return $this;
    }

    /**
     * Get bgid
     *
     * @return integer
     */
    public function getBgid()
    {
        return $this->bgid;
    }

    /**
     * Set bgteam
     *
     * @param integer $bgteam
     *
     * @return CharacterBgcoord
     */
    public function setBgteam($bgteam)
    {
        $this->bgteam = $bgteam;

        return $this;
    }

    /**
     * Get bgteam
     *
     * @return integer
     */
    public function getBgteam()
    {
        return $this->bgteam;
    }

    /**
     * Set bgmap
     *
     * @param integer $bgmap
     *
     * @return CharacterBgcoord
     */
    public function setBgmap($bgmap)
    {
        $this->bgmap = $bgmap;

        return $this;
    }

    /**
     * Get bgmap
     *
     * @return integer
     */
    public function getBgmap()
    {
        return $this->bgmap;
    }

    /**
     * Set bgx
     *
     * @param float $bgx
     *
     * @return CharacterBgcoord
     */
    public function setBgx($bgx)
    {
        $this->bgx = $bgx;

        return $this;
    }

    /**
     * Get bgx
     *
     * @return float
     */
    public function getBgx()
    {
        return $this->bgx;
    }

    /**
     * Set bgy
     *
     * @param float $bgy
     *
     * @return CharacterBgcoord
     */
    public function setBgy($bgy)
    {
        $this->bgy = $bgy;

        return $this;
    }

    /**
     * Get bgy
     *
     * @return float
     */
    public function getBgy()
    {
        return $this->bgy;
    }

    /**
     * Set bgz
     *
     * @param float $bgz
     *
     * @return CharacterBgcoord
     */
    public function setBgz($bgz)
    {
        $this->bgz = $bgz;

        return $this;
    }

    /**
     * Get bgz
     *
     * @return float
     */
    public function getBgz()
    {
        return $this->bgz;
    }

    /**
     * Set bgo
     *
     * @param float $bgo
     *
     * @return CharacterBgcoord
     */
    public function setBgo($bgo)
    {
        $this->bgo = $bgo;

        return $this;
    }

    /**
     * Get bgo
     *
     * @return float
     */
    public function getBgo()
    {
        return $this->bgo;
    }
}
