<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ItemInstance
 *
 * @ORM\Table(name="item_instance", indexes={@ORM\Index(name="idx_owner_guid", columns={"owner_guid"})})
 * @ORM\Entity
 */
class ItemInstance
{
    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $guid = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="itemEntry", type="integer", nullable=false)
     */
    protected $itemEntry = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="owner_guid", type="integer", nullable=false)
     */
    protected $ownerGuid = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="creatorGuid", type="integer", nullable=false)
     */
    protected $creatorGuid = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="giftCreatorGuid", type="integer", nullable=false)
     */
    protected $giftCreatorGuid = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="count", type="integer", nullable=false)
     */
    protected $count = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="duration", type="integer", nullable=false)
     */
    protected $duration = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="charges", type="smallint")
     */
    protected $charges = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="flags", type="integer", nullable=false)
     */
    protected $flags = 0;

    /**
     * @var text
     *
     * @ORM\Column(name="enchantments", type="text")
     */
    protected $enchantments;

    /**
     * @var integer
     *
     * @ORM\Column(name="randomPropertyId", type="smallint", nullable=false)
     */
    protected $randomPropertyId = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="durability", type="smallint", nullable=false)
     */
    protected $durability = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="text", type="integer", nullable=false)
     */
    protected $text = 0;

    /**
     * @return int
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * @param int $guid
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;
    }

    /**
     * @return int
     */
    public function getItemEntry()
    {
        return $this->itemEntry;
    }

    /**
     * @param int $itemEntry
     */
    public function setItemEntry($itemEntry)
    {
        $this->itemEntry = $itemEntry;
    }

    /**
     * @return int
     */
    public function getOwnerGuid()
    {
        return $this->ownerGuid;
    }

    /**
     * @param int $ownerGuid
     */
    public function setOwnerGuid($ownerGuid)
    {
        $this->ownerGuid = $ownerGuid;
    }

    /**
     * @return int
     */
    public function getCreatorGuid()
    {
        return $this->creatorGuid;
    }

    /**
     * @param int $creatorGuid
     */
    public function setCreatorGuid($creatorGuid)
    {
        $this->creatorGuid = $creatorGuid;
    }

    /**
     * @return int
     */
    public function getGiftCreatorGuid()
    {
        return $this->giftCreatorGuid;
    }

    /**
     * @param int $giftCreatorGuid
     */
    public function setGiftCreatorGuid($giftCreatorGuid)
    {
        $this->giftCreatorGuid = $giftCreatorGuid;
    }

    /**
     * @return int
     */
    public function getCount()
    {
        return $this->count;
    }

    /**
     * @param int $count
     */
    public function setCount($count)
    {
        $this->count = $count;
    }

    /**
     * @return int
     */
    public function getDuration()
    {
        return $this->duration;
    }

    /**
     * @param int $duration
     */
    public function setDuration($duration)
    {
        $this->duration = $duration;
    }

    /**
     * @return int
     */
    public function getCharges()
    {
        return $this->charges;
    }

    /**
     * @param int $charges
     */
    public function setCharges($charges)
    {
        $this->charges = $charges;
    }

    /**
     * @return int
     */
    public function getFlags()
    {
        return $this->flags;
    }

    /**
     * @param int $flags
     */
    public function setFlags($flags)
    {
        $this->flags = $flags;
    }

    /**
     * @return text
     */
    public function getEnchantments()
    {
        return $this->enchantments;
    }

    /**
     * @param text $enchantments
     */
    public function setEnchantments($enchantments)
    {
        $this->enchantments = $enchantments;
    }

    /**
     * @return int
     */
    public function getRandomPropertyId()
    {
        return $this->randomPropertyId;
    }

    /**
     * @param int $randomPropertyId
     */
    public function setRandomPropertyId($randomPropertyId)
    {
        $this->randomPropertyId = $randomPropertyId;
    }

    /**
     * @return int
     */
    public function getDurability()
    {
        return $this->durability;
    }

    /**
     * @param int $durability
     */
    public function setDurability($durability)
    {
        $this->durability = $durability;
    }

    /**
     * @return int
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * @param int $text
     */
    public function setText($text)
    {
        $this->text = $text;
    }
}
