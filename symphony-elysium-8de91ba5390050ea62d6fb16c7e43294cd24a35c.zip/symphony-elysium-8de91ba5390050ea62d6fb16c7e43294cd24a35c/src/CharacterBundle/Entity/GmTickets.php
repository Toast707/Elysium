<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GmTickets
 *
 * @ORM\Table(name="gm_tickets")
 * @ORM\Entity(repositoryClass="CharacterBundle\Repository\GmTicketsRepository")
 */
class GmTickets implements \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="ticketId", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $ticketId = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="guid", type="integer", nullable=false)
     */
    protected $guid = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=12, nullable=false)
     */
    protected $name;

    /**
     * @var string
     *
     * @ORM\Column(name="message", type="text", length=65535, nullable=false)
     */
    protected $message;

    /**
     * @var integer
     *
     * @ORM\Column(name="createtime", type="integer", nullable=false)
     */
    protected $createdAt;

    /**
     * @var integer
     *
     * @ORM\Column(name="mapId", type="integer", nullable=false)
     */
    protected $mapId = 0;

    /**
     * @var float
     *
     * @ORM\Column(name="posX", type="float", precision=10, scale=0, nullable=false)
     */
    protected $posX = 0;

    /**
     * @var float
     *
     * @ORM\Column(name="posY", type="float", precision=10, scale=0, nullable=false)
     */
    protected $posY = 0;

    /**
     * @var float
     *
     * @ORM\Column(name="posZ", type="float", precision=10, scale=0, nullable=false)
     */
    protected $posZ = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="lastModifiedTime", type="integer", length=10, nullable=false)
     */
    protected $lastModifiedTime = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="closedBy", type="integer", nullable=false)
     */
    protected $closedBy = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="assignedTo", type="integer", nullable=false)
     */
    protected $assignedTo = 0;

    /**
     * @var string
     *
     * @ORM\Column(name="comment", type="text", length=65535, nullable=false)
     */
    protected $comment;

    /**
     * @var string
     *
     * @ORM\Column(name="response", type="text", length=65535, nullable=false)
     */
    protected $response;

    /**
     * @var integer
     *
     * @ORM\Column(name="completed", type="integer", length=3, nullable=false)
     */
    protected $completed = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="escalated", type="integer", length=3, nullable=false)
     */
    protected $escalated = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="viewed", type="integer", length=3, nullable=false)
     */
    protected $viewed = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="haveTicket", type="integer", length=3, nullable=false)
     */
    protected $haveTicket = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="ticketType", type="integer", length=3, nullable=false)
     */
    protected $ticketType = 0;

    /**
     * @var integer
     *
     * @ORM\Column(name="securityNeeded", type="integer", length=3, nullable=false)
     */
    protected $securityNeeded = 0;


    /**
     * @return int
     */
    public function getTicketId()
    {
        return $this->ticketId;
    }

    /**
     * @param int $ticketId
     */
    public function setTicketId($ticketId)
    {
        $this->ticketId = $ticketId;
    }

    /**
     * @return int
     */
    public function getGuid()
    {
        return $this->guid;
    }

    /**
     * @param int $guid
     */
    public function setGuid($guid)
    {
        $this->guid = $guid;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @param string $message
     */
    public function setMessage($message)
    {
        $this->message = $message;
    }

    /**
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param int $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
    }

    /**
     * @return int
     */
    public function getMapId()
    {
        return $this->mapId;
    }

    /**
     * @param int $mapId
     */
    public function setMapId($mapId)
    {
        $this->mapId = $mapId;
    }

    /**
     * @return float
     */
    public function getPosX()
    {
        return $this->posX;
    }

    /**
     * @param float $posX
     */
    public function setPosX($posX)
    {
        $this->posX = $posX;
    }

    /**
     * @return float
     */
    public function getPosY()
    {
        return $this->posY;
    }

    /**
     * @param float $posY
     */
    public function setPosY($posY)
    {
        $this->posY = $posY;
    }

    /**
     * @return float
     */
    public function getPosZ()
    {
        return $this->posZ;
    }

    /**
     * @param float $posZ
     */
    public function setPosZ($posZ)
    {
        $this->posZ = $posZ;
    }

    /**
     * @return int
     */
    public function getLastModifiedTime()
    {
        return $this->lastModifiedTime;
    }

    /**
     * @param int $lastModifiedTime
     */
    public function setLastModifiedTime($lastModifiedTime)
    {
        $this->lastModifiedTime = $lastModifiedTime;
    }

    /**
     * @return int
     */
    public function getClosedBy()
    {
        return $this->closedBy;
    }

    /**
     * @param int $closedBy
     */
    public function setClosedBy($closedBy)
    {
        $this->closedBy = $closedBy;
    }

    /**
     * @return int
     */
    public function getAssignedTo()
    {
        return $this->assignedTo;
    }

    /**
     * @param int $assignedTo
     */
    public function setAssignedTo($assignedTo)
    {
        $this->assignedTo = $assignedTo;
    }

    /**
     * @return string
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * @param string $comment
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * @return string
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * @param string $response
     */
    public function setResponse($response)
    {
        $this->response = $response;
    }

    /**
     * @return int
     */
    public function getCompleted()
    {
        return $this->completed;
    }

    /**
     * @param int $completed
     */
    public function setCompleted($completed)
    {
        $this->completed = $completed;
    }

    /**
     * @return int
     */
    public function getEscalated()
    {
        return $this->escalated;
    }

    /**
     * @param int $escalated
     */
    public function setEscalated($escalated)
    {
        $this->escalated = $escalated;
    }

    /**
     * @return int
     */
    public function getViewed()
    {
        return $this->viewed;
    }

    /**
     * @param int $viewed
     */
    public function setViewed($viewed)
    {
        $this->viewed = $viewed;
    }

    /**
     * @return int
     */
    public function getHaveTicket()
    {
        return $this->haveTicket;
    }

    /**
     * @param int $haveTicket
     */
    public function setHaveTicket($haveTicket)
    {
        $this->haveTicket = $haveTicket;
    }

    /**
     * @return int
     */
    public function getTicketType()
    {
        return $this->ticketType;
    }

    /**
     * @param int $ticketType
     */
    public function setTicketType($ticketType)
    {
        $this->ticketType = $ticketType;
    }

    /**
     * @return int
     */
    public function getSecurityNeeded()
    {
        return $this->securityNeeded;
    }

    /**
     * @param int $securityNeeded
     */
    public function setSecurityNeeded($securityNeeded)
    {
        $this->securityNeeded = $securityNeeded;
    }

    /** @see \Serializable::serialize() */
    public function serialize()
    {
        return serialize(array(
            $this->ticketId,
            $this->guid,
            $this->name,
            $this->message,
            $this->closedBy,
            $this->assignedTo,
            $this->escalated,
        ));
    }

    /** @see \Serializable::unserialize() */
    public function unserialize($serialized)
    {
        list (
            $this->ticketId,
            $this->guid,
            $this->name,
            $this->message,
            $this->closedBy,
            $this->assignedTo,
            $this->escalated,
            ) = unserialize($serialized);
    }
}
