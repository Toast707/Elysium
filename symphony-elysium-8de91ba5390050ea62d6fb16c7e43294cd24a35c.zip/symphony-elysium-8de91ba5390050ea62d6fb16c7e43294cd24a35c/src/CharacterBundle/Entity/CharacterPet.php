<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CharacterPet
 *
 * @ORM\Table(name="character_pet", indexes={@ORM\Index(name="owner", columns={"owner"})})
 * @ORM\Entity
 */
class CharacterPet
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="entry", type="integer", nullable=false)
     */
    protected $entry = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="owner", type="integer", nullable=false)
     */
    protected $owner = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="modelid", type="integer", nullable=true)
     */
    protected $modelid = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="CreatedBySpell", type="integer", nullable=false)
     */
    protected $createdbyspell = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="PetType", type="boolean", nullable=false)
     */
    protected $pettype = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="level", type="boolean", nullable=false)
     */
    protected $level = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="exp", type="integer", nullable=false)
     */
    protected $exp = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="Reactstate", type="boolean", nullable=false)
     */
    protected $reactstate = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="loyaltypoints", type="integer", nullable=false)
     */
    protected $loyaltypoints = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="loyalty", type="integer", nullable=false)
     */
    protected $loyalty = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="trainpoint", type="integer", nullable=false)
     */
    protected $trainpoint = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=100, nullable=true)
     */
    protected $name = 'Pet';

    /**
     * @var boolean
     *
     * @ORM\Column(name="renamed", type="boolean", nullable=false)
     */
    protected $renamed = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="slot", type="boolean", nullable=false)
     */
    protected $slot = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="curhealth", type="integer", nullable=false)
     */
    protected $curhealth = '1';

    /**
     * @var integer
     *
     * @ORM\Column(name="curmana", type="integer", nullable=false)
     */
    protected $curmana = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="curhappiness", type="integer", nullable=false)
     */
    protected $curhappiness = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="savetime", type="integer", nullable=false)
     */
    protected $savetime = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="resettalents_cost", type="integer", nullable=false)
     */
    protected $resettalentsCost = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="resettalents_time", type="integer", nullable=false)
     */
    protected $resettalentsTime = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="abdata", type="text", nullable=true)
     */
    protected $abdata;

    /**
     * @var string
     *
     * @ORM\Column(name="teachspelldata", type="text", nullable=true)
     */
    protected $teachspelldata;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set entry
     *
     * @param integer $entry
     *
     * @return CharacterPet
     */
    public function setEntry($entry)
    {
        $this->entry = $entry;

        return $this;
    }

    /**
     * Get entry
     *
     * @return integer
     */
    public function getEntry()
    {
        return $this->entry;
    }

    /**
     * Set owner
     *
     * @param integer $owner
     *
     * @return CharacterPet
     */
    public function setOwner($owner)
    {
        $this->owner = $owner;

        return $this;
    }

    /**
     * Get owner
     *
     * @return integer
     */
    public function getOwner()
    {
        return $this->owner;
    }

    /**
     * Set modelid
     *
     * @param integer $modelid
     *
     * @return CharacterPet
     */
    public function setModelid($modelid)
    {
        $this->modelid = $modelid;

        return $this;
    }

    /**
     * Get modelid
     *
     * @return integer
     */
    public function getModelid()
    {
        return $this->modelid;
    }

    /**
     * Set createdbyspell
     *
     * @param integer $createdbyspell
     *
     * @return CharacterPet
     */
    public function setCreatedbyspell($createdbyspell)
    {
        $this->createdbyspell = $createdbyspell;

        return $this;
    }

    /**
     * Get createdbyspell
     *
     * @return integer
     */
    public function getCreatedbyspell()
    {
        return $this->createdbyspell;
    }

    /**
     * Set pettype
     *
     * @param boolean $pettype
     *
     * @return CharacterPet
     */
    public function setPettype($pettype)
    {
        $this->pettype = $pettype;

        return $this;
    }

    /**
     * Get pettype
     *
     * @return boolean
     */
    public function getPettype()
    {
        return $this->pettype;
    }

    /**
     * Set level
     *
     * @param boolean $level
     *
     * @return CharacterPet
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return boolean
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set exp
     *
     * @param integer $exp
     *
     * @return CharacterPet
     */
    public function setExp($exp)
    {
        $this->exp = $exp;

        return $this;
    }

    /**
     * Get exp
     *
     * @return integer
     */
    public function getExp()
    {
        return $this->exp;
    }

    /**
     * Set reactstate
     *
     * @param boolean $reactstate
     *
     * @return CharacterPet
     */
    public function setReactstate($reactstate)
    {
        $this->reactstate = $reactstate;

        return $this;
    }

    /**
     * Get reactstate
     *
     * @return boolean
     */
    public function getReactstate()
    {
        return $this->reactstate;
    }

    /**
     * Set loyaltypoints
     *
     * @param integer $loyaltypoints
     *
     * @return CharacterPet
     */
    public function setLoyaltypoints($loyaltypoints)
    {
        $this->loyaltypoints = $loyaltypoints;

        return $this;
    }

    /**
     * Get loyaltypoints
     *
     * @return integer
     */
    public function getLoyaltypoints()
    {
        return $this->loyaltypoints;
    }

    /**
     * Set loyalty
     *
     * @param integer $loyalty
     *
     * @return CharacterPet
     */
    public function setLoyalty($loyalty)
    {
        $this->loyalty = $loyalty;

        return $this;
    }

    /**
     * Get loyalty
     *
     * @return integer
     */
    public function getLoyalty()
    {
        return $this->loyalty;
    }

    /**
     * Set trainpoint
     *
     * @param integer $trainpoint
     *
     * @return CharacterPet
     */
    public function setTrainpoint($trainpoint)
    {
        $this->trainpoint = $trainpoint;

        return $this;
    }

    /**
     * Get trainpoint
     *
     * @return integer
     */
    public function getTrainpoint()
    {
        return $this->trainpoint;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return CharacterPet
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set renamed
     *
     * @param boolean $renamed
     *
     * @return CharacterPet
     */
    public function setRenamed($renamed)
    {
        $this->renamed = $renamed;

        return $this;
    }

    /**
     * Get renamed
     *
     * @return boolean
     */
    public function getRenamed()
    {
        return $this->renamed;
    }

    /**
     * Set slot
     *
     * @param boolean $slot
     *
     * @return CharacterPet
     */
    public function setSlot($slot)
    {
        $this->slot = $slot;

        return $this;
    }

    /**
     * Get slot
     *
     * @return boolean
     */
    public function getSlot()
    {
        return $this->slot;
    }

    /**
     * Set curhealth
     *
     * @param integer $curhealth
     *
     * @return CharacterPet
     */
    public function setCurhealth($curhealth)
    {
        $this->curhealth = $curhealth;

        return $this;
    }

    /**
     * Get curhealth
     *
     * @return integer
     */
    public function getCurhealth()
    {
        return $this->curhealth;
    }

    /**
     * Set curmana
     *
     * @param integer $curmana
     *
     * @return CharacterPet
     */
    public function setCurmana($curmana)
    {
        $this->curmana = $curmana;

        return $this;
    }

    /**
     * Get curmana
     *
     * @return integer
     */
    public function getCurmana()
    {
        return $this->curmana;
    }

    /**
     * Set curhappiness
     *
     * @param integer $curhappiness
     *
     * @return CharacterPet
     */
    public function setCurhappiness($curhappiness)
    {
        $this->curhappiness = $curhappiness;

        return $this;
    }

    /**
     * Get curhappiness
     *
     * @return integer
     */
    public function getCurhappiness()
    {
        return $this->curhappiness;
    }

    /**
     * Set savetime
     *
     * @param integer $savetime
     *
     * @return CharacterPet
     */
    public function setSavetime($savetime)
    {
        $this->savetime = $savetime;

        return $this;
    }

    /**
     * Get savetime
     *
     * @return integer
     */
    public function getSavetime()
    {
        return $this->savetime;
    }

    /**
     * Set resettalentsCost
     *
     * @param integer $resettalentsCost
     *
     * @return CharacterPet
     */
    public function setResettalentsCost($resettalentsCost)
    {
        $this->resettalentsCost = $resettalentsCost;

        return $this;
    }

    /**
     * Get resettalentsCost
     *
     * @return integer
     */
    public function getResettalentsCost()
    {
        return $this->resettalentsCost;
    }

    /**
     * Set resettalentsTime
     *
     * @param integer $resettalentsTime
     *
     * @return CharacterPet
     */
    public function setResettalentsTime($resettalentsTime)
    {
        $this->resettalentsTime = $resettalentsTime;

        return $this;
    }

    /**
     * Get resettalentsTime
     *
     * @return integer
     */
    public function getResettalentsTime()
    {
        return $this->resettalentsTime;
    }

    /**
     * Set abdata
     *
     * @param string $abdata
     *
     * @return CharacterPet
     */
    public function setAbdata($abdata)
    {
        $this->abdata = $abdata;

        return $this;
    }

    /**
     * Get abdata
     *
     * @return string
     */
    public function getAbdata()
    {
        return $this->abdata;
    }

    /**
     * Set teachspelldata
     *
     * @param string $teachspelldata
     *
     * @return CharacterPet
     */
    public function setTeachspelldata($teachspelldata)
    {
        $this->teachspelldata = $teachspelldata;

        return $this;
    }

    /**
     * Get teachspelldata
     *
     * @return string
     */
    public function getTeachspelldata()
    {
        return $this->teachspelldata;
    }
}
