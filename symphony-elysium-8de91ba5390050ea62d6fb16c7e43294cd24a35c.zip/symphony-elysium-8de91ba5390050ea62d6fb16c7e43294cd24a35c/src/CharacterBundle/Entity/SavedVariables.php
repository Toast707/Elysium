<?php

namespace CharacterBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * SavedVariables
 *
 * @ORM\Table(name="saved_variables")
 * @ORM\Entity
 */
class SavedVariables
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="NextArenaPointDistributionTime", type="bigint", nullable=false)
     */
    protected $nextarenapointdistributiontime = '0';

    /**
     * @var integer
     *
     * @ORM\Column(name="GmWeekBeginTime", type="bigint", nullable=false)
     */
    protected $gmweekbegintime = '0';

    /**
     * @var boolean
     *
     * @ORM\Column(name="allowed_pvp_rewards", type="boolean", nullable=false)
     */
    protected $allowedPvpRewards = '0';



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nextarenapointdistributiontime
     *
     * @param integer $nextarenapointdistributiontime
     *
     * @return SavedVariables
     */
    public function setNextarenapointdistributiontime($nextarenapointdistributiontime)
    {
        $this->nextarenapointdistributiontime = $nextarenapointdistributiontime;

        return $this;
    }

    /**
     * Get nextarenapointdistributiontime
     *
     * @return integer
     */
    public function getNextarenapointdistributiontime()
    {
        return $this->nextarenapointdistributiontime;
    }

    /**
     * Set gmweekbegintime
     *
     * @param integer $gmweekbegintime
     *
     * @return SavedVariables
     */
    public function setGmweekbegintime($gmweekbegintime)
    {
        $this->gmweekbegintime = $gmweekbegintime;

        return $this;
    }

    /**
     * Get gmweekbegintime
     *
     * @return integer
     */
    public function getGmweekbegintime()
    {
        return $this->gmweekbegintime;
    }

    /**
     * Set allowedPvpRewards
     *
     * @param boolean $allowedPvpRewards
     *
     * @return SavedVariables
     */
    public function setAllowedPvpRewards($allowedPvpRewards)
    {
        $this->allowedPvpRewards = $allowedPvpRewards;

        return $this;
    }

    /**
     * Get allowedPvpRewards
     *
     * @return boolean
     */
    public function getAllowedPvpRewards()
    {
        return $this->allowedPvpRewards;
    }
}
