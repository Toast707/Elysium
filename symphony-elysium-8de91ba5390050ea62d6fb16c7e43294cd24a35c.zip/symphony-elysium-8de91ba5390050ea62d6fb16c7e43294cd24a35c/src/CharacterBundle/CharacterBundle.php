<?php

namespace CharacterBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CharacterBundle extends Bundle
{
}
