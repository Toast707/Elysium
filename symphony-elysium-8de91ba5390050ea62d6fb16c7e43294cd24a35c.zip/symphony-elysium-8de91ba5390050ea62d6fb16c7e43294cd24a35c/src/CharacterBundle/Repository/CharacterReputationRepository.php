<?php

namespace CharacterBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class CharacterReputationRepository
 * @package CharacterBundle\Repository
 */
class CharacterReputationRepository extends EntityRepository
{
    /**
     * @param $guid
     * @return array
     */
    public function getActiveReputation($guid)
    {
        return $this->createQueryBuilder('cr')
            ->where('cr.guid = :guid')
            ->setParameter('guid', $guid)
            ->andWhere('BIT_AND(cr.flags, 1) = 1')
            ->getQuery()
            ->getResult();
    }
}