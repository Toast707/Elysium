<?php

namespace CharacterBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class GmTicketsRepository
 * @package CharacterBundle\Repository
 */
class GmTicketsRepository extends EntityRepository
{
    public function getOpenTicketsCount()
    {
        return $this->createQueryBuilder('t')
            ->select('COUNT(t), c.online')
            ->join('CharacterBundle:Characters', 'c', 'WITH', 't.guid = c.guid')
            ->where('t.closedBy = 0')
            ->andWhere('t.assignedTo = 0')
            ->groupBy('c.online')
            ->getQuery()
            ->getScalarResult();
    }

    public function getOpenTickets()
    {
        return $this->createQueryBuilder('t')
            ->select('t.ticketId, t.guid, t.name, c.race, c.class, c.gender, c.level, c.online, t.message, t.createdAt, t.mapId, t.posX, t.posY, t.posZ, t.lastModifiedTime, t.assignedTo, c2.name as AssignedToName, t.comment, t.response, t.escalated, t.viewed, t.securityNeeded')
            ->leftJoin('CharacterBundle:Characters', 'c', 'WITH', 'c.guid = t.guid')
            ->leftJoin('CharacterBundle:Characters', 'c2', 'WITH', 'c2.guid = t.assignedTo')
            ->where('t.closedBy = 0')
            ->getQuery()
            ->getResult();
    }


    /**
     * @param $start
     * @param $end
     * @return array
     */
    public function findByTimeBetween($start, $end, $characters)
    {
        return $this->createQueryBuilder('t')
            ->select('COUNT(t) as TicketCount, t.closedBy, c.name')
            ->join('CharacterBundle:Characters', 'c', 'WITH', 'c.guid = t.closedBy')
            ->where('t.closedBy > 0')
            ->andWhere('t.closedBy IN (:characters)')
            ->setParameter('characters', $characters)
            ->andWhere('t.createdAt BETWEEN :start AND :end')
            ->setParameter('start', $start->getTimestamp())
            ->setParameter('end', $end->getTimestamp())
            ->groupBy('t.closedBy')
            ->orderBy('TicketCount', 'DESC')
            ->getQuery()
            ->getResult();
    }
}