<?php

namespace CharacterBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class CharactersRepository
 * @package CharacterBundle\Repository
 */
class CharactersRepository extends EntityRepository
{
    /**
     * @param            $username
     * @param int        $offset
     * @param int        $limit
     * @param bool|false $gm
     * @param string     $sort
     * @param string     $dir
     * @return array
     */
    public function search($username, $offset = 0, $limit = 15, $gm = false, $sort = 'level', $dir = 'desc')
    {
        $query = $this->createQueryBuilder('c')
            ->select('c');

        if($gm)
        {
            $query = $query
                ->addSelect('a')
                ->leftJoin('c.account', 'a');
        }

        $query = $query
            ->addSelect('gm')
            ->leftJoin('c.guild', 'gm')
            ->where('c.name LIKE :username')
            ->setParameter('username', "%{$username}%")
            ->addOrderBy('c.level', 'DESC')
            ->addOrderBy('c.totaltime', 'DESC')
            ->getQuery()
            ->getResult();
        return $query;
    }

    /**
     * @return mixed
     */
    public function countOnlinePlayers()
    {
        return $this->createQueryBuilder('c')
            ->select('COUNT(c)')
            ->where('c.online = 1')
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @return mixed
     */
    public function countHordeOnlinePlayers()
    {
        return $this->createQueryBuilder('c')
            ->select('COUNT(c)')
            ->where('c.race IN (2,5,6,8)')
            ->andWhere('c.online = 1')
            ->getQuery()
            ->getSingleScalarResult();
    }

    /**
     * @return mixed
     */
    public function findOnePerAccount($accounts)
    {
        return $this->createQueryBuilder('c')
            ->where('c.account IN (:accounts)')
            ->setParameter('accounts', $accounts)
            ->groupBy('c.account')
            ->orderBy('c.name', 'ASC')
            ->getQuery()
            ->getResult();
    }
}