<?php

namespace CharacterBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class GuildRepository
 * @package CharacterBundle\Repository
 */
class GuildRepository extends EntityRepository
{
    /**
     * @param            $name
     * @param int        $offset
     * @param int        $limit
     * @param bool|false $gm
     * @param string     $sort
     * @param string     $dir
     * @return array
     */
    public function search($name, $offset = 0, $limit = 15, $gm = false, $sort = 'level', $dir = 'desc')
    {
        $query = $this->createQueryBuilder('g')
            ->where('g.name LIKE :name')
            ->setParameter('name', "%{$name}%")
            ->getQuery()
            ->getResult();
        return $query;
    }
}