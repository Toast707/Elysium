<?php

namespace CharacterBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;

/**
 * Class ArenaTeamRepository
 * @package CharacterBundle\Repository
 */
class ArenaTeamRepository extends EntityRepository
{
    /**
     * @param            $name
     * @param int        $offset
     * @param int        $limit
     * @param bool|false $gm
     * @param string     $sort
     * @param string     $dir
     * @return array
     */
    public function search($name, $offset = 0, $limit = 15, $gm = false, $sort = 'level', $dir = 'desc')
    {
        $query = $this->createQueryBuilder('at')
            ->where('at.name LIKE :name')
            ->setParameter('name', "%{$name}%")
            ->getQuery()
            ->getResult();
        return $query;
    }
}