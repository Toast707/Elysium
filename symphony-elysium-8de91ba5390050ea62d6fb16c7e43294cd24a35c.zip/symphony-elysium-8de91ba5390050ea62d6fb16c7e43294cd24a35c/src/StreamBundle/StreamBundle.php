<?php

namespace StreamBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class StreamBundle extends Bundle
{
}
