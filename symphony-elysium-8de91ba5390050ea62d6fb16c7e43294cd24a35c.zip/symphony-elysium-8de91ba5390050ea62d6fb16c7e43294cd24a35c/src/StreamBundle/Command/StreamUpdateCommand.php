<?php

namespace StreamBundle\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;

class StreamUpdateCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName("update:streams")
            ->setDescription("Update the streams.");
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $search     = strtolower($this->getContainer()->getParameter('stream_search'));
        $games      = $this->getContainer()->getParameter('stream_games');
        $blacklist  = $this->getContainer()->getParameter('stream_blacklist');

        // Get all the live streams
        $liveStreams = [];
        $streamsBatch = $this->getStreamsBatch('TWITCH', $search);
        if($streamsBatch)
        {
            foreach($streamsBatch['streams'] as $stream)
            {
                if(strpos(strtolower($stream['channel']['status']), $search) === false)
                    continue;
                if(!in_array(strtolower($stream['game']), $games) && strtolower($stream['game']) != $search)
                    continue;
                if(in_array($stream['channel']['name'], $blacklist))
                    continue;

                $streamer = [
                    'name'          => $stream['channel']['name'],
                    'display_name'  => $stream['channel']['display_name'],
                    'platform'      => 'twitch',
                    'status'        => $stream['channel']['status'],
                    'viewers'       => $stream['viewers'],
                ];
                $liveStreams[] = $streamer;
            }
        }

        $streamsBatch = $this->getStreamsBatch('HITBOX', $search);
        if($streamsBatch)
        {
            foreach($streamsBatch['livestream'] as $stream)
            {
                if(strpos(strtolower($stream['media_status']), "elysium") === false)
                    continue;
                if(!in_array(strtolower($stream['category_name']), $games) && strtolower($stream['category_name']) != $search)
                    continue;
                if(in_array($stream['media_name'], $blacklist))
                    continue;

                $streamer = [
                    'name'          => $stream['media_name'],
                    'display_name'  => $stream['media_display_name'],
                    'platform'      => 'hitbox',
                    'status'        => $stream['media_status'],
                    'viewers'       => $stream['media_views'],

                ];
                $liveStreams[] = $streamer;
            }
        }

        // Sort by viewers
        $viewers = [];
        foreach ($liveStreams as $key => $stream)
            $viewers[$key] = $stream['viewers'];
        array_multisort($viewers, SORT_DESC, $liveStreams);

        $redis = $this->getContainer()->get('snc_redis.default');
        $redis->set('streams', json_encode($liveStreams));
    }

    /**
     * @param $platform
     * @param $search
     * @return bool|mixed
     */
    protected function getStreamsBatch($platform, $search)
    {
        switch($platform)
        {
            case 'TWITCH':
                $url = "https://api.twitch.tv/kraken/search/streams?q={$search}&limit=100&offset=0";
                break;
            case 'HITBOX':
                $url = "https://api.hitbox.tv/media/live/list?search={$search}&fast=true";
                break;
            default:
                return false;
        }
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_HTTPHEADER => array(
                // Twitch API
                "Client-ID: {$this->getContainer()->getParameter('stream_client_id')}"
            ),
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_SSL_VERIFYPEER  => false,
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_URL             => $url
        ));
        $result = curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if($responseCode == 200)
            return json_decode($result, true);
        else
            return false;
    }
}