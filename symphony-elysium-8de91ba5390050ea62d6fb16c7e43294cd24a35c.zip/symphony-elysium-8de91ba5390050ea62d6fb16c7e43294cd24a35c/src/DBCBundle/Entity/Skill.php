<?php

namespace DBCBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Skill
 *
 * @ORM\Table
 * @ORM\Entity
 */
class Skill
{
	/**
	 * @var integer
	 *
     * @ORM\Id
     * @ORM\Column(name="id", type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
	 */
	protected $id;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="category", type="integer")
	 */
	protected $category;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="skill_cost", type="integer")
	 */
	protected $skillCost;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="display_name", type="string")
	 */
	protected $displayName;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="description", type="string")
	 */
	protected $description;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="description_mask", type="integer")
	 */
	protected $descriptionMask;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="spell_icon", type="integer")
	 */
	protected $spellIcon;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return int
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * @param int $category
     */
    public function setCategory($category)
    {
        $this->category = $category;
    }

    /**
     * @return int
     */
    public function getSkillCost()
    {
        return $this->skillCost;
    }

    /**
     * @param int $skillCost
     */
    public function setSkillCost($skillCost)
    {
        $this->skillCost = $skillCost;
    }

    /**
     * @return string
     */
    public function getDisplayName()
    {
        return $this->displayName;
    }

    /**
     * @param string $displayName
     */
    public function setDisplayName($displayName)
    {
        $this->displayName = $displayName;
    }

    /**
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param string $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return int
     */
    public function getDescriptionMask()
    {
        return $this->descriptionMask;
    }

    /**
     * @param int $descriptionMask
     */
    public function setDescriptionMask($descriptionMask)
    {
        $this->descriptionMask = $descriptionMask;
    }

    /**
     * @return int
     */
    public function getSpellIcon()
    {
        return $this->spellIcon;
    }

    /**
     * @param int $spellIcon
     */
    public function setSpellIcon($spellIcon)
    {
        $this->spellIcon = $spellIcon;
    }
}