<?php

namespace DBCBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Faction
 *
 * @ORM\Table
 * @ORM\Entity
 */
class Faction
{
	/**
	 * @var integer
	 *
     * @ORM\Id
	 * @ORM\Column(name="id", type="integer")
     * @ORM\GeneratedValue(strategy="IDENTITY")
	 */
	protected $id;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="index", type="integer")
	 */
	protected $index;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="name_enUs", type="text")
	 */
	protected $nameEnUs;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="race_mask", type="integer")
	 */
	protected $raceMask0;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="race_mask_1", type="integer")
	 */
	protected $raceMask1;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="race_mask_2", type="integer")
	 */
	protected $raceMask2;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="race_mask_3", type="integer")
	 */
	protected $raceMask3;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="class_mask", type="integer")
	 */
	protected $classMask0;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="class_mask_1", type="integer")
	 */
	protected $classMask1;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="class_mask_2", type="integer")
	 */
	protected $classMask2;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="class_mask_3", type="integer")
	 */
	protected $classMask3;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="base", type="integer")
	 */
	protected $base0;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="base_1", type="integer")
	 */
	protected $base1;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="base_2", type="integer")
	 */
	protected $base2;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="base_3", type="integer")
	 */
	protected $base3;

	/**
	 * @var integer
	 *
	 * @ORM\Column(name="parentFactionID", type="integer")
	 */
	protected $parentFactionId;

	/**
	 * @return int
	 */
	public function getId()
	{
		return $this->id;
	}

	/**
	 * @param int $id
	 */
	public function setId($id)
	{
		$this->id = $id;
	}

	/**
	 * @return int
	 */
	public function getIndex()
	{
		return $this->index;
	}

	/**
	 * @param int $index
	 */
	public function setIndex($index)
	{
		$this->index = $index;
	}

	/**
	 * @return string
	 */
	public function getNameEnUs()
	{
		return $this->nameEnUs;
	}

	/**
	 * @param string $nameEnUs
	 */
	public function setNameEnUs($nameEnUs)
	{
		$this->nameEnUs = $nameEnUs;
	}

	/**
	 * @param $id
	 * @return int
	 */
	public function getRaceMask($id)
	{
		$racemask = "raceMask{$id}";
		return $this->$racemask;
	}

	/**
	 * @return int
	 */
	public function getRaceMask0()
	{
		return $this->raceMask0;
	}

	/**
	 * @param int $raceMask0
	 */
	public function setRaceMask0($raceMask0)
	{
		$this->raceMask0 = $raceMask0;
	}

	/**
	 * @return int
	 */
	public function getRaceMask1()
	{
		return $this->raceMask1;
	}

	/**
	 * @param int $raceMask1
	 */
	public function setRaceMask1($raceMask1)
	{
		$this->raceMask1 = $raceMask1;
	}

	/**
	 * @return int
	 */
	public function getRaceMask2()
	{
		return $this->raceMask2;
	}

	/**
	 * @param int $raceMask2
	 */
	public function setRaceMask2($raceMask2)
	{
		$this->raceMask2 = $raceMask2;
	}

	/**
	 * @return int
	 */
	public function getRaceMask3()
	{
		return $this->raceMask3;
	}

	/**
	 * @param int $raceMask3
	 */
	public function setRaceMask3($raceMask3)
	{
		$this->raceMask3 = $raceMask3;
	}

	/**
	 * @param $id
	 * @return int
	 */
	public function getClassMask($id)
	{
		$classmask = "classMask{$id}";
		return $this->$classmask;
	}

	/**
	 * @return int
	 */
	public function getClassMask0()
	{
		return $this->classMask0;
	}

	/**
	 * @param int $classMask0
	 */
	public function setClassMask0($classMask0)
	{
		$this->classMask0 = $classMask0;
	}

	/**
	 * @return int
	 */
	public function getClassMask1()
	{
		return $this->classMask1;
	}

	/**
	 * @param int $classMask1
	 */
	public function setClassMask1($classMask1)
	{
		$this->classMask1 = $classMask1;
	}

	/**
	 * @return int
	 */
	public function getClassMask2()
	{
		return $this->classMask2;
	}

	/**
	 * @param int $classMask2
	 */
	public function setClassMask2($classMask2)
	{
		$this->classMask2 = $classMask2;
	}

	/**
	 * @return int
	 */
	public function getClassMask3()
	{
		return $this->classMask3;
	}

	/**
	 * @param int $classMask3
	 */
	public function setClassMask3($classMask3)
	{
		$this->classMask3 = $classMask3;
	}

	/**
	 * @param $id
	 * @return int
	 */
	public function getBase($id)
	{
		$base = "base{$id}";
		return $this->$base;
	}

	/**
	 * @return int
	 */
	public function getBase0()
	{
		return $this->base0;
	}

	/**
	 * @param int $base0
	 */
	public function setBase0($base0)
	{
		$this->base0 = $base0;
	}

	/**
	 * @return int
	 */
	public function getBase1()
	{
		return $this->base1;
	}

	/**
	 * @param int $base1
	 */
	public function setBase1($base1)
	{
		$this->base1 = $base1;
	}

	/**
	 * @return int
	 */
	public function getBase2()
	{
		return $this->base2;
	}

	/**
	 * @param int $base2
	 */
	public function setBase2($base2)
	{
		$this->base2 = $base2;
	}

	/**
	 * @return int
	 */
	public function getBase3()
	{
		return $this->base3;
	}

	/**
	 * @param int $base3
	 */
	public function setBase3($base3)
	{
		$this->base3 = $base3;
	}

	/**
	 * @return int
	 */
	public function getParentFactionId()
	{
		return $this->parentFactionId;
	}

	/**
	 * @param int $parentFactionId
	 */
	public function setParentFactionId($parentFactionId)
	{
		$this->parentFactionId = $parentFactionId;
	}
}