<?php

namespace DBCBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DBCBundle extends Bundle
{
}
