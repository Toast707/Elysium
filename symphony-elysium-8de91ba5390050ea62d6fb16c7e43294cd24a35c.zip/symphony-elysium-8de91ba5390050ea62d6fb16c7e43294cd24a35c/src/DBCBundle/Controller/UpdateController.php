<?php

namespace DBCBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class UpdateController extends Controller
{
    /**
     * @Route("/admin/update/reputation", name="update_reputation")
     * @Security("is_granted('ROLE_GM6')")
     */
    public function reputationAction(Request $request)
    {
        $redis = $this->get('snc_redis.default');
        $reputation = $this->getDoctrine()->getRepository('DBCBundle:Faction', 'web')->findAll();
        $reputations = [];
        foreach($reputation as $faction)
        {
            if($faction->getIndex() > -1)
                $reputations[$faction->getId()] = $faction;
        }
        $redis->set('web:reputation', serialize($reputations));
        $redis->ttl('web:reputation');
        return $this->render('update/index.html.twig', array('info' => 'DBC Faction'));
    }

    /**
     * @Route("/admin/update/skill", name="update_skill")
     * @Security("is_granted('ROLE_GM6')")
     */
    public function skillAction(Request $request)
    {
        $redis = $this->get('snc_redis.default');
        $skills = $this->getDoctrine()->getRepository('DBCBundle:Skill', 'web')->findAll();
        $result = [];
        foreach($skills as $skill)
            $result[$skill->getId()] = $skill;
        $redis->set('web:skill', serialize($result));
        $redis->ttl('web:skill');
        return $this->render('update/index.html.twig', array('info' => 'DBC Skill'));
    }
}