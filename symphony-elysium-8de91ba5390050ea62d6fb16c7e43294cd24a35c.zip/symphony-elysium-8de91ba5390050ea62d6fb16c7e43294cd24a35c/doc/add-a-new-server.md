# Add a server

There are multiple places where servers are used:

* Status page
* GM UI
* GM Armory


**In this example, we want to add a 6th realm named 'Gurubashi PvP'.**

### Parameters
#### Realm parameters
Open `app/config/parameters.yml`.

Find
```yml
    realms:
        1:
            name: 'Anathema PvP'
```

`1`: `logon.realmlist#id`
`name`: `logon.realmlist#name`

```yml
        6:
            name: 'Gurubashi PvP'
```

Conclusion:

```yml
    realms:
        1:
            name: 'Anathema PvP'
        6:
            name: 'Gurubashi PvP'
```

#### Database connection

In order to get data, you need to add a connection to this realm's characters database.

```yml
    database_realm6_host:
    database_realm6_port:
    database_realm6_name:
    database_realm6_user:
    database_realm6_password:
```

Realm will most likely have logs, so you also need to add this realm's logs database:

```yml
    database_log6_host:
    database_log6_port:
    database_log6_name:
    database_log6_user:
    database_log6_password:
```

Save and exit the file.

Don't forget to add the new parameters to the base file `app/config/parameters.yml.dist`.

If you are in production environment, you need to [empty the cache](symfony-cache.md).

### Config
Open `app/config/config.yml`.

Find
```yml
doctrine:
    dbal:
        default_connection: auth
        connections:
```

Add the connection to the character database:

```yml
            realm6:
                driver:   pdo_mysql
                host:     "%database_realm6_host%"
                port:     "%database_realm6_port%"
                dbname:   "%database_realm6_name%"
                user:     "%database_realm6_user%"
                password: "%database_realm6_password%"
                charset:  UTF8
```

And the connection to the logs database:

```yml
            log6:
                driver:   pdo_mysql
                host:     "%database_log6_host%"
                port:     "%database_log6_port%"
                dbname:   "%database_log6_name%"
                user:     "%database_log6_user%"
                password: "%database_log6_password%"
                charset:  UTF8
```

Find
```yml
    orm:
        auto_generate_proxy_classes: "%kernel.debug%"
        default_entity_manager: web
        entity_managers:
```

Create two new entity managers for the new connections:

```yml
            # Gurubashi PvP
            realm6:
                connection: realm6
                naming_strategy: doctrine.orm.naming_strategy.underscore
                mappings:
                    CharacterBundle: ~
                    DBCBundle: ~
            log6:
                connection: log6
                naming_strategy: doctrine.orm.naming_strategy.underscore
                mappings:
                    LogBundle: ~
```

Save and exit.

Open `app/config/config_prod.yml`.

Find
```yml
doctrine:
    orm:
        auto_generate_proxy_classes: "%kernel.debug%"
        default_entity_manager: web
        entity_managers:
```

Create two new entity managers for the new connections:

```yml
            # Gurubashi PvP
            realm6:
                connection: realm6
                naming_strategy: doctrine.orm.naming_strategy.underscore
                metadata_cache_driver: redis
                query_cache_driver: redis
                mappings:
                    CharacterBundle: ~
                    DBCBundle: ~
            log6:
                connection: log6
                naming_strategy: doctrine.orm.naming_strategy.underscore
                metadata_cache_driver: redis
                query_cache_driver: redis
                mappings:
                    LogBundle: ~
```

Save and exit.

At this point you should commit the changes.

Update the redis cache of the realms by going to the following path `/admin/update/realm`.