# Deal with Symfony Cache

After editing a view or changing the parameters, you need to reset the cache in the right environment.

## On production
1. Go to the website root folder which could be `/var/www/elysium-project.org`
2. Run `php bin/console cache:clear --env=prod` or minified version `php bin/console c:c --env=prod`
3. Now that the cache is empty, Symfony needs to be able to recreate it, you need to give Symfony the permission to do so with this command `chown -R www-data:www-data /var/www/elysium-project.org/*`

## Locally
1. Go to the website root folder which could be `D:/web/www/elysium-project.org`
2. Run `php bin/console cache:clear` or minified version `php bin/console c:c`