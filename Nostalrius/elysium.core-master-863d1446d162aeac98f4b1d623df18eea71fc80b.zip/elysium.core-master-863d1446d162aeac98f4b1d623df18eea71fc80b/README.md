Development Regulations


Prefix your subject with a code realm it relates to

Separate subject from body with a blank line

Limit the subject line to 50 characters

Capitalize the subject line

Do not end the subject line with a period

Use the imperative mood in the subject line

Wrap the body at 72 characters

Use the body to explain what and why vs. how

Huge rework always takes a separate branch

In case of typo try to fix the existing commit if possible

C++ 11 code standarts are welcome

Nice code formatting is welcome as well

Define spaces usage instead of tab symbols

Force push is not welcome

Always pull before pushing
