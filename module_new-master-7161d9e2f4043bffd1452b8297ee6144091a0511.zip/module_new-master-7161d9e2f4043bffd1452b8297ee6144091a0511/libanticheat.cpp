#include "libanticheat.h"

#include "Policies/SingletonImp.h"

#include "World.h"
#include "Player.h"
#include "WorldSession.h"
#include "AccountMgr.h"
#include "MasterPlayer.h"
#include "ObjectAccessor.h"
#include "Channel.h"
#include "ChannelMgr.h"

#include "Antispam/Antispam.h"
#include "MovementAnticheat/Cheat.h"
#include "WardenAnticheat/Warden.h"
#include "WardenAnticheat/WardenWin.h"
#include "WardenAnticheat/WardenMac.h"

INSTANTIATE_SINGLETON_1(AnticheatConfig);

void NostalriusAnticheatLib::LoadAnticheatData()
{
    sLog.outString("Loading antispam system ...");
    sAntispam->loadFromDB();

    sLog.outString("Loading anticheat system ...");
    sCheatsMgr->LoadFromDB();

    sLog.outString("Loading warden checks...");
    _wardenMgr->LoadWardenChecks();
	
    sLog.outString("Initialize module storage...");
    sLog.outString("Loading warden modules...");
    _wardenMgr->LoadWardenModules();
}

void NostalriusAnticheatLib::LoadConfig()
{
    if (!sAcConfig.SetSource(_LIB_ANTICHEAT_CONFIG))
        sLog.outError("[Anticheat] Could not find configuration file %s.", _LIB_ANTICHEAT_CONFIG);

    sAcConfig.loadConfigSettings();
    sCheatsMgr->LoadConfig();
    sAntispam->loadConfig();
}

PlayerAnticheatInterface* NostalriusAnticheatLib::CreateAnticheatFor(Player* player)
{
    PlayerCheatData* cd = new PlayerCheatData(player);
    cd->Init();
    return cd;
}

WardenInterface* NostalriusAnticheatLib::CreateWardenFor(WorldSession* client, BigNumber* K)
{
    Warden* _warden;
    ClientOSType os = client->GetOS();

    if (os == CLIENT_OS_MAC)
        _warden = new WardenMac(client);
    else if (os == CLIENT_OS_WIN)
        _warden = new WardenWin(client);
    else
        return nullptr;

    _warden->Init(K);

    return _warden;
}

NostalriusAnticheatLib* NostalriusAnticheatLib::instance()
{
    static NostalriusAnticheatLib i;
    return &i;
}

std::string NostalriusAnticheatLib::NormalizeMessage(const std::string &msg, uint32 mask)
{
    return sAntispam->NormalizeMessage(msg, mask);
}

bool NostalriusAnticheatLib::FilterChatMessage(PlayerPointer playerPointer, uint32 type, const std::string &msg)
{
    return sAntispam->FilterChatMessage(playerPointer, type, msg);
}

void NostalriusAnticheatLib::mute(PlayerPointer playerPointer)
{
    sAntispam->mute(playerPointer);
}

void NostalriusAnticheatLib::unmute(PlayerPointer playerPointer)
{
    sAntispam->unmute(playerPointer);
}

void NostalriusAnticheatLib::showMuted(WorldSession* session)
{
    sAntispam->showMuted(session);
}

AnticheatConfig::AnticheatConfig()
{
    for (int i = 0; i < CONFIG_INT32_AC_COUNT; ++i)
        m_configInt32Values[i] = 0;

    for (int i = 0; i < CONFIG_UINT32_AC_COUNT; ++i)
        m_configUInt32Values[i] = 0;

    for (int i = 0; i < CONFIG_BOOL_AC_COUNT; ++i)
        m_configBoolValues[i] = false;
}

void AnticheatConfig::loadConfigSettings()
{
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_ENABLED, "Anticheat.Enable", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_ANTI_MULTI_JUMP_ENABLED, "Anticheat.AntiMultiJump.Enable", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_ANTI_SPEED_HACK_ENABLED, "Anticheat.AntiSpeedHack.Enable", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_USE_INTERPOLATION, "Anticheat.AntiSpeedHack.UseInterpolation", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_ANTI_WALL_CLIMB_ENABLED, "Anticheat.AntiWallClimb.Enable", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_ANTI_WATER_WALK_ENABLED, "Anticheat.AntiWaterWalk.Enable", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_NOTIFY_CHEATERS, "Anticheat.NotifyCheaters", false);
    setConfig(CONFIG_BOOL_AC_ANTICHEAT_LOG_DATA, "Anticheat.LogData", false);
    setConfig(CONFIG_BOOL_AC_ANTISPAM_ENABLED, "Antispam.Enable", false);

    setConfig(CONFIG_INT32_AC_ANTICHEAT_MAX_ALLOWED_DESYNC, "Anticheat.MaxAllowedDesync", 0);

    setConfig(CONFIG_UINT32_AC_ANTICHEAT_GM_ANNOUNCE_MASK, "Anticheat.GMAnnounceMask", 0);
    setConfig(CONFIG_UINT32_AC_ANTISPAM_MAX_RESTRICTION_LEVEL, "Antispam.MaxRestrictionLevel", 20);
    setConfig(CONFIG_UINT32_AC_ANTISPAM_ORIGINAL_NORMALIZE_MASK, "Antispam.OriginalNormalizeMask", 0);
    setConfig(CONFIG_UINT32_AC_ANTISPAM_FULLY_NORMALIZE_MASK, "Antispam.FullyNormalizeMask", 0);
    setConfig(CONFIG_UINT32_AC_ANTISPAM_SCORE_THRESHOLD, "Antispam.ScoreThreshold", 4);
    setConfig(CONFIG_UINT32_AC_ANTISPAM_MUTETIME, "Antispam.Mutetime", 3600);
    setConfig(CONFIG_UINT32_AC_ANTISPAM_CHAT_MASK, "Antispam.ChatMask", 0);
    setConfig(CONFIG_UINT32_AC_WARDEN_MEM_CHECKS_COUNT, "Warden.MemChecksCount", 10);
    setConfig(CONFIG_UINT32_AC_WARDEN_OTHER_CHECKS_COUNT, "Warden.OtherChecksCount", 6);
}

void AnticheatConfig::setConfig(AnticheatConfigInt32Values index, char const* fieldname, int32 defvalue)
{
    setConfig(index, sAcConfig.GetIntDefault(fieldname, defvalue));
}

void AnticheatConfig::setConfig(AnticheatConfigUInt32Values index, char const* fieldname, uint32 defvalue)
{
    setConfig(index, sAcConfig.GetIntDefault(fieldname, defvalue));
}

void AnticheatConfig::setConfig(AnticheatConfigBoolValues index, char const* fieldname, bool defvalue)
{
    setConfig(index, sAcConfig.GetBoolDefault(fieldname, defvalue));
}

AnticheatLibInterface* GetAnticheatLib()
{
    return NostalriusAnticheatLib::instance();
}