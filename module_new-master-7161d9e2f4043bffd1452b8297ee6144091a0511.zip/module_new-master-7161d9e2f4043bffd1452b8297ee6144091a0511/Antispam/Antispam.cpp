#include <regex>
#include <string>
#include <algorithm>

#include "Database/DatabaseEnv.h"
#include "Util.h"
#include "World.h"
#include "ChannelMgr.h"
#include "Chat.h"
#include "Antispam.h"
#include "module/libanticheat.h"

Antispam::Antispam()
    : m_enabled(false), m_restrictionLevel(0), m_originalNormalizeMask(0), m_fullyNormalizeMask(0),
        m_threshold(0), m_mutetime(0), m_chatMask(0)
{
    
}

void Antispam::loadFromDB()
{
    sLog.outString("Loading table 'antispam_blacklist'");
    m_blackList.clear();

    QueryResult* result = WorldDatabase.Query("SELECT * FROM antispam_blacklist");
    if (result)
    {
        do
        {
            auto fields = result->Fetch();
            m_blackList.insert(fields[0].GetCppString());
        }
        while (result->NextRow());
        delete result;
    }

    sLog.outString(">> %u blacklist words loaded", m_blackList.size());
    sLog.outString();

    sLog.outString("Loading table 'antispam_replacement'");
    m_replacement.clear();

    result = WorldDatabase.Query("SELECT * FROM antispam_replacement");
    if (result)
    {
        do
        {
            auto fields = result->Fetch();
            m_replacement[fields[0].GetCppString()] = fields[1].GetCppString();
        }
        while (result->NextRow());
        delete result;
    }

    sLog.outString(">> %u replacements loaded", m_replacement.size());
    sLog.outString();

    sLog.outString("Loading table 'antispam_scores'");

    m_scores[MSG_TYPE_NORMALIZED].clear();
    m_scores[MSG_TYPE_ORIGINAL].clear();

    result = WorldDatabase.Query("SELECT * FROM antispam_scores");
    if (result)
    {
        do
        {
            auto fields = result->Fetch();
            m_scores[fields[2].GetUInt8()][fields[0].GetCppString()] = fields[1].GetInt32();
        }
        while (result->NextRow());
        delete result;
    }

    sLog.outString(">> %u scores loaded", m_scores[MSG_TYPE_NORMALIZED].size() + m_scores[MSG_TYPE_ORIGINAL].size());
    sLog.outString();
    
    sLog.outString("Loading table 'antispam_unicode'");
    m_unicode.clear();

    result = WorldDatabase.Query("SELECT * FROM antispam_unicode");
    if (result)
    {
        std::wostringstream wss;
        do
        {
            auto fields = result->Fetch();
            wss.str(std::wstring());
            wss << wchar_t(fields[0].GetUInt32());
            std::wstring key = wss.str();
            wss.str(std::wstring());
            wss << wchar_t(fields[1].GetUInt32());
            std::wstring value = wss.str();
            m_unicode[key] = value;
        }
        while (result->NextRow());
        delete result;
    }

    sLog.outString(">> %u unicode symbols loaded", m_unicode.size());
    sLog.outString();
}

void Antispam::loadConfig()
{
    loadFromDB(); // temporary solution for reload from game

    m_enabled = sAcConfig.getConfig(CONFIG_BOOL_AC_ANTISPAM_ENABLED);
    m_restrictionLevel = sAcConfig.getConfig(CONFIG_UINT32_AC_ANTISPAM_MAX_RESTRICTION_LEVEL);
    m_originalNormalizeMask = sAcConfig.getConfig(CONFIG_UINT32_AC_ANTISPAM_ORIGINAL_NORMALIZE_MASK);
    m_fullyNormalizeMask = sAcConfig.getConfig(CONFIG_UINT32_AC_ANTISPAM_FULLY_NORMALIZE_MASK);
    m_threshold = sAcConfig.getConfig(CONFIG_UINT32_AC_ANTISPAM_SCORE_THRESHOLD);
    m_mutetime = sAcConfig.getConfig(CONFIG_UINT32_AC_ANTISPAM_MUTETIME);
    m_chatMask = sAcConfig.getConfig(CONFIG_UINT32_AC_ANTISPAM_CHAT_MASK);
}

static inline void ReplaceAll(std::string &str, const std::string& from, const std::string& to)
{
    size_t startPos = 0;
    while ((startPos = str.find(from, startPos)) != std::string::npos)
    {
        str.replace(startPos, from.length(), to);
        startPos += to.length();
    }
}

static inline void ReplaceAllW(std::wstring &str, const std::wstring& from, const std::wstring& to)
{
    size_t startPos = 0;
    while ((startPos = str.find(from, startPos)) != std::wstring::npos)
    {
        str.replace(startPos, from.length(), to);
        startPos += to.length();
    }
}

std::string Antispam::NormalizeMessage(const std::string& msg, uint32 mask)
{
    auto newMsg = msg;

    if (!mask)
        mask = m_fullyNormalizeMask;

    if (mask & NF_CUT_COLOR)
    {
        static std::regex regex1("(\\|c\\w{8})");
        static std::regex regex2("(\\|H[\\w|\\W]{1,}\\|h)");
        newMsg = std::regex_replace(newMsg, regex1, "");
        ReplaceAll(newMsg, "|h|r", "");
        newMsg = std::regex_replace(newMsg, regex2, "");
    }

    if (mask & NF_REPLACE_WORDS)
        for (auto& e : m_replacement)
            ReplaceAll(newMsg, e.first, e.second);
    
    if (mask & NF_CUT_CTRL)
    {
        static std::regex regex4("([[:cntrl:]]+)");
        newMsg = std::regex_replace(newMsg, regex4, "");
    }

    if (mask & NF_CUT_PUNCT)
    {
        static std::regex regex5("([[:punct:]]+)");
        newMsg = std::regex_replace(newMsg, regex5, "");
    }

    if (mask & NF_CUT_SPACE)
    {
        static std::regex regex6("(\\s+|_)");
        newMsg = std::regex_replace(newMsg, regex6, "");
    }

    if (mask & NF_CUT_NUMBERS)
    {
        static std::regex regex3("(\\d+)");
        newMsg = std::regex_replace(newMsg, regex3, "");
    }

    if (mask & NF_REPLACE_UNICODE)
    {
        std::wstring w_tempMsg, w_tempMsg2;
        Utf8toWStr(newMsg, w_tempMsg);
        wstrToUpper(w_tempMsg);

        if (!isBasicLatinString(w_tempMsg, true))
        {
            for (auto& s : m_unicode)
                ReplaceAllW(w_tempMsg, s.first, s.second);

            if (mask & NF_REMOVE_NON_LATIN)
            {
                for (size_t i = 0; i < w_tempMsg.size(); ++i)
                    if (isBasicLatinCharacter(w_tempMsg[i]) || isNumeric(w_tempMsg[i]))
                        w_tempMsg2.push_back(w_tempMsg[i]);
            }
            else
                w_tempMsg2 = w_tempMsg;
        }
        else
            w_tempMsg2 = w_tempMsg;

        newMsg = std::string(w_tempMsg2.begin(), w_tempMsg2.end());
    }
    else
        std::transform(newMsg.begin(), newMsg.end(), newMsg.begin(), ::toupper);

    if (mask & NF_REMOVE_REPEATS)
        newMsg.erase(std::unique(newMsg.begin(), newMsg.end()), newMsg.end());

    return newMsg;
}

bool Antispam::FilterChatMessage(PlayerPointer playerPointer, uint32 type, const std::string &msg)
{
    if (!m_enabled || playerPointer->isGameMaster())
        return false;

    if (playerPointer->getLevel() > m_restrictionLevel)
        return false;
    
    if (m_chatMask && (m_chatMask & (1 << type)) == 0)
        return false;

    auto itr = m_mutedAccounts.find(playerPointer->GetSession()->GetUsername());
    if (itr != m_mutedAccounts.end())
    {
        if (itr->second < time(nullptr))
            m_mutedAccounts.erase(itr);
        else
            return true;
    }

    auto normMsg = NormalizeMessage(msg);
    auto origMsg = NormalizeMessage(msg, m_originalNormalizeMask);

    bool block = false;
    uint32 score = 0;

    for (auto& word : m_blackList)
    {
        if (origMsg.find(word) != std::string::npos ||
            normMsg.find(word) != std::string::npos)
        {
            block = true;
            break;
        }
    }

    if (!block)
    {
        for (auto& word : m_scores[MSG_TYPE_NORMALIZED])
            if (normMsg.find(word.first) != std::string::npos)
                score += word.second;

        for (auto& word : m_scores[MSG_TYPE_ORIGINAL])
            if (origMsg.find(word.first) != std::string::npos)
                score += word.second;

        if (score > m_threshold)
            block = true;
    }

    if (block)
    {
        mute(playerPointer);
        ChannelMgr::AnnounceBothFactionsChannel("ChatSpam", playerPointer->GetObjectGuid(), msg.c_str());
    }

    return block;
}

void Antispam::mute(PlayerPointer playerPointer)
{
    std::string account = playerPointer->GetSession()->GetUsername();
    if (m_mutedAccounts.find(account) == m_mutedAccounts.end())
        m_mutedAccounts[account] = time(nullptr) + m_mutetime;
}

void Antispam::unmute(PlayerPointer playerPointer)
{
    m_mutedAccounts.erase(playerPointer->GetSession()->GetUsername());
}

void Antispam::showMuted(WorldSession* session)
{
    if (m_mutedAccounts.empty())
    {
        ChatHandler(session).SendSysMessage("No muted spamers");
        return;
    }

    ChatHandler(session).SendSysMessage("Muted spamers accounts list:");
    for (auto& e : m_mutedAccounts)
        ChatHandler(session).SendSysMessage(e.first.c_str());
}