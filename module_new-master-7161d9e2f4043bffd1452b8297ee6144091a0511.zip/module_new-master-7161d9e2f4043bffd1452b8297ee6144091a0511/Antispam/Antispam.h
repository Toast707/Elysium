#include <string>

#include "Util.h"
#include "World.h"
#include "ChannelMgr.h"
#include "module/libanticheat.h"

enum NormalizeFlags
{
    NF_CUT_COLOR        = 0x001,
    NF_REPLACE_WORDS    = 0x002,
    NF_CUT_SPACE        = 0x004,
    NF_CUT_CTRL         = 0x008,
    NF_CUT_PUNCT        = 0x010,
    NF_CUT_NUMBERS      = 0x020,
    NF_REPLACE_UNICODE  = 0x040,
    NF_REMOVE_REPEATS   = 0x080,
    NF_REMOVE_NON_LATIN = 0x100
};
    
enum MessageType
{
    MSG_TYPE_NORMALIZED,
    MSG_TYPE_ORIGINAL,
    MSG_TYPE_MAX
};

typedef std::unordered_set<std::string> StringSet;
typedef std::unordered_map<std::wstring, std::wstring> UnicodeMap;
typedef std::unordered_map<std::string, std::string> StringMap;
typedef std::unordered_map<std::string, int32> ScoreMap;
typedef std::unordered_map<std::string, time_t> MutedAccountsMap;

class Antispam
{
    friend class ACE_Singleton<Antispam, ACE_Null_Mutex>;
    public:
        Antispam();
        ~Antispam() {}
        
        void loadFromDB();
        void loadConfig();
        
        std::string NormalizeMessage(const std::string& msg, uint32 mask = 0);
        bool FilterChatMessage(PlayerPointer playerPointer, uint32 type, const std::string &msg);
        
        void mute(PlayerPointer playerPointer);
        void unmute(PlayerPointer playerPointer);
        void showMuted(WorldSession* session);

    private:
        bool m_enabled;
        uint8 m_restrictionLevel;
        uint16 m_originalNormalizeMask;
        uint16 m_fullyNormalizeMask;
        uint32 m_threshold;
        uint32 m_mutetime;
        uint32 m_chatMask;

        StringSet m_blackList;
        StringMap m_replacement;
        ScoreMap m_scores[MSG_TYPE_MAX];
        UnicodeMap m_unicode;

        MutedAccountsMap m_mutedAccounts;
};

#define sAntispam ACE_Singleton<Antispam, ACE_Null_Mutex>::instance()
