/*
SQLyog Ultimate
MySQL - 5.7.14-log : Database - nost_world
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `antispam_blacklist` */

DROP TABLE IF EXISTS `antispam_blacklist`;

CREATE TABLE `antispam_blacklist` (
  `word` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `antispam_blacklist` */

LOCK TABLES `antispam_blacklist` WRITE;

insert  into `antispam_blacklist`(`word`) values ('4GAMEPOWER'),('G4WOW'),('GOLD4MMO'),('GOLDDEAL'),('GOLDINSIDER'),('ILOVEUGOLD'),('ITEM4GAME'),('ITEM4WOW'),('MMOLORD'),('MONEYFORGAMES'),('NOST100'),('OKOGAMES'),('OKOGOMES'),('SINBAGAME'),('SINBAGOLD'),('SINBAONLINE'),('SUSANGAME'),('WTSITEM'),('X2GOLD');

UNLOCK TABLES;

/*Table structure for table `antispam_replacement` */

DROP TABLE IF EXISTS `antispam_replacement`;

CREATE TABLE `antispam_replacement` (
  `from` varchar(32) NOT NULL DEFAULT '',
  `to` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`from`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `antispam_replacement` */

LOCK TABLES `antispam_replacement` WRITE;

insert  into `antispam_replacement`(`from`,`to`) values ('\\\\/\\\\/','W'),('/\\\\/\\\\','M'),('/\\\\','A'),('0','O'),('3','E'),('...hic!',''),('()','O');

UNLOCK TABLES;

/*Table structure for table `antispam_scores` */

DROP TABLE IF EXISTS `antispam_scores`;

CREATE TABLE `antispam_scores` (
  `word` varchar(32) NOT NULL DEFAULT '',
  `score` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `antispam_scores` */

LOCK TABLES `antispam_scores` WRITE;

insert  into `antispam_scores`(`word`,`score`,`type`) values ('>>',1,1),('<<',1,1),('50G',1,1),('$',2,1),('100',2,1),('\\\\',2,1),('ACOUNT',1,0),('CHEAP',1,0),('LEVELING',1,0),('LEVLING',1,0),('LEVILING',1,0),('LVLING',1,0),('SAFE',1,0),('SERVICE',1,0),('NOST',1,0),('COM',1,0),('PRICE',2,0),('GOLD',2,0),('SKYPE',2,0),('EPIC',2,0),('DOLARS',2,0),('PROFESIONAL',2,0),('RELIABLE',2,0),('PROMOTION',2,0),('DELIVER',2,0),('NAX',2,0),('GAMES',2,0),('GRETINGS',2,0),('WEBSITE',2,0),('GOID',2,0),('ITEM4',5,1),('1OO',2,1),('POWER',1,0),('SELGOLD',2,0);

UNLOCK TABLES;

/*Table structure for table `antispam_unicode` */

DROP TABLE IF EXISTS `antispam_unicode`;

CREATE TABLE `antispam_unicode` (
  `from` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `to` mediumint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`from`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `antispam_unicode` */

LOCK TABLES `antispam_unicode` WRITE;

insert  into `antispam_unicode`(`from`,`to`) values (1040,65);

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
