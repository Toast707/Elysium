/*
* Copyright (C) 2010-2014 Anathema Engine project <http://valkyrie-wow.com/> 
* Copyright (C) C(ontinued)-MaNGOS <http://cmangos.net/>
*/

#ifndef __WARDEN_WIN_H
#define __WARDEN_WIN_H

#include "Warden.h"

class WorldSession;
class Warden;

class WardenWin : public Warden
{
    public:
        WardenWin(WorldSession* pClient);
        ~WardenWin();

        void Packet03();
        void Packet05(bool reInitialize = false);
        void HandlePacket04(ByteBuffer &buff);
        
        void Packet02();
        void Packet02_1();
        void SpecialRequestData();

        std::string Penalty(WardenCheck* rd, std::string realData = "", std::string packetData = "");
        
        void HandlePacket02(ByteBuffer &buff);
        void HandlePacket02_1(ByteBuffer &buff);
        void HandlePacket02_2(ByteBuffer &buff);
        void SpecialHandleData(ByteBuffer &buff);

        void BuildCheckRequest(ByteBuffer &buff, std::vector<uint16> &_checksTodo, uint8 checkCount);
        void TestInit();

        void ClearEndSceneOffsets();

    private:
        uint32 _serverTicks;
        std::vector<uint16> _memChecksTodo;
        std::vector<uint16> _mpqChecksTodo;
        std::vector<uint16> _pageChecksATodo;
        std::vector<uint16> _pageChecksBTodo;
        std::vector<uint16> _luaStrChecksTodo;
        std::vector<uint16> _driverChecksTodo;
        std::vector<uint16> _moduleChecksTodo;
        std::vector<uint16> _procChecksTodo;
        std::list<uint16> _currentChecks;

        uint32 currentModulePtr;
        uint32 prevModulePtr;

        uint32 pDevice;
        uint32 pEnd;
        uint32 pScene;
        uint32 pEndScene;
};

#endif