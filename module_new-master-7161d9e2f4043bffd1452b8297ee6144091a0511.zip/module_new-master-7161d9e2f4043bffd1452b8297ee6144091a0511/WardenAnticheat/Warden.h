/*
* Copyright (C) 2010-2014 Anathema Engine project <http://valkyrie-wow.com/> 
* Copyright (C) C(ontinued)-MaNGOS <http://cmangos.net/>
*/

#ifndef __WARDEN_H
#define __WARDEN_H

#include "Anticheat.h"
#include "Policies/Singleton.h"
#include "WardenKeyGeneration.h"
#include "Auth/AuthCrypt.h"
#include "Common.h"
#include "ByteBuffer.h"
#include "WorldSession.h"
#include "Auth/BigNumber.h"
#include "Auth/SARC4.h"
#include "WardenMgr.h"

enum TrackCreatureMask
{
    TRACK_BEASTS     = 0x01,
    TRACK_DRAGONS    = 0x02,
    TRACK_DEMONS     = 0x04,
    TRACK_ELEMENTALS = 0x08,
    TRACK_GIANTS     = 0x10,
    TRACK_UNDEAD     = 0x20,
    TRACK_HUMANS     = 0x40,
    TRACK_ALL        = 0xFF
};

enum TrackResourceMask
{
    TRACK_HERBS     = 0x02,
    TRACK_MINERALS  = 0x04,
    TRACK_TREASURES = 0x10
};

#if defined(__GNUC__)
#pragma pack(1)
#else
#pragma pack(push,1)
#endif

struct WardenModuleUse
{
    uint8 Command;
    uint8 ModuleId[16];
    uint8 ModuleKey[16];
    uint32 Size;
};

struct WardenModuleCache
{
    uint8 Command;
    uint16 DataSize;
    uint8 Data[500];
};

struct WardenHashRequest
{
    uint8 Command;
    uint8 Seed[16];
};

#if defined(__GNUC__)
#pragma pack()
#else
#pragma pack(pop)
#endif

class WorldSession;

class Warden : public WardenInterface
{
    friend class WardenWin;
    friend class WardenMac;

    public:
        Warden();
        virtual ~Warden();

        void HandleWardenDataOpcode(WorldPacket & recvData);

        void RequestModule();
        void SendModuleToClient();
        void Update();
        void ChangeModule(uint32 id);

        void Init(BigNumber *K);
        virtual void Packet03() {}
        virtual void Packet05(bool reInitialize = false) {}
        virtual void HandlePacket04(ByteBuffer &buff) {}
        virtual void Packet02() {}
        virtual void Packet02_1() {}
        virtual void HandlePacket02(ByteBuffer &buff) {}
        virtual void HandlePacket02_1(ByteBuffer &buff) {}
        virtual void HandlePacket02_2(ByteBuffer &buff) {}
        virtual void TestInit() {}

        void EncryptData(uint8* buffer, uint32 length);
        void DecryptData(uint8* buffer, uint32 length);

        uint32 BuildChecksum(const uint8* data, uint32 dataLen);
        bool IsValidCheckSum(uint32 checksum, const uint8* data, const uint16 length);

        // sync
        void DropAckIndexes();
        void ResetLastPacketsCount();
        void ResetFailedPacketsCount();

        // WardenWin
        virtual void ClearEndSceneOffsets() {}

    private:
        WorldSession* _session;
        WardenModule* _currentModule;
        uint32 _clientBuild;
        bool _initialized;
        SARC4 _inputCrypto;
        SARC4 _outputCrypto;
        uint32 _initTimer;
        uint32 _checkTimer;
        uint32 _checkTimer2;
        uint32 _moduleChangeTimer;
        uint32 _lastTimestamp;

        // test IMPORTANT system of sync
        uint32 m_synIndex;
        uint32 m_ackIndex;
        uint32 m_reqAckIndex;

        uint8 m_sendLastPacketCount;
        uint8 m_sendLastPacketCount2;

        uint8 m_failedSyncPacketCount;
};

#endif