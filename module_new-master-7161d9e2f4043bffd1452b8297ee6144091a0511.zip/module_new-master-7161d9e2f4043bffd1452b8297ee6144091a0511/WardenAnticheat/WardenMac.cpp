/*
* Copyright (C) 2010-2014 Anathema Engine project <http://valkyrie-wow.com/> 
* Copyright (C) C(ontinued)-MaNGOS <http://cmangos.net/>
*/

#include <zlib/zlib.h>
#include "WardenKeyGeneration.h"
#include "Common.h"
#include "Player.h"
#include "WorldPacket.h"
#include "WorldSession.h"
#include "World.h"
#include "Log.h"
#include "SpellAuras.h"
#include "Opcodes.h"
#include "ByteBuffer.h"
#include <openssl/md5.h>
#include <openssl/sha.h>
#include "Database/DatabaseEnv.h"
#include "Policies/SingletonImp.h"
#include "Auth/BigNumber.h"
#include "Auth/HMACSHA1.h"
#include "WardenMac.h"
#include "WardenMgr.h"
#include "Util.h"

#include "MoveSpline.h"

WardenMac::WardenMac(WorldSession* pClient) : Warden()
{
    _session = pClient;
    _currentModule = _wardenMgr->GetModuleByName("");
    _clientBuild = _session->GetGameBuild();
}

WardenMac::~WardenMac() {}