/*
 * Copyright (C) 2010-2013 Anathema Engine project <http://valkyrie-wow.com/>
 * Copyright (C) 2005-2009 MaNGOS <http://getmangos.com/>
 */

#include "Common.h"
#include "WorldPacket.h"
#include "WorldSession.h"
#include "World.h"
#include "Log.h"
#include "Database/DatabaseEnv.h"
#include "Policies/SingletonImp.h"
#include <openssl/md5.h>
#include "Auth/BigNumber.h"
#include "WardenMgr.h"
#include "Warden.h"
#include "Util.h"
#include <sys/types.h>

#ifndef _WIN32
#include <dirent.h>
#include <errno.h>
#endif

WardenMgr::WardenMgr()
{
    checkStore.clear();
    checkResultStore.clear();
    moduleStore.clear();
}

WardenMgr::~WardenMgr()
{
    for (CheckContainer::const_iterator itr = checkStore.begin(); itr != checkStore.end(); ++itr)
    {
        std::vector<WardenCheck*> checkGroup = itr->second;
        for (std::vector<WardenCheck*>::const_iterator itr2 = checkGroup.begin(); itr2 != checkGroup.end(); ++itr2)
            delete (*itr2);
    }

    for (CheckResultContainer::const_iterator itr = checkResultStore.begin(); itr != checkResultStore.end(); ++itr)
    {
        std::vector<WardenCheckResult*> checkResultGroup = itr->second;
        for (std::vector<WardenCheckResult*>::const_iterator itr2 = checkResultGroup.begin(); itr2 != checkResultGroup.end(); ++itr2)
            delete (*itr2);
    }

    for (ModuleContainer::const_iterator itr = moduleStore.begin(); itr != moduleStore.end(); ++itr)
    {
        WardenModule* mod = itr->second;
        delete [] mod->CompressedData;
        delete mod;
    }

    checkStore.clear();
    checkResultStore.clear();
    moduleStore.clear();
}

void WardenMgr::LoadWardenChecks()
{
    QueryResult *result = WorldDatabase.Query("SELECT MAX(id) FROM warden_checks");

    if (!result)
    {
        sLog.outString(">> Loaded 0 warden checks. DB table `warden_checks` is empty!");
        sLog.outString();
        return;
    }

    checkStore.clear();
    checkResultStore.clear();

    result = WorldDatabase.Query("SELECT id, build, checkId, type, str, str1, data, address, length, result, action, banTime FROM warden_checks ORDER BY id ASC");

    uint32 count = 0;
    do
    {
        Field* fields = result->Fetch();

        uint16 build            = fields[1].GetUInt16();
        uint16 checkId          = fields[2].GetUInt8();
        uint8 checkType         = fields[3].GetUInt8();
        std::string str         = fields[4].GetCppString();
        std::string str1        = fields[5].GetCppString();
        std::string data        = fields[6].GetCppString();
        uint32 address          = fields[7].GetUInt32();
        uint32 length           = fields[8].GetUInt32();
        std::string checkResult = fields[9].GetCppString();
        uint8 action            = fields[10].GetUInt8();
        uint32 banTime          = fields[11].GetUInt32();

        WardenCheck* wardenCheck = new WardenCheck();

        wardenCheck->checkId = checkId;
        wardenCheck->type = checkType;
        wardenCheck->action = action;
        wardenCheck->banTime = banTime;

        if (checkType == PAGE_CHECK_A || checkType == PAGE_CHECK_B || checkType == DRIVER_CHECK || checkType == MODULE_CHECK || checkType == PROC_CHECK)
        {
            wardenCheck->data.SetHexStr(data.c_str());
            int len = data.size() / 2;

            if (wardenCheck->data.GetNumBytes() < len)
            {
                uint8 temp[24];
                memset(temp, 0, len);
                auto wData = wardenCheck->data.AsByteArray();
                memcpy(temp, wData.data(), wData.size());
                wardenCheck->data.SetBinary((uint8*)temp, len);
            }
        }

        if (checkType == MEM_CHECK || checkType == PAGE_CHECK_A || checkType == PAGE_CHECK_B || checkType == PROC_CHECK || checkType == INTERNAL_CHECK)
        {
            wardenCheck->address = address;
            wardenCheck->length = length;
        }

        if (checkType == MEM_CHECK || checkType == MPQ_CHECK || checkType == LUA_STR_CHECK || checkType == DRIVER_CHECK || checkType == PROC_CHECK)
            wardenCheck->str = str;

        if (checkType == PROC_CHECK)
            wardenCheck->str1 = str1;

        if (checkType != INTERNAL_CHECK)
        {
            switch (checkType)
            {
            case MEM_CHECK: MemChecksPool[build].push_back(checkId); break;
            case MPQ_CHECK: MPQChecksPool[build].push_back(checkId); break;
            case PAGE_CHECK_A: PageChecksAPool[build].push_back(checkId); break;
            case PAGE_CHECK_B: PageChecksBPool[build].push_back(checkId); break;
            case LUA_STR_CHECK: LuaStrChecksPool[build].push_back(checkId); break;
            case MODULE_CHECK: ModuleChecksPool[build].push_back(checkId); break;
            case DRIVER_CHECK: DriverChecksPool[build].push_back(checkId); break;
            case PROC_CHECK: ProcChecksPool[build].push_back(checkId); break;
            }
        }

        checkStore[build].push_back(wardenCheck);

        if (checkType == MPQ_CHECK || checkType == MEM_CHECK || checkType == PAGE_CHECK_A || checkType == PAGE_CHECK_B
            || checkType == DRIVER_CHECK || checkType == MODULE_CHECK || checkType == PROC_CHECK || checkType == INTERNAL_CHECK)
        {
            WardenCheckResult *wr = new WardenCheckResult();
            wr->checkId = checkId;
            wr->result = checkResult;

            checkResultStore[build].push_back(wr);
        }

        ++count;
    }
    while (result->NextRow());

    sLog.outString(">> Loaded %u warden checks.", count);
    sLog.outString();
}

void WardenMgr::LoadWardenModules()
{
    moduleStore.clear();

#ifndef _WIN32

    DIR *dirp;
    struct dirent *dp;
    dirp = opendir("./warden_modules/");

    if (!dirp)
        return;

    uint32 count = 1;

    while (dirp)
    {
        errno = 0;
        if ((dp = readdir(dirp)) != NULL)
        {
            int l = strlen(dp->d_name);
            if (l < 36)
                continue;
            if (!memcmp(&dp->d_name[l - 4], ".bin", 4))
            {
                LoadModule(dp->d_name, count);
                ++count;
            }
        }
        else
        {
            if (errno != 0)
            {
                closedir(dirp);
                return;
            }

            break;
        }
    }

    if (dirp)
        closedir(dirp);

#else
    uint32 count = 1;

    WIN32_FIND_DATA fil;
    HANDLE hFil = FindFirstFile("./warden_modules/*.bin", &fil);

    if (hFil == INVALID_HANDLE_VALUE)
        return;
    do
    {
        LoadModule(fil.cFileName, count);
        ++count;
    } 
    while (FindNextFile(hFil, &fil));

    FindClose(hFil);

#endif
    sLog.outString(">> Loaded %u warden modules.", moduleStore.size());
    sLog.outString();
}

void WardenMgr::LoadModule(const char * fileName, uint32 index)
{
    char fn_module[256];
    snprintf(fn_module, 256, "./warden_modules/%s", fileName);

    WardenModule *mod = new WardenModule;

    FILE * f_mod = fopen(fn_module, "rb");
    if (f_mod == 0)
        return;

    // read module
    fseek(f_mod, 0, SEEK_END);
    uint32 len = ftell(f_mod);
    fseek(f_mod, 0, SEEK_SET);
    // data assign
    mod->CompressedSize = len;
    mod->CompressedData = new uint8[len];
    fread(mod->CompressedData, len, 1, f_mod);

    // md5 hash
    MD5_CTX ctx;
    MD5_Init(&ctx);
    MD5_Update(&ctx, mod->CompressedData, len);
    MD5_Final((uint8*)&mod->ID, &ctx);

    fclose(f_mod);

    std::string fn(fileName);
    std::string fn_t = fn.substr(0, fn.length() - 4);
    std::string path = "./warden_modules/";
    path += fn_t;
    path += ".key";

    FILE * f_key = fopen(path.c_str(), "rb");
    if (f_key == 0)
        return;

    // read key and other data
    fread(mod->Key, 16, 1, f_key);
    fread(mod->Seed, 16, 1, f_key);
    fread(mod->ServerKeySeed, 16, 1, f_key);
    fread(mod->ClientKeySeed, 16, 1, f_key);
    fread(mod->ClientKeySeedHash, 20, 1, f_key);
    fread(mod->CheckTypes, 9, 1, f_key);

    fclose(f_key);

    moduleStore[index] = mod;
}

WardenModule* WardenMgr::GetModuleByName(std::string name)
{
    for (ModuleContainer::const_iterator itr = moduleStore.begin(); itr != moduleStore.end(); ++itr)
    {
        WardenModule* mod = itr->second;

        if (!mod)
            continue;

        std::string m_name = ConvertByteArrayToString(mod->ID, 16);

        if (m_name == name)
            return itr->second;
    }

    return NULL;
}

WardenModule* WardenMgr::GetModuleByID(uint32 ID)
{
    ModuleContainer::const_iterator itr = moduleStore.find(ID);
    if (itr != moduleStore.end())
        return itr->second;

    return NULL;
}

WardenCheck* WardenMgr::GetCheckDataById(uint16 checkId, uint16 build)
{
    CheckContainer::const_iterator itr = checkStore.find(build);
    if (itr != checkStore.end())
    {
        std::vector<WardenCheck*> checkGroup = itr->second;
        for (std::vector<WardenCheck*>::const_iterator itr2 = checkGroup.begin(); itr2 != checkGroup.end(); ++itr2)
        {
            if ((*itr2) && (*itr2)->checkId == checkId)
                return (*itr2);
        }
    }

    return NULL;
}

std::vector<uint16> WardenMgr::GetChecksIdByType(uint16 type, uint16 build)
{
    std::vector<uint16> checks;

    CheckContainer::const_iterator itr = checkStore.find(build);
    if (itr != checkStore.end())
    {
        std::vector<WardenCheck*> checkGroup = itr->second;
        for (std::vector<WardenCheck*>::const_iterator itr2 = checkGroup.begin(); itr2 != checkGroup.end(); ++itr2)
        {
            if ((*itr2) && (*itr2)->type == type)
                checks.push_back((*itr2)->checkId);
        }
    }

    return checks;
}

std::vector<uint16> WardenMgr::GetChecksIdByType(std::vector<uint16>& currentChecks, uint16 type, uint16 build)
{
    std::vector<uint16> checks;

    for (std::vector<uint16>::const_iterator itr = currentChecks.begin(); itr != currentChecks.end(); ++itr)
    {
        WardenCheck* wd = GetCheckDataById((*itr), build);

        if (!wd)
            continue;

        if (wd->type == type)
            checks.push_back(wd->checkId);
    }

    return checks;
}

WardenCheckResult* WardenMgr::GetCheckResultById(uint16 checkId, uint16 build)
{
    CheckResultContainer::const_iterator itr = checkResultStore.find(build);
    if (itr != checkResultStore.end())
    {
        std::vector<WardenCheckResult*> checkResultGroup = itr->second;
        for (std::vector<WardenCheckResult*>::const_iterator itr2 = checkResultGroup.begin(); itr2 != checkResultGroup.end(); ++itr2)
        {
            if ((*itr2) && (*itr2)->checkId == checkId)
                return (*itr2);
        }
    }

    return NULL;
}

/*template <typename I>
I WardenMgr::GetRandomCheckFromList(I begin, I end)
{
    const unsigned long n = std::distance(begin, end);
    const unsigned long divisor = (RAND_MAX + 1) / n;

    unsigned long k;
    do { k = std::rand() / divisor; } while (k >= n);

    std::advance(begin, k);
    return begin;
}*/

std::vector<uint16>::iterator WardenMgr::GetRandomCheckFromList(std::vector<uint16>::iterator begin, std::vector<uint16>::iterator end)
{
    const unsigned long n = std::distance(begin, end);
    const unsigned long divisor = (RAND_MAX + 1) / n;

    unsigned long k;
    do { k = std::rand() / divisor; } while (k >= n);

    std::advance(begin, k);
    return begin;
}

std::vector<uint8> WardenMgr::GetChecksCount()
{
    std::vector<uint8> checksCount;
    uint8 packetSequence = urand(0, 3);

    switch (packetSequence)
    {
        case 0:
            checksCount = { 10, 2, 1, 0, 1, 0, 2, 0 };
            break;
        case 1:
            checksCount = { 4, 3, 3, 2, 0, 2, 0, 1 };
            break;
        case 2:
            checksCount = { 2, 1, 1, 5, 1, 0, 1, 0 };
            break;
        case 3:
            checksCount = { 5, 2, 2, 2, 0, 1, 0, 0 };
            break;
    }

    return checksCount;
}

std::string WardenMgr::ConvertByteArrayToString(const uint8 * packet_data, uint16 length)
{
    std::ostringstream ss;

    // convert packet data to string
    for (uint32 i = 0; i < length; i++)
    {
        if (int(packet_data[i]) < 16)
            ss << std::uppercase << std::hex << "0" << int(packet_data[i]) << "";
        else
            ss << std::uppercase << std::hex << int(packet_data[i]) << "";
    }

    std::string data_str = ss.str();
    return data_str;
}
