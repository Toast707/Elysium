/*
 * Copyright (C) 2010-2013 Anathema Engine project <http://valkyrie-wow.com/>
 * Copyright (C) 2005-2009 MaNGOS <http://getmangos.com/>
 */

#include <zlib/zlib.h>
#include "WardenKeyGeneration.h"
#include "Common.h"
#include "Player.h"
#include "WorldPacket.h"
#include "WorldSession.h"
#include "World.h"
#include "Log.h"
#include "SpellAuras.h"
#include "Opcodes.h"
#include "ByteBuffer.h"
#include <openssl/md5.h>
#include <openssl/sha.h>
#include "Database/DatabaseEnv.h"
#include "Policies/SingletonImp.h"
#include "Auth/BigNumber.h"
#include "Auth/HMACSHA1.h"
#include "WardenWin.h"
#include "WardenMgr.h"
#include "Util.h"

#include "MoveSpline.h"

WardenWin::WardenWin(WorldSession* pClient) : Warden()
{
    _session = pClient;
    _currentModule = _wardenMgr->GetModuleByID(1);
    _clientBuild = pClient->GetGameBuild();

    ClearEndSceneOffsets();

    currentModulePtr = 0;
    prevModulePtr = 0;
}

WardenWin::~WardenWin()
{
}

void WardenWin::ClearEndSceneOffsets() {}

void WardenWin::Packet03()
{
    BigNumber n;
    switch(_clientBuild)
    {
        // 1.12.1
        case 5875:
        {
            n.SetHexStr("01000200A0772400F08724006084240030872400040000F03B30000001010010C0020001");
            break;
        }
        // 1.12.2
        case 6005:
        {
            n.SetHexStr("01000200A0772400F08724006084240030872400040000203C30000001010010C0020001");
            break;
        }
        // 1.12.3
        case 6141:
        {
            n.SetHexStr("01000200409B240090AB240000A82400D0AA2400040000C05F30000001010010C0020001");
            break;
        }
        default:
        {
            sLog.outWarden("SERVER WARDEN: Right client build are not detected! Account kicked! Maybe cheating!");
            _session->KickPlayer();
            return;
        }
    }

    sLog.outDebug("SERVER WARDEN: Initialize module...");

    // hex string -> byte[]
    ByteBuffer buff_b, buff_c;
    auto temp = n.AsByteArray(0, false);
    buff_c.append(temp);

    buff_b << uint8(0x03);
    buff_b << uint16(20);
    buff_b << uint32(BuildChecksum(buff_c.contents(), 20));
    buff_b.append(buff_c.contents(), 20);

    buff_b << uint8(0x03);
    buff_b << uint16(8);
    buff_b << uint32(BuildChecksum(buff_c.contents() + 20, 8));
    buff_b.append(buff_c.contents() + 20, 8);

    buff_b << uint8(0x03);
    buff_b << uint16(8);
    buff_b << uint32(BuildChecksum(buff_c.contents() + 28, 8));
    buff_b.append(buff_c.contents() + 28, 8);

    // Encrypt with warden RC4 key.
    EncryptData(const_cast<uint8*>(buff_b.contents()), buff_b.size());

    WorldPacket pkt(SMSG_WARDEN_DATA, buff_b.size());
    pkt.append(buff_b);
    _session->SendPacket(&pkt);
}

void WardenWin::TestInit()
{
    /*BigNumber n;
    n.SetHexStr("01000200A0772400F08724006084240030872400040000409D41000101010010C0020001");

    //sLog.outDebug("SERVER WARDEN: Initialize module
    //uint32 callFunc = s_currentModule + 0x5CBC;
    uint32 callFunc = 0x5ABE10;
    callFunc = callFunc - 0x400000;
    uint8 result[8];
    
    result[0] = 0x01;
    result[1] = 0x01;
    result[2] = 0x00;
    result[3] = (callFunc & 0x000000ff);
    result[4] = (callFunc & 0x0000ff00) >> 8;
    result[5] = (callFunc & 0x00ff0000) >> 16;
    result[6] = (callFunc & 0xff000000) >> 24;
    result[7] = 0x01;

    // hex string -> byte[]
    ByteBuffer buff_b, buff_c;
    uint8* temp = n.AsByteArray(0, false);
    buff_c.append(temp, 36);

    buff_b << uint8(0x03);
    buff_b << uint16(20);
    buff_b << uint32(BuildChecksum(buff_c.contents(), 20));
    buff_b.append(buff_c.contents(), 20);

    buff_b << uint8(0x03);
    buff_b << uint16(8);
    buff_b << uint32(BuildChecksum(buff_c.contents() + 20, 8));
    buff_b.append(buff_c.contents() + 20, 8);

    buff_b << uint8(0x03);
    buff_b << uint16(8);
    buff_b << uint32(BuildChecksum(result, 8));
    buff_b.append(result, 8);

    // Encrypt with warden RC4 key.
    EncryptData(const_cast<uint8*>(buff_b.contents()), buff_b.size());

    WorldPacket pkt(SMSG_WARDEN_DATA, buff_b.size());
    pkt.append(buff_b);
    _session->SendPacket(&pkt);*/
}

void WardenWin::Packet05(bool reInitialize)
{
    sLog.outDebug("SERVER WARDEN: Initial Warden Request Hash...");

    if (reInitialize)
        sLog.outWarden("CLIENT WARDEN: Player %s (account: %u) re-initialize module", _session->GetPlayerName(), _session->GetAccountId());

    // Create packet structure
    WardenHashRequest Request;
    Request.Command = 0x05;
    memcpy(Request.Seed, _currentModule->Seed, 16);

    // Encrypt with warden RC4 key.
    EncryptData((uint8*)&Request, sizeof(WardenHashRequest));

    WorldPacket pkt(SMSG_WARDEN_DATA, sizeof(WardenHashRequest));
    pkt.append((uint8*)&Request, sizeof(WardenHashRequest));
    _session->SendPacket(&pkt);
}

void WardenWin::HandlePacket04(ByteBuffer &buff)
{
    buff.rpos(buff.wpos());

    // Verify key
    if (memcmp(buff.contents() + 1, _currentModule->ClientKeySeedHash, 20) != 0)
    {
        sLog.outWarden("SERVER WARDEN: Hash check failed! Account %u kicked! Maybe cheating!", _session->GetAccountId());
        _session->KickPlayer();
    }

    // Change keys here
    _inputCrypto.Init(_currentModule->ClientKeySeed);
    _outputCrypto.Init(_currentModule->ServerKeySeed);

    sLog.outDebug("SERVER WARDEN: Keys are successfully changed!");

	_initialized = true;
}

void WardenWin::BuildCheckRequest(ByteBuffer &buff, std::vector<uint16> &_checksTodo, uint8 checkCount)
{
    for (uint8 i = 0; i < checkCount; ++i)
    {
        if (_checksTodo.empty())
            break;

        std::vector<uint16>::iterator itr = _wardenMgr->GetRandomCheckFromList(_checksTodo.begin(), _checksTodo.end());
        uint16 id = (*itr);
        _checksTodo.erase(itr);

        // Add the id to the list sent in this cycle
        _currentChecks.push_back(id);

        WardenCheck* wd = _wardenMgr->GetCheckDataById(id, _clientBuild);

        if (wd->type == MPQ_CHECK || wd->type == LUA_STR_CHECK || wd->type == DRIVER_CHECK)
        {
            buff << uint8(wd->str.size());
            buff.append(wd->str.c_str(), wd->str.size());
        }
        else if (wd->type == PROC_CHECK)
        {
            buff << uint8(wd->str.size());
            buff.append(wd->str.c_str(), wd->str.size());
            buff << uint8(wd->str1.size());
            buff.append(wd->str1.c_str(), wd->str1.size());
        }
    }
}

void WardenWin::Packet02()
{
    sLog.outDebug("SERVER WARDEN: Cheat base checks was STARTED!");

    if (_currentModule->ClientKeySeed[0] != 0x7F)
    {
        SpecialRequestData();
        return;
    }

    // If all checks were done, fill the todo list again
    // TODO: rewrite it!
    if (_memChecksTodo.empty())
        _memChecksTodo.assign(_wardenMgr->MemChecksPool[_clientBuild].begin(), _wardenMgr->MemChecksPool[_clientBuild].end());
    if (_mpqChecksTodo.empty())
        _mpqChecksTodo.assign(_wardenMgr->MPQChecksPool[_clientBuild].begin(), _wardenMgr->MPQChecksPool[_clientBuild].end());
    if (_pageChecksATodo.empty())
        _pageChecksATodo.assign(_wardenMgr->PageChecksAPool[_clientBuild].begin(), _wardenMgr->PageChecksAPool[_clientBuild].end());
    if (_pageChecksBTodo.empty())
        _pageChecksBTodo.assign(_wardenMgr->PageChecksBPool[_clientBuild].begin(), _wardenMgr->PageChecksBPool[_clientBuild].end());
    if (_luaStrChecksTodo.empty())
        _luaStrChecksTodo.assign(_wardenMgr->LuaStrChecksPool[_clientBuild].begin(), _wardenMgr->LuaStrChecksPool[_clientBuild].end());
    if (_driverChecksTodo.empty())
        _driverChecksTodo.assign(_wardenMgr->DriverChecksPool[_clientBuild].begin(), _wardenMgr->DriverChecksPool[_clientBuild].end());
    if (_moduleChecksTodo.empty())
        _moduleChecksTodo.assign(_wardenMgr->ModuleChecksPool[_clientBuild].begin(), _wardenMgr->ModuleChecksPool[_clientBuild].end());
    if (_procChecksTodo.empty())
        _procChecksTodo.assign(_wardenMgr->ProcChecksPool[_clientBuild].begin(), _wardenMgr->ProcChecksPool[_clientBuild].end());

    _serverTicks = WorldTimer::getMSTime();
    _currentChecks.clear();

    ByteBuffer buff;
    buff << uint8(0x02);

    ACE_READ_GUARD(ACE_RW_Mutex, g, _wardenMgr->_checkStoreLock);

    // Get numbers of check types
    std::vector<uint8> checksCount = _wardenMgr->GetChecksCount();

    // Build check request
    for (uint8 i = MEM_CHECK; i < MAX_CHECK_TYPE; ++i)
    {
        if (!_currentModule->CheckTypes[i])
            continue;

        switch (i)
        {
        case MEM_CHECK: BuildCheckRequest(buff, _memChecksTodo, checksCount[i - 1]); break;
        case PAGE_CHECK_A: BuildCheckRequest(buff, _pageChecksATodo, checksCount[i - 1]); break;
        case PAGE_CHECK_B: BuildCheckRequest(buff, _pageChecksBTodo, checksCount[i - 1]); break;
        case MPQ_CHECK: BuildCheckRequest(buff, _mpqChecksTodo, checksCount[i - 1]); break;
        case DRIVER_CHECK: BuildCheckRequest(buff, _driverChecksTodo, checksCount[i - 1]); break;
        case MODULE_CHECK: BuildCheckRequest(buff, _moduleChecksTodo, checksCount[i - 1]); break;
        case LUA_STR_CHECK: BuildCheckRequest(buff, _luaStrChecksTodo, checksCount[i - 1]); break;
        case PROC_CHECK: BuildCheckRequest(buff, _procChecksTodo, checksCount[i - 1]); break;
        }
    }

    uint8 xorByte = _currentModule->ClientKeySeed[0];

    // Add TIMING_CHECK
    buff << uint8(0x00);
    buff << uint8(_currentModule->CheckTypes[TIMING_CHECK] ^ xorByte);

    uint8 index = 1;

    // header
    WardenCheck* wd = _wardenMgr->GetCheckDataById(1, _clientBuild);

    buff << uint8(_currentModule->CheckTypes[MEM_CHECK] ^ xorByte);
    buff << uint8(0x00);
    buff << uint32(wd->address);
    buff << uint8(wd->length);

    // test native calls of module function - DISABLED IT
    /*if (s_currentModule == 0x00 && s_currentModulePtr == 0x00)
    {
        buff << uint8(MEM_CHECK ^ xorByte);
        buff << uint8(0x00);
        buff << uint32(0x00CE8978);
        buff << uint8(4);
    }
    else if (s_currentModule == 0x00)
    {
        buff << uint8(MEM_CHECK ^ xorByte);
        buff << uint8(0x00);
        buff << uint32(s_currentModulePtr);
        buff << uint8(4);
    }*/

    for (std::list<uint16>::iterator itr = _currentChecks.begin(); itr != _currentChecks.end(); ++itr)
    {
        wd = _wardenMgr->GetCheckDataById(*itr, _clientBuild);

        switch (wd->type)
        {
            case MEM_CHECK:
            {
                buff << uint8(_currentModule->CheckTypes[MEM_CHECK] ^ xorByte);
                buff << uint8(0x00);
                buff << uint32(wd->address);
                buff << uint8(wd->length);
                break;
            }
            case PAGE_CHECK_A:
            case PAGE_CHECK_B:
            {
                buff << uint8(_currentModule->CheckTypes[wd->type] ^ xorByte);
                auto data = wd->data.AsByteArray(0, false);
                buff.append(data);
                buff << uint32(wd->address);
                buff << uint8(wd->length);
                break;
            }
            case MPQ_CHECK:
            case LUA_STR_CHECK:
            {
                buff << uint8(_currentModule->CheckTypes[wd->type] ^ xorByte);
                buff << uint8(index++);
                break;
            }
            case DRIVER_CHECK:
            {
                buff << uint8(_currentModule->CheckTypes[DRIVER_CHECK] ^ xorByte);
                auto data = wd->data.AsByteArray(0, false);
                buff.append(data);
                buff << uint8(index++);
                break;
            }
            case MODULE_CHECK:
            {
                buff << uint8(_currentModule->CheckTypes[MODULE_CHECK] ^ xorByte);
                uint32 seed = static_cast<uint32>(rand32());
                buff << uint32(seed);
                HMACSHA1 hmac(4, (uint8*)&seed);
                hmac.UpdateData(wd->str);
                hmac.Finalize();
                buff.append(hmac.GetDigest(), hmac.GetLength());
                break;
            }
            case PROC_CHECK:
            {
                buff << uint8(_currentModule->CheckTypes[PROC_CHECK] ^ xorByte);
                auto data = wd->data.AsByteArray(0, false);
                buff.append(data);
                buff << uint8(index++);
                buff << uint8(index++);
                buff << uint32(wd->address);
                buff << uint8(wd->length);
                break;
            }
            default:
                break;                                      // Should never happen
        }
    }

    buff << uint8(xorByte);

    // Encrypt with warden RC4 key
    EncryptData(const_cast<uint8*>(buff.contents()), buff.size());

    WorldPacket pkt(SMSG_WARDEN_DATA, buff.size());
    pkt.append(buff);
    _session->SendPacket(&pkt);

    ++m_sendLastPacketCount;

    if (m_sendLastPacketCount > 4)
    {
        sLog.outWarden("Player %s (account: %u) (latency: %u, IP: %s) exceeded Warden module response delay (static packets) - disconnecting client",
            _session->GetPlayerName(), _session->GetAccountId(), _session->GetLatency(), _session->GetRemoteAddress().c_str());
        _session->KickPlayer();
        return;
    }

    ++m_synIndex;
    m_reqAckIndex = m_synIndex;
    //sLog.outWarden("server packet number - %u, required client packet number - %u", m_PacketNumber_S, m_reqClientPacketNumber);

    std::stringstream stream;
    stream << "WARDEN: Sent check id's: ";
    for (std::list<uint16>::iterator itr = _currentChecks.begin(); itr != _currentChecks.end(); ++itr)
        stream << *itr << " ";

    sLog.outWarden("%s", stream.str().c_str());
}

void WardenWin::Packet02_1()
{
    if (_currentModule->ClientKeySeed[0] != 0x7F)
        return;

    ByteBuffer buff;
    buff << uint8(0x02);

    uint8 xorByte = _currentModule->ClientKeySeed[0];

    buff << uint8(0x00);
    buff << uint8(_currentModule->CheckTypes[TIMING_CHECK] ^ xorByte);                  // check TIMING_CHECK

    // header
    WardenCheck* wd = _wardenMgr->GetCheckDataById(2, _clientBuild);

    buff << uint8(_currentModule->CheckTypes[MEM_CHECK] ^ xorByte);
    buff << uint8(0x00);
    buff << uint32(wd->address);
    buff << uint8(wd->length);

    // construct dynamic part of packet
    buff << uint8(_currentModule->CheckTypes[MEM_CHECK] ^ xorByte);
    buff << uint8(0x00);

    bool dataCreate = false;

    // first packet in chain
    if (!pDevice && !pEnd && !pScene && !pEndScene)
    {
        wd = _wardenMgr->GetCheckDataById(106, _clientBuild);// data from wow.exe
        buff << uint32(wd->address);
        buff << uint8(wd->length);
        dataCreate = true;
    }
    // second packet in chain
    else if (pDevice && !pEnd && !pScene && !pEndScene)
    {
        wd = _wardenMgr->GetCheckDataById(107, _clientBuild);//0x38A8
        pDevice += wd->address;
        buff << uint32(pDevice);
        buff << uint8(wd->length);
        dataCreate = true;
    }
    // third packet in chain
    else if (pDevice && pEnd && !pScene && !pEndScene)
    {
        buff << uint32(pEnd);
        buff << uint8(wd->length);
        dataCreate = true;
    }
    // fourth packet in chain
    else if (pDevice && pEnd && pScene && !pEndScene)
    {
        wd = _wardenMgr->GetCheckDataById(108, _clientBuild);//A8
        pScene += wd->address;
        buff << uint32(pScene);
        buff << uint8(wd->length);
        dataCreate = true;
    }
    else if (pDevice && pEnd && pScene && pEndScene)
    {
        buff << uint32(pEndScene);
        buff << uint8(0x05);
        dataCreate = true;
    }

    if (dataCreate)
    {
        buff << uint8(xorByte);

        // Encrypt with warden RC4 key.
        EncryptData(const_cast<uint8*>(buff.contents()), buff.size());

        WorldPacket pkt(SMSG_WARDEN_DATA, buff.size());
        pkt.append(buff);
        _session->SendPacket(&pkt);

        // inc packet count
        ++m_sendLastPacketCount2;

        if (m_sendLastPacketCount2 > 20)
        {
            sLog.outWarden("Player %s (account: %u) (latency: %u, IP: %s) exceeded Warden module response delay (dynamic packets) - disconnecting client",
                _session->GetPlayerName(), _session->GetAccountId(), _session->GetLatency(), _session->GetRemoteAddress().c_str());
            _session->KickPlayer();
            return;
        }

        //sLog.outWarden("server packet number 2 - %u, required client packet number 2 - %u", m_PacketNumber2_S, m_reqClientPacketNumber2);
    }
}

void WardenWin::SpecialRequestData()
{
    sLog.outWarden("SERVER WARDEN: Special Request for Gasai Bot");
    _serverTicks = WorldTimer::getMSTime();
    _currentChecks.clear();

    _currentChecks.push_back(91);

    ByteBuffer buff;
    buff << uint8(0x02);

    uint8 xorByte = _currentModule->ClientKeySeed[0];

    // Add TIMING_CHECK
    buff << uint8(0x00);
    buff << uint8(_currentModule->CheckTypes[TIMING_CHECK] ^ xorByte);

    uint8 index = 1;

    // header
    WardenCheck* wd = _wardenMgr->GetCheckDataById(1, _clientBuild);

    buff << uint8(_currentModule->CheckTypes[MEM_CHECK] ^ xorByte);
    buff << uint8(0x00);
    buff << uint32(wd->address);
    buff << uint8(wd->length);

    for (std::list<uint16>::iterator itr = _currentChecks.begin(); itr != _currentChecks.end(); ++itr)
    {
        wd = _wardenMgr->GetCheckDataById(*itr, _clientBuild);

        switch (wd->type)
        {
            case PAGE_CHECK_A:
            case PAGE_CHECK_B:
            {
                buff << uint8(_currentModule->CheckTypes[wd->type] ^ xorByte);
                auto data = wd->data.AsByteArray(0, false);
                buff.append(data);
                buff << uint32(wd->address);
                buff << uint8(wd->length);
                break;
            }
            default: 
                break;
        }
    }

    buff << uint8(xorByte);
    //buff.hexlike();

    // Encrypt with warden RC4 key
    EncryptData(const_cast<uint8*>(buff.contents()), buff.size());

    WorldPacket pkt(SMSG_WARDEN_DATA, buff.size());
    pkt.append(buff);
    _session->SendPacket(&pkt);
}

std::string WardenWin::Penalty(WardenCheck* rd, std::string realData, std::string packetData)
{
    uint8 action = rd->action;
    rd->reason = "Unknown check";

    // ----> to Warden.log
    sLog.outWarden("Penalty: %s (accountID - %u, accountName - %s, playerName - %s, clientBuild - %u, checkId - %u, action - %u, realData - %s, failedData - %s)", 
        rd->reason.c_str(), _session->GetAccountId(), _session->GetUsername().c_str(), _session->GetPlayerName(), _clientBuild, rd->checkId, rd->action, realData.c_str(), packetData.c_str());

    switch (action)
    {
        case 0: return "Log";
        case 1:
        {
            _session->KickPlayer();
            return "Kick";
        }
        case 2:
        {
            std::string accountName = _session->GetUsername();
            std::ostringstream banReason;
            banReason << "Cheat detected";
            //_session->UpdateBanAttempts(_session->GetAccountId());
            sWorld.BanAccount(BAN_ACCOUNT, accountName, 0, banReason.str(), "Warden AntiCheat");
            return "Ban";
        }
    }

    return "Undefined";
}

void WardenWin::HandlePacket02(ByteBuffer &buff)
{
    sLog.outDebug("CLIENT WARDEN: Raw Packet Data");

    uint16 length;
    uint32 checksum;
    buff >> length;
    buff >> checksum;

    if (!IsValidCheckSum(checksum, buff.contents() + buff.rpos(), length))
    {
        buff.rpos(buff.wpos());
        sLog.outWarden("CLIENT WARDEN : Packet checksum FAIL! Abort parsing! Account %u" , _session->GetAccountId());
        _session->KickPlayer();
        return;
    }

    //TIMING_CHECK
    uint8 timingRes;
    buff >> timingRes;

    if (!timingRes)
    {
        sLog.outWarden("WARDEN: timing check failed! Account %u", _session->GetAccountId());
        _session->KickPlayer();
        return;
    }

    uint32 newClientTicks;
    buff >> newClientTicks;

    uint32 ticksNow = WorldTimer::getMSTime();
    uint32 ourTicks = newClientTicks + (ticksNow - _serverTicks);

    // read header
    uint8 HeaderRes;
    buff >> HeaderRes;

    if (HeaderRes != 0)
    {
        buff.rpos(buff.wpos());
        sLog.outWarden("WARDEN: Player %s (account: %u) failed read Warden packet header. Player kicked", _session->GetPlayerName(), _session->GetAccountId());
        _session->KickPlayer();
        return;
    }

    uint8 sign[6];
    buff.read(sign, 6);
    std::string packetSign = _wardenMgr->ConvertByteArrayToString(sign, 6);

    WardenCheckResult* wr = _wardenMgr->GetCheckResultById(1, _clientBuild);
    std::string staticCheckSign = wr->result;

    // static checks: verify header not equal kick player
    if (!strcmp(packetSign.c_str(), staticCheckSign.c_str()))
    {
        HandlePacket02_1(buff);
        return;
    }

    wr = _wardenMgr->GetCheckResultById(2, _clientBuild);
    std::string dynamicCheckSign = wr->result;

    // dynamic checks: verify header not equal kick player
    if (!strcmp(packetSign.c_str(), dynamicCheckSign.c_str()))
    {
        HandlePacket02_2(buff);
        return;
    }

    buff.rpos(buff.wpos());
    sLog.outWarden("WARDEN: Player %s (account: %u) failed check Warden packet header. Player kicked",
        _session->GetPlayerName(), _session->GetAccountId());
    _session->KickPlayer();
}

void WardenWin::HandlePacket02_1(ByteBuffer &buff)
{
    if (_currentModule->ClientKeySeed[0] != 0x7F)
    {
        SpecialHandleData(buff);
        return;
    }

    //sLog.outWarden("client packet number - %u, required client packet number - %u", m_ackIndex, m_reqAckIndex);
    m_sendLastPacketCount = 0;
    ++m_ackIndex;

    if (m_ackIndex != m_reqAckIndex)
    {
        ++m_failedSyncPacketCount;

        // failed sync attempts larger than normal
        if (m_failedSyncPacketCount > 3)
        {
            sLog.outWarden("Player %s (account: %u) (latency: %u, IP: %s) too many failed sync attempts - disconnecting client",
                _session->GetPlayerName(), _session->GetAccountId(), _session->GetLatency(), _session->GetRemoteAddress().c_str());
            _session->KickPlayer();
            return;
        }

        DropAckIndexes();
        // reset packet and delay check timer
        buff.rpos(buff.wpos());
        _checkTimer += 10 * IN_MILLISECONDS;
        //sLog.outWarden("Player %s (account: %u) (latency: %u, IP: %s) failed sync static packets current: %u (req: %u)", _session->GetPlayerName(), _session->GetAccountId(), _session->GetLatency(), _session->GetRemoteAddress().c_str(), m_ackIndex, m_reqAckIndex);
        return;
    }

    WardenCheckResult *rs;
    WardenCheck *rd;
    uint8 type;

    ACE_READ_GUARD(ACE_RW_Mutex, g, _wardenMgr->_checkStoreLock);

    for (std::list<uint16>::iterator itr = _currentChecks.begin(); itr != _currentChecks.end(); ++itr)
    {
        rd = _wardenMgr->GetCheckDataById(*itr, _clientBuild);
        rs = _wardenMgr->GetCheckResultById(*itr, _clientBuild);

        type = rd->type;
        switch (type)
        {
            case MEM_CHECK:
            {
                uint8 memResult;
                buff >> memResult;

                if (memResult)
                {
                    sLog.outWarden("Function for MEM_CHECK hasn't been called, CheckId %u account Id %u", *itr, _session->GetAccountId());
                    buff.rpos(buff.wpos());
                    //sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd).c_str());
                    _session->KickPlayer();
                    return;
                }

                std::string packet_data = _wardenMgr->ConvertByteArrayToString(buff.contents() + buff.rpos(), rd->length);
                std::string result = rs->result;

                bool pen = false;

                // not equal result, soft compare
                if (strcmp(result.c_str(), packet_data.c_str()))
                    pen = true;

                if (pen)
                {
                    sLog.outWarden("RESULT MEM_CHECK fail CheckId %u account Id %u", *itr, _session->GetAccountId());
                    //buff.rpos(buff.wpos());
                    sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd, result, packet_data).c_str());
                    //return;
                }

                buff.rpos(buff.rpos() + rd->length);
                break;
            }
            case PAGE_CHECK_A:
            case PAGE_CHECK_B:
            case DRIVER_CHECK:
            case MODULE_CHECK:
            case PROC_CHECK:
            {
                std::string packet_data = _wardenMgr->ConvertByteArrayToString(buff.contents() + buff.rpos(), 1);
                std::string result = rs->result;
                if (strcmp(result.c_str(), packet_data.c_str()))
                {
                    if (type == PAGE_CHECK_A || type == PAGE_CHECK_B)
                        sLog.outWarden("RESULT PAGE_CHECK fail, CheckId %u, account Id %u", *itr, _session->GetAccountId());
                    if (type == MODULE_CHECK)
                        sLog.outWarden("RESULT MODULE_CHECK fail, CheckId %u, account Id %u", *itr, _session->GetAccountId());
                    if (type == DRIVER_CHECK)
                        sLog.outWarden("RESULT DRIVER_CHECK fail, CheckId %u, account Id %u", *itr, _session->GetAccountId());
                    if (type == PROC_CHECK)
                        sLog.outWarden("RESULT PROC_CHECK fail, CheckId %u, account Id %u", *itr, _session->GetAccountId());

                    //buff.rpos(buff.wpos());
                    sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd, result, packet_data).c_str());
                    //return;
                }

                buff.rpos(buff.rpos() + 1);
                break;
            }
            case MPQ_CHECK:
            {
                uint8 mpqResult;
                buff >> mpqResult;

                if (mpqResult)
                {
                    sLog.outWarden("Function for MPQ_CHECK hasn't been called, CheckId %u account Id %u", *itr, _session->GetAccountId());
                    buff.rpos(buff.wpos());
                    //sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd).c_str());
                    _session->KickPlayer();
                    return;
                }

                std::string packet_data = _wardenMgr->ConvertByteArrayToString(buff.contents() + buff.rpos(), 20);
                std::string result = rs->result;
                if (strcmp(rs->result.c_str(), packet_data.c_str()))
                {
                    sLog.outWarden("RESULT MPQ_CHECK fail, CheckId %u account Id %u", *itr, _session->GetAccountId());
                    //buff.rpos(buff.wpos());
                    sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd, result, packet_data).c_str());
                    //return;
                }

                buff.rpos(buff.rpos() + 20);                // 20 bytes SHA1
                break;
            }
            case LUA_STR_CHECK:
            {
                uint8 luaResult;
                buff >> luaResult;

                if (luaResult)
                {
                    sLog.outWarden("Function for LUA_STR_CHECK hasn't been called, CheckId %u account Id %u", *itr, _session->GetAccountId());
                    buff.rpos(buff.wpos());
                    //sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd).c_str());
                    _session->KickPlayer();
                    return;
                }

                uint8 luaStrLen;
                buff >> luaStrLen;

                if (luaStrLen)
                {
                    char *str = new char[luaStrLen + 1];
                    memset(str, 0, luaStrLen + 1);
                    memcpy(str, buff.contents() + buff.rpos(), luaStrLen);
                    sLog.outWarden("RESULT LUA_STR_CHECK fail, CheckId %u account Id %u", *itr, _session->GetAccountId());
                    sLog.outWarden("Lua string found: %s", str);
                    delete[] str;

                    //buff.rpos(buff.wpos());
                    sLog.outWarden("Player %s (account: %u) failed Warden check %u. Action: %s", _session->GetPlayerName(), _session->GetAccountId(), *itr, Penalty(rd).c_str());
                    //return;
                }

                buff.rpos(buff.rpos() + luaStrLen);         // lua string length
                break;
            }
            default:                                        // Should never happen
                break;
        }
    }
}

void WardenWin::HandlePacket02_2(ByteBuffer &buff)
{
    if (_currentModule->ClientKeySeed[0] != 0x7F)
        return;

    //sLog.outWarden("client packet number 2 - %u, required client packet number 2 - %u", m_PacketNumber2_C, m_reqClientPacketNumber2);
    m_sendLastPacketCount2 = 0;

    uint8 MemResult;
    buff >> MemResult;
    
    if (MemResult)
    {
        buff.rpos(buff.wpos());
        _checkTimer2 = 4 * IN_MILLISECONDS;
        return;
    }

    // first packet in chain
    if (!pDevice && !pEnd && !pScene && !pEndScene)
    {
        buff >> pDevice;
        _checkTimer2 = 2 * IN_MILLISECONDS;
        return;
    }

    // second packet in chain
    if (pDevice && !pEnd && !pScene && !pEndScene)
    {
        buff >> pEnd;
        _checkTimer2 = 2 * IN_MILLISECONDS;
        return;
    }

    // third packet in chain
    if (pDevice && pEnd && !pScene && !pEndScene)
    {
        buff >> pScene;
        _checkTimer2 = 2 * IN_MILLISECONDS;
        return;
    }

    // fourth packet in chain
    if (pDevice && pEnd && pScene && !pEndScene)
    {
        buff >> pEndScene;
        _checkTimer2 = 2 * IN_MILLISECONDS;
        return;
    }

    if (pDevice && pEnd && pScene && pEndScene)
    {
        uint8 checkHook[5];
        buff.read(checkHook, 5);
        if (checkHook[0] == 0xE9 || checkHook[0] == 0xEB)
            sLog.outWarden("Player %s (account: %u): EndSceneHook detected, data - %s", _session->GetPlayerName(), _session->GetAccountId(), _wardenMgr->ConvertByteArrayToString(checkHook, 5).c_str());
        _checkTimer2 = 33 * IN_MILLISECONDS;
        return;
    }
}

void WardenWin::SpecialHandleData(ByteBuffer &buff)
{
    //buff.hexlike();
    //sLog.outWarden("SERVER WARDEN: Special Handle Data for Gasai Bot");

    std::string packet_data = _wardenMgr->ConvertByteArrayToString(buff.contents() + buff.rpos(), 1);
    std::string result = "E9";
    if (strcmp(result.c_str(), packet_data.c_str()))
    {
        sLog.outWarden("RESULT PAGE_CHECK fail, CheckId 200, account Id %u", _session->GetAccountId());
        sLog.outWarden("Penalty: Gasai Bot (accountID - %u, accountName - %s, playerName - %s, clientBuild - %u, checkId - 200, action - 0, realData - E9, failedData - %s)",
            _session->GetAccountId(), _session->GetUsername().c_str(), _session->GetPlayerName(), _clientBuild, packet_data.c_str());
        sLog.outWarden("Player %s (account: %u) failed Warden check 200. Action: Log", _session->GetPlayerName(), _session->GetAccountId());
    }

    buff.rpos(buff.rpos() + 1);

    // reload module
    ChangeModule(1);
}