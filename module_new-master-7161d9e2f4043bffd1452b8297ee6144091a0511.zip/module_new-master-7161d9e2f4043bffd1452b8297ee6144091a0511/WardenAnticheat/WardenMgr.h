/*
 * Copyright (C) 2010-2013 Anathema Engine project <http://valkyrie-wow.com/>
 * Copyright (C) 2005-2009 MaNGOS <http://getmangos.com/>
 */

#ifndef _WARDENMGR_H
#define _WARDENMGR_H

#include <ace/Null_Mutex.h>
#include <ace/Singleton.h>
#include "Common.h"
#include "WorldPacket.h"
#include "WorldSession.h"
#include "Auth/BigNumber.h"

enum WardenCheckType
{
    INTERNAL_CHECK = 0,
    TIMING_CHECK = 0,
    MEM_CHECK = 1,
    PAGE_CHECK_A = 2,
    PAGE_CHECK_B = 3,
    MPQ_CHECK = 4,
    DRIVER_CHECK = 5,
    MODULE_CHECK = 6,
    LUA_STR_CHECK = 7,
    PROC_CHECK = 8,
    MAX_CHECK_TYPE
};

struct WardenModule
{
    uint8 ID[16];
    uint8 Key[16];
    uint8 Seed[16];
    uint8 ServerKeySeed[16];
    uint8 ClientKeySeed[16];
    uint8 ClientKeySeedHash[20];
    uint8 CheckTypes[9];
    //RC4_Context ClientRC4State;
    //RC4_Context ServerRC4State;
    uint8* CompressedData;
    uint32 CompressedSize;
};

struct WardenCheck
{
    uint8 checkId;
    uint8 type;
    BigNumber data;
    uint32 address;
    uint32 length;
    std::string str;
    std::string str1;
    // 0 - log, 1 - kick, 2 - ban
    uint8 action;
    uint32 banTime;
    std::string reason;
};

struct WardenCheckResult
{
    uint16 checkId;
    std::string result;
};

class WardenMgr
{
    public:
        WardenMgr();
        ~WardenMgr();

        // storages
        typedef std::unordered_map<uint32, std::vector<WardenCheck*> > CheckContainer;
        typedef std::unordered_map<uint32, std::vector<WardenCheckResult*> > CheckResultContainer;
        typedef std::unordered_map<uint32, WardenModule*> ModuleContainer;

        // module helpers
        void LoadWardenModules();
        void LoadModule(const char * FileName, uint32 index);
        WardenModule* GetModuleByName(std::string name);
        WardenModule* GetModuleByID(uint32 ID);

        // checks helpers
        void LoadWardenChecks();
        WardenCheck* GetCheckDataById(uint16 checkId, uint16 build);
        WardenCheckResult* GetCheckResultById(uint16 checkId, uint16 build);
        std::vector<uint16> GetChecksIdByType(uint16 type, uint16 build);
        std::vector<uint16> GetChecksIdByType(std::vector<uint16>& currentChecks, uint16 type, uint16 build);
        std::vector<uint8> GetChecksCount();

        //template <typename I>
        //I GetRandomCheckFromList(I begin, I end);
        std::vector<uint16>::iterator GetRandomCheckFromList(std::vector<uint16>::iterator begin, std::vector<uint16>::iterator end);

        std::unordered_map<uint32, std::vector<uint16>> MemChecksPool;
        std::unordered_map<uint32, std::vector<uint16>> MPQChecksPool;
        std::unordered_map<uint32, std::vector<uint16>> PageChecksAPool;
        std::unordered_map<uint32, std::vector<uint16>> PageChecksBPool;
        std::unordered_map<uint32, std::vector<uint16>> LuaStrChecksPool;
        std::unordered_map<uint32, std::vector<uint16>> ModuleChecksPool;
        std::unordered_map<uint32, std::vector<uint16>> DriverChecksPool;
        std::unordered_map<uint32, std::vector<uint16>> ProcChecksPool;

        std::string ConvertByteArrayToString(const uint8 * packet_data, uint16 length);

        ACE_RW_Mutex _checkStoreLock;

    private:
        CheckContainer checkStore;
        CheckResultContainer checkResultStore;
        ModuleContainer moduleStore;
};

#define _wardenMgr ACE_Singleton<WardenMgr, ACE_Null_Mutex>::instance()

#endif
